import os
from cerebras.cloud.sdk import Cerebras
from typing import Dict, List, Optional, Any

class CerebrasAIClient:
    """
    Client để tích hợp với Cerebras AI API
    Cung cấp các phương thức tạo nội dung học thuật chất lượng cao
    """
    
    def __init__(self, api_key: str = None):
        self.api_key = api_key or "csk-ekpp2wm8npdv8wdk43tn6ef53ww86errnw3ec8hwr99xk496"
        self.client = Cerebras(api_key=self.api_key)
        
    def generate_academic_content(self, prompt: str, max_tokens: int = 2000, 
                                temperature: float = 0.7) -> str:
        """
        Tạo nội dung học thuật bằng Cerebras AI
        """
        try:
            response = self.client.chat.completions.create(
                messages=[
                    {
                        "role": "system",
                        "content": """Bạn là một chuyên gia nghiên cứu học thuật với kinh nghiệm viết luận văn tiến sĩ. 
                        Hãy tạo nội dung học thuật chất lượng cao, có trích dẫn phù hợp, logic rõ ràng và tuân thủ 
                        các chuẩn mực nghiên cứu khoa học quốc tế."""
                    },
                    {
                        "role": "user", 
                        "content": prompt
                    }
                ],
                model="llama3.1-8b",
                max_tokens=max_tokens,
                temperature=temperature
            )
            
            return response.choices[0].message.content
            
        except Exception as e:
            return f"Lỗi khi tạo nội dung: {str(e)}"
    
    def generate_theoretical_framework(self, topic: str, field: str, 
                                     research_approach: str) -> str:
        """
        Tạo khung lý thuyết chuyên sâu
        """
        prompt = f"""
        Hãy tạo một khung lý thuyết chuyên sâu và chi tiết cho nghiên cứu về "{topic}" 
        trong lĩnh vực {field} với phương pháp {research_approach}.

        Khung lý thuyết cần bao gồm:
        1. Các lý thuyết nền tảng liên quan (ít nhất 3-4 lý thuyết chính)
        2. Mô hình khái niệm nghiên cứu
        3. Các biến số và mối quan hệ giữa chúng
        4. Giả thuyết nghiên cứu cụ thể (5-7 giả thuyết)
        5. Định nghĩa các khái niệm chính
        6. Tham khảo các nghiên cứu gần đây (2020-2024)

        Hãy viết bằng tiếng Việt với phong cách học thuật và có trích dẫn APA.
        """
        
        return self.generate_academic_content(prompt, max_tokens=3000, temperature=0.6)
    
    def generate_literature_review(self, topic: str, field: str) -> str:
        """
        Tạo tổng quan tài liệu nghiên cứu
        """
        prompt = f"""
        Hãy viết một chương tổng quan tài liệu nghiên cứu chi tiết về "{topic}" 
        trong lĩnh vực {field}.

        Chương cần bao gồm:
        1. Tiến hóa của khái niệm qua các thời kỳ
        2. Các trường phái nghiên cứu chính
        3. Nghiên cứu trong nước và quốc tế
        4. Phân tích so sánh các nghiên cứu
        5. Xác định khoảng trống nghiên cứu
        6. Định vị nghiên cứu hiện tại

        Sử dụng ít nhất 15-20 tài liệu tham khảo, ưu tiên các nghiên cứu từ 2018-2024.
        Viết bằng tiếng Việt với phong cách học thuật.
        """
        
        return self.generate_academic_content(prompt, max_tokens=4000, temperature=0.7)
    
    def generate_methodology_chapter(self, topic: str, field: str, 
                                   research_approach: str) -> str:
        """
        Tạo chương phương pháp nghiên cứu
        """
        prompt = f"""
        Hãy viết chương phương pháp nghiên cứu chi tiết cho nghiên cứu về "{topic}" 
        trong {field} sử dụng {research_approach}.

        Chương cần bao gồm:
        1. Triết lý nghiên cứu và paradigm
        2. Thiết kế nghiên cứu cụ thể
        3. Dân số và mẫu nghiên cứu (với power analysis)
        4. Phương pháp thu thập dữ liệu
        5. Công cụ nghiên cứu và validation
        6. Quy trình thực hiện nghiên cứu
        7. Phương pháp phân tích dữ liệu
        8. Đạo đức nghiên cứu

        Đảm bảo tính khoa học và chi tiết ở mức độ tiến sĩ.
        """
        
        return self.generate_academic_content(prompt, max_tokens=3500, temperature=0.6)
    
    def analyze_and_improve_content(self, content: str, content_type: str) -> str:
        """
        Phân tích và cải thiện nội dung đã có
        """
        prompt = f"""
        Hãy phân tích và cải thiện nội dung {content_type} sau đây để đạt chuẩn học thuật cao hơn:

        {content}

        Hãy:
        1. Đánh giá chất lượng hiện tại
        2. Chỉ ra điểm mạnh và điểm cần cải thiện
        3. Đưa ra phiên bản được cải thiện với:
           - Logic rõ ràng hơn
           - Trích dẫn phù hợp hơn
           - Ngôn ngữ học thuật chính xác hơn
           - Cấu trúc tốt hơn

        Viết bằng tiếng Việt.
        """
        
        return self.generate_academic_content(prompt, max_tokens=3000, temperature=0.5)
    
    def generate_citations(self, topic: str, field: str, num_citations: int = 20) -> List[str]:
        """
        Tạo danh sách tài liệu tham khảo học thuật
        """
        prompt = f"""
        Hãy tạo {num_citations} tài liệu tham khảo học thuật chất lượng cao về "{topic}" 
        trong lĩnh vực {field}.

        Yêu cầu:
        1. Định dạng APA chuẩn
        2. Bao gồm cả tài liệu tiếng Việt và tiếng Anh
        3. Ưu tiên các nghiên cứu từ 2018-2024
        4. Bao gồm đa dạng loại tài liệu: journal articles, books, conferences
        5. Đảm bảo tính liên quan cao đến chủ đề

        Chỉ trả về danh sách các citation, mỗi citation một dòng.
        """
        
        response = self.generate_academic_content(prompt, max_tokens=2000, temperature=0.3)
        return [line.strip() for line in response.split('\n') if line.strip()]
    
    def enhance_research_quality(self, research_question: str, 
                               methodology: str) -> Dict[str, Any]:
        """
        Nâng cao chất lượng nghiên cứu với đề xuất cải thiện
        """
        prompt = f"""
        Phân tích và đề xuất cải thiện chất lượng nghiên cứu:

        Câu hỏi nghiên cứu: {research_question}
        Phương pháp: {methodology}

        Hãy đánh giá và đưa ra khuyến nghị về:
        1. Tính khả thi của nghiên cứu
        2. Điểm mạnh và yếu của thiết kế nghiên cứu
        3. Các rủi ro và hạn chế tiềm ẩn
        4. Đề xuất cải thiện cụ thể
        5. Các phương pháp thay thế có thể xem xét

        Trả về dưới dạng phân tích có cấu trúc rõ ràng.
        """
        
        response = self.generate_academic_content(prompt, max_tokens=2500, temperature=0.6)
        
        return {
            'analysis': response,
            'recommendations': self._extract_recommendations(response),
            'quality_score': self._estimate_quality_score(response)
        }
    
    def _extract_recommendations(self, analysis: str) -> List[str]:
        """
        Trích xuất các khuyến nghị từ phân tích
        """
        # Logic đơn giản để trích xuất khuyến nghị
        lines = analysis.split('\n')
        recommendations = []
        
        for line in lines:
            if any(word in line.lower() for word in ['khuyến nghị', 'đề xuất', 'nên', 'cần']):
                recommendations.append(line.strip())
        
        return recommendations[:5]  # Trả về tối đa 5 khuyến nghị
    
    def _estimate_quality_score(self, analysis: str) -> float:
        """
        Ước tính điểm chất lượng dựa trên phân tích
        """
        # Logic đơn giản để ước tính điểm số
        positive_words = ['tốt', 'mạnh', 'hiệu quả', 'phù hợp', 'khả thi']
        negative_words = ['yếu', 'hạn chế', 'thiếu', 'không', 'khó khăn']
        
        positive_count = sum(word in analysis.lower() for word in positive_words)
        negative_count = sum(word in analysis.lower() for word in negative_words)
        
        # Tính điểm từ 1-10
        base_score = 5.0
        score_adjustment = (positive_count - negative_count) * 0.5
        
        return max(1.0, min(10.0, base_score + score_adjustment))
