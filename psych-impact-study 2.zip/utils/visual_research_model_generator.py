"""
Visual Research Model Generator
Automatically creates research models with visual diagrams showing relationships 
between independent, dependent, mediating, and moderating variables.
"""
import matplotlib.pyplot as plt
import matplotlib.patches as patches
from matplotlib.patches import FancyBboxPatch, ConnectionPatch
import numpy as np
from typing import Dict, List, Any, Tuple
import io
import base64
from PIL import Image
import random

class ResearchVariable:
    """Represents a research variable with its properties"""
    
    def __init__(self, name: str, var_type: str, description: str = "", 
                 measurement_scale: str = "interval"):
        self.name = name
        self.type = var_type  # independent, dependent, mediating, moderating, control
        self.description = description
        self.measurement_scale = measurement_scale  # nominal, ordinal, interval, ratio
        self.position = (0, 0)  # x, y coordinates for visualization

class ResearchModel:
    """Complete research model with variables and relationships"""
    
    def __init__(self, model_name: str, research_topic: str):
        self.model_name = model_name
        self.research_topic = research_topic
        self.variables = []
        self.relationships = []
        self.hypotheses = []
        
    def add_variable(self, variable: ResearchVariable):
        self.variables.append(variable)
    
    def add_relationship(self, from_var: str, to_var: str, relationship_type: str, 
                        strength: float = 0.5):
        """Add relationship between variables"""
        self.relationships.append({
            'from': from_var,
            'to': to_var,
            'type': relationship_type,  # direct, mediated, moderated
            'strength': strength,  # 0.0 to 1.0
            'direction': 'positive'  # positive, negative, bidirectional
        })
    
    def add_hypothesis(self, hypothesis: str, variables_involved: List[str]):
        self.hypotheses.append({
            'statement': hypothesis,
            'variables': variables_involved,
            'type': 'directional'  # directional, non-directional, null
        })

class VisualResearchModelGenerator:
    """Generates visual research models and diagrams"""
    
    def __init__(self):
        self.color_scheme = {
            'independent': '#4CAF50',      # Green
            'dependent': '#2196F3',        # Blue  
            'mediating': '#FF9800',        # Orange
            'moderating': '#9C27B0',       # Purple
            'control': '#757575',          # Grey
            'relationship': '#424242',     # Dark grey
            'background': '#F5F5F5'        # Light grey
        }
        
        # Pre-defined variable templates by field
        self.variable_templates = self._create_variable_templates()
    
    def _create_variable_templates(self) -> Dict[str, Dict[str, List[str]]]:
        """Create variable templates for different research fields"""
        
        return {
            "giáo dục": {
                "independent": [
                    "Phương pháp dạy học", "Công nghệ giáo dục", "Chương trình đào tạo",
                    "Kỹ năng giảng viên", "Cơ sở vật chất", "Nguồn tài liệu học tập"
                ],
                "dependent": [
                    "Kết quả học tập", "Sự hài lòng của sinh viên", "Động lực học tập",
                    "Kỹ năng tư duy phản biện", "Khả năng ứng dụng kiến thức", "Thành tích học tập"
                ],
                "mediating": [
                    "Động lực học tập", "Sự tự tin", "Thái độ học tập",
                    "Khả năng tự học", "Sự tương tác trong lớp"
                ],
                "moderating": [
                    "Giới tính", "Tuổi", "Kinh nghiệm trước đó",
                    "Hoàn cảnh gia đình", "Khả năng tài chính"
                ]
            },
            
            "kinh tế": {
                "independent": [
                    "Chính sách tài chính", "Đầu tư công nghệ", "Quy mô thị trường",
                    "Cạnh tranh", "Chính sách pháp lý", "Nguồn nhân lực"
                ],
                "dependent": [
                    "Hiệu quả kinh doanh", "Lợi nhuận", "Thị phần",
                    "Sự hài lòng khách hàng", "Tăng trưởng doanh thu", "Khả năng cạnh tranh"
                ],
                "mediating": [
                    "Năng lực tổ chức", "Văn hóa doanh nghiệp", "Chất lượng dịch vụ",
                    "Sự đổi mới", "Mối quan hệ khách hàng"
                ],
                "moderating": [
                    "Quy mô doanh nghiệp", "Ngành công nghiệp", "Vị trí địa lý",
                    "Thời gian hoạt động", "Loại hình sở hữu"
                ]
            },
            
            "y học": {
                "independent": [
                    "Phác đồ điều trị", "Liều lượng thuốc", "Phương pháp phẫu thuật",
                    "Chế độ dinh dưỡng", "Tập luyện phục hồi", "Hỗ trợ tâm lý"
                ],
                "dependent": [
                    "Kết quả điều trị", "Chất lượng cuộc sống", "Tỷ lệ phục hồi",
                    "Thời gian nằm viện", "Tác dụng phụ", "Sự hài lòng bệnh nhân"
                ],
                "mediating": [
                    "Tuân thủ điều trị", "Tình trạng tâm lý", "Hỗ trợ gia đình",
                    "Kiến thức về bệnh", "Động lực điều trị"
                ],
                "moderating": [
                    "Tuổi", "Giới tính", "Tình trạng sức khỏe ban đầu",
                    "Bệnh đi kèm", "Yếu tố di truyền", "Điều kiện kinh tế"
                ]
            },
            
            "kỹ thuật": {
                "independent": [
                    "Thuật toán AI", "Kiến trúc hệ thống", "Công nghệ phần cứng",
                    "Phương pháp tối ưu", "Giao thức truyền thông", "Bảo mật dữ liệu"
                ],
                "dependent": [
                    "Hiệu suất hệ thống", "Độ chính xác", "Thời gian xử lý",
                    "Tiêu thụ năng lượng", "Độ tin cậy", "Khả năng mở rộng"
                ],
                "mediating": [
                    "Chất lượng dữ liệu", "Tối ưu hóa thuật toán", "Cấu hình hệ thống",
                    "Quản lý tài nguyên", "Xử lý lỗi"
                ],
                "moderating": [
                    "Quy mô dữ liệu", "Độ phức tạp bài toán", "Tài nguyên phần cứng",
                    "Yêu cầu thời gian thực", "Môi trường triển khai"
                ]
            }
        }
    
    def generate_research_model(self, topic: str, field: str, 
                              complexity: str = "medium") -> ResearchModel:
        """Generate complete research model for given topic and field"""
        
        model = ResearchModel(
            model_name=f"Mô hình nghiên cứu: {topic}",
            research_topic=topic
        )
        
        # Determine number of variables based on complexity
        var_counts = {
            "simple": {"independent": 2, "dependent": 1, "mediating": 1, "moderating": 1},
            "medium": {"independent": 3, "dependent": 2, "mediating": 2, "moderating": 1}, 
            "complex": {"independent": 4, "dependent": 3, "mediating": 3, "moderating": 2}
        }
        
        counts = var_counts.get(complexity, var_counts["medium"])
        
        # Get field templates
        field_key = self._normalize_field(field)
        templates = self.variable_templates.get(field_key, self.variable_templates["giáo dục"])
        
        # Generate variables
        variables_added = []
        
        for var_type, count in counts.items():
            available_vars = templates[var_type]
            selected_vars = random.sample(available_vars, min(count, len(available_vars)))
            
            for var_name in selected_vars:
                var = ResearchVariable(
                    name=var_name,
                    var_type=var_type,
                    description=f"Biến {var_type} đo lường {var_name.lower()}",
                    measurement_scale="interval" if var_type != "moderating" else "nominal"
                )
                model.add_variable(var)
                variables_added.append(var_name)
        
        # Generate relationships
        self._generate_relationships(model)
        
        # Generate hypotheses
        self._generate_hypotheses(model, topic)
        
        return model
    
    def _normalize_field(self, field: str) -> str:
        """Normalize field name"""
        field_lower = field.lower()
        
        if "giáo dục" in field_lower or "education" in field_lower:
            return "giáo dục"
        elif "kinh tế" in field_lower or "business" in field_lower or "economic" in field_lower:
            return "kinh tế"
        elif "y học" in field_lower or "medical" in field_lower or "health" in field_lower:
            return "y học"
        elif "kỹ thuật" in field_lower or "engineering" in field_lower or "technology" in field_lower:
            return "kỹ thuật"
        else:
            return "giáo dục"
    
    def _generate_relationships(self, model: ResearchModel):
        """Generate logical relationships between variables"""
        
        # Get variables by type
        independent_vars = [v for v in model.variables if v.type == "independent"]
        dependent_vars = [v for v in model.variables if v.type == "dependent"]
        mediating_vars = [v for v in model.variables if v.type == "mediating"]
        moderating_vars = [v for v in model.variables if v.type == "moderating"]
        
        # Direct relationships: Independent -> Dependent
        for ind_var in independent_vars:
            for dep_var in dependent_vars:
                model.add_relationship(
                    ind_var.name, dep_var.name, "direct",
                    strength=random.uniform(0.3, 0.8)
                )
        
        # Mediated relationships: Independent -> Mediating -> Dependent
        for ind_var in independent_vars:
            for med_var in mediating_vars:
                model.add_relationship(
                    ind_var.name, med_var.name, "direct",
                    strength=random.uniform(0.4, 0.7)
                )
                
                for dep_var in dependent_vars:
                    model.add_relationship(
                        med_var.name, dep_var.name, "mediated",
                        strength=random.uniform(0.3, 0.6)
                    )
        
        # Moderated relationships
        for mod_var in moderating_vars:
            # Select random independent-dependent pair for moderation
            if independent_vars and dependent_vars:
                ind_var = random.choice(independent_vars)
                dep_var = random.choice(dependent_vars)
                model.add_relationship(
                    f"{ind_var.name}*{mod_var.name}", dep_var.name, "moderated",
                    strength=random.uniform(0.2, 0.5)
                )
    
    def _generate_hypotheses(self, model: ResearchModel, topic: str):
        """Generate research hypotheses based on model relationships"""
        
        hypothesis_templates = [
            "H{}: {} có tác động tích cực đến {}",
            "H{}: {} tác động đến {} thông qua {}",
            "H{}: {} điều tiết mối quan hệ giữa {} và {}",
            "H{}: Có mối quan hệ tương quan thuận giữa {} và {}"
        ]
        
        h_counter = 1
        
        # Direct hypotheses
        for rel in model.relationships:
            if rel['type'] == 'direct':
                hypothesis = hypothesis_templates[0].format(
                    h_counter, rel['from'], rel['to']
                )
                model.add_hypothesis(hypothesis, [rel['from'], rel['to']])
                h_counter += 1
        
        # Mediation hypotheses (simplified)
        mediating_vars = [v.name for v in model.variables if v.type == "mediating"]
        if mediating_vars and len(model.variables) >= 3:
            ind_var = next(v.name for v in model.variables if v.type == "independent")
            dep_var = next(v.name for v in model.variables if v.type == "dependent")
            med_var = mediating_vars[0]
            
            hypothesis = hypothesis_templates[1].format(
                h_counter, ind_var, dep_var, med_var
            )
            model.add_hypothesis(hypothesis, [ind_var, dep_var, med_var])
        
    def create_visual_diagram(self, model: ResearchModel, 
                            diagram_type: str = "structural") -> str:
        """Create visual diagram of the research model"""
        
        fig, ax = plt.subplots(1, 1, figsize=(14, 10))
        fig.patch.set_facecolor(self.color_scheme['background'])
        ax.set_facecolor('white')
        
        # Calculate positions for variables
        positions = self._calculate_positions(model)
        
        # Draw variables
        drawn_boxes = {}
        for variable in model.variables:
            x, y = positions[variable.name]
            
            # Create variable box
            box = self._draw_variable_box(ax, variable, x, y)
            drawn_boxes[variable.name] = (box, x, y)
        
        # Draw relationships
        if diagram_type == "structural":
            self._draw_relationships(ax, model, positions)
        
        # Add title and labels
        ax.set_title(f"{model.model_name}\n{model.research_topic}", 
                    fontsize=16, fontweight='bold', pad=20)
        
        # Add legend
        self._add_legend(ax)
        
        # Set axis properties
        ax.set_xlim(-1, 11)
        ax.set_ylim(-1, 8)
        ax.set_aspect('equal')
        ax.axis('off')
        
        # Save to base64 string
        buffer = io.BytesIO()
        plt.tight_layout()
        plt.savefig(buffer, format='png', dpi=300, bbox_inches='tight')
        buffer.seek(0)
        
        # Convert to base64
        image_base64 = base64.b64encode(buffer.getvalue()).decode()
        plt.close()
        
        return image_base64
    
    def _calculate_positions(self, model: ResearchModel) -> Dict[str, Tuple[float, float]]:
        """Calculate optimal positions for variables in the diagram"""
        
        # Group variables by type
        var_groups = {
            'independent': [v for v in model.variables if v.type == 'independent'],
            'mediating': [v for v in model.variables if v.type == 'mediating'],
            'dependent': [v for v in model.variables if v.type == 'dependent'],
            'moderating': [v for v in model.variables if v.type == 'moderating'],
            'control': [v for v in model.variables if v.type == 'control']
        }
        
        positions = {}
        
        # Independent variables (left side)
        ind_vars = var_groups['independent']
        if ind_vars:
            y_positions = np.linspace(2, 6, len(ind_vars))
            for i, var in enumerate(ind_vars):
                positions[var.name] = (1, y_positions[i])
        
        # Dependent variables (right side)
        dep_vars = var_groups['dependent']
        if dep_vars:
            y_positions = np.linspace(2, 6, len(dep_vars))
            for i, var in enumerate(dep_vars):
                positions[var.name] = (9, y_positions[i])
        
        # Mediating variables (center)
        med_vars = var_groups['mediating']
        if med_vars:
            y_positions = np.linspace(2.5, 5.5, len(med_vars))
            for i, var in enumerate(med_vars):
                positions[var.name] = (5, y_positions[i])
        
        # Moderating variables (top)
        mod_vars = var_groups['moderating']
        if mod_vars:
            x_positions = np.linspace(3, 7, len(mod_vars))
            for i, var in enumerate(mod_vars):
                positions[var.name] = (x_positions[i], 7)
        
        # Control variables (bottom)
        ctrl_vars = var_groups['control']
        if ctrl_vars:
            x_positions = np.linspace(3, 7, len(ctrl_vars))
            for i, var in enumerate(ctrl_vars):
                positions[var.name] = (x_positions[i], 1)
        
        return positions
    
    def _draw_variable_box(self, ax, variable: ResearchVariable, x: float, y: float):
        """Draw a variable box with appropriate styling"""
        
        color = self.color_scheme.get(variable.type, '#CCCCCC')
        
        # Create rounded rectangle
        box = FancyBboxPatch(
            (x-0.8, y-0.3), 1.6, 0.6,
            boxstyle="round,pad=0.1",
            facecolor=color,
            edgecolor='black',
            linewidth=1.5,
            alpha=0.8
        )
        
        ax.add_patch(box)
        
        # Add text
        ax.text(x, y, variable.name, 
               ha='center', va='center',
               fontsize=9, fontweight='bold',
               color='white' if variable.type != 'control' else 'black',
               wrap=True)
        
        return box
    
    def _draw_relationships(self, ax, model: ResearchModel, positions: Dict[str, Tuple[float, float]]):
        """Draw relationship arrows between variables"""
        
        for rel in model.relationships:
            if '*' in rel['from']:  # Moderated relationship
                continue  # Skip for now, handle separately
            
            if rel['from'] in positions and rel['to'] in positions:
                x1, y1 = positions[rel['from']]
                x2, y2 = positions[rel['to']]
                
                # Calculate arrow properties
                arrow_color = self.color_scheme['relationship']
                arrow_width = rel['strength'] * 3
                
                # Draw arrow
                arrow = ConnectionPatch(
                    (x1+0.8, y1), (x2-0.8, y2),
                    "data", "data",
                    arrowstyle="->",
                    shrinkA=5, shrinkB=5,
                    mutation_scale=15,
                    color=arrow_color,
                    linewidth=arrow_width,
                    alpha=0.7
                )
                ax.add_patch(arrow)
                
                # Add relationship label
                mid_x, mid_y = (x1+x2)/2, (y1+y2)/2
                if rel['type'] == 'mediated':
                    ax.text(mid_x, mid_y+0.2, f"β={rel['strength']:.2f}", 
                           ha='center', va='center', fontsize=8,
                           bbox=dict(boxstyle="round,pad=0.2", facecolor='yellow', alpha=0.7))
    
    def _add_legend(self, ax):
        """Add legend explaining variable types"""
        
        legend_elements = []
        legend_labels = {
            'independent': 'Biến độc lập',
            'dependent': 'Biến phụ thuộc', 
            'mediating': 'Biến trung gian',
            'moderating': 'Biến điều tiết',
            'control': 'Biến kiểm soát'
        }
        
        y_pos = 0.5
        for var_type, label in legend_labels.items():
            color = self.color_scheme[var_type]
            
            # Draw legend box
            legend_box = FancyBboxPatch(
                (10.5, y_pos-0.15), 0.3, 0.3,
                boxstyle="round,pad=0.05",
                facecolor=color,
                edgecolor='black',
                alpha=0.8
            )
            ax.add_patch(legend_box)
            
            # Add legend text
            ax.text(11, y_pos, label, ha='left', va='center', fontsize=10)
            
            y_pos += 0.8
    
    def export_model_description(self, model: ResearchModel) -> str:
        """Export detailed model description"""
        
        description = f"""# MÔ HÌNH NGHIÊN CỨU: {model.model_name.upper()}

## 1. TỔNG QUAN MÔ HÌNH

Đề tài nghiên cứu: {model.research_topic}

Mô hình nghiên cứu này được thiết kế để khám phá các mối quan hệ phức tạp giữa các yếu tố ảnh hưởng đến {model.research_topic.lower()}. Mô hình bao gồm {len(model.variables)} biến số chính được phân loại theo vai trò và chức năng trong nghiên cứu.

## 2. CÁC BIẾN TRONG MÔ HÌNH

"""
        
        # Group variables by type
        var_types = ['independent', 'dependent', 'mediating', 'moderating', 'control']
        type_names = {
            'independent': 'BIẾN ĐỘC LẬP',
            'dependent': 'BIẾN PHỤ THUỘC',
            'mediating': 'BIẾN TRUNG GIAN', 
            'moderating': 'BIẾN ĐIỀU TIẾT',
            'control': 'BIẾN KIỂM SOÁT'
        }
        
        for var_type in var_types:
            vars_of_type = [v for v in model.variables if v.type == var_type]
            if vars_of_type:
                description += f"### 2.{var_types.index(var_type)+1} {type_names[var_type]}\n\n"
                
                for i, var in enumerate(vars_of_type, 1):
                    description += f"**{var.name}**\n"
                    description += f"- Mô tả: {var.description}\n"
                    description += f"- Thang đo: {var.measurement_scale}\n\n"
        
        # Add relationships
        description += "\n## 3. CÁC MỐI QUAN HỆ TRONG MÔ HÌNH\n\n"
        
        for i, rel in enumerate(model.relationships, 1):
            description += f"**Mối quan hệ {i}:** {rel['from']} → {rel['to']}\n"
            description += f"- Loại quan hệ: {rel['type']}\n"
            description += f"- Mức độ tác động: {rel['strength']:.2f}\n"
            description += f"- Hướng tác động: {rel['direction']}\n\n"
        
        # Add hypotheses
        description += "\n## 4. CÁC GIẢ THUYẾT NGHIÊN CỨU\n\n"
        
        for i, hypothesis in enumerate(model.hypotheses, 1):
            description += f"**{hypothesis['statement']}**\n"
            description += f"- Các biến liên quan: {', '.join(hypothesis['variables'])}\n"
            description += f"- Loại giả thuyết: {hypothesis['type']}\n\n"
        
        # Add model implications
        description += "\n## 5. Ý NGHĨA VÀ ỨNG DỤNG CỦA MÔ HÌNH\n\n"
        description += f"Mô hình này cung cấp framework tổng quát để hiểu rõ các yếu tố ảnh hưởng đến {model.research_topic.lower()}. "
        description += "Các phát hiện từ mô hình sẽ có ý nghĩa quan trọng trong việc:\n\n"
        description += "1. Xây dựng lý thuyết và mở rộng kiến thức hiện có\n"
        description += "2. Đưa ra các khuyến nghị chính sách và thực tiễn\n"
        description += "3. Định hướng cho các nghiên cứu tiếp theo\n"
        description += "4. Cải thiện hiệu quả các can thiệp và giải pháp\n"
        
        return description
    
    def create_statistical_analysis_plan(self, model: ResearchModel) -> str:
        """Create statistical analysis plan based on the model"""
        
        plan = f"""# KẾ HOẠCH PHÂN TÍCH THỐNG KÊ

## 1. TỔNG QUAN
Đề tài: {model.research_topic}
Số biến: {len(model.variables)}
Số giả thuyết: {len(model.hypotheses)}

## 2. PHƯƠNG PHÁP PHÂN TÍCH CHO TỪNG LOẠI BIẾN

"""
        
        # Analysis methods by variable types
        var_counts = {}
        for var in model.variables:
            var_counts[var.type] = var_counts.get(var.type, 0) + 1
        
        if var_counts.get('independent', 0) > 0 and var_counts.get('dependent', 0) > 0:
            plan += "### 2.1 Phân tích mối quan hệ trực tiếp\n"
            plan += "- **Phương pháp:** Hồi quy tuyến tính đa biến\n"
            plan += "- **Mục đích:** Xác định tác động của các biến độc lập lên biến phụ thuộc\n"
            plan += "- **Công cụ:** SPSS/R/Python\n\n"
        
        if var_counts.get('mediating', 0) > 0:
            plan += "### 2.2 Phân tích trung gian (Mediation Analysis)\n"
            plan += "- **Phương pháp:** Bootstrap mediation analysis (Hayes PROCESS)\n"
            plan += "- **Mục đích:** Kiểm tra tác động gián tiếp qua biến trung gian\n"
            plan += "- **Chỉ số:** Indirect effect, confidence intervals\n\n"
        
        if var_counts.get('moderating', 0) > 0:
            plan += "### 2.3 Phân tích điều tiết (Moderation Analysis)\n"
            plan += "- **Phương pháp:** Hierarchical regression với interaction terms\n"
            plan += "- **Mục đích:** Kiểm tra tác động điều tiết của biến moderator\n"
            plan += "- **Chỉ số:** R² change, interaction coefficients\n\n"
        
        # Add specific analysis steps
        plan += "## 3. QUY TRÌNH PHÂN TÍCH CHI TIẾT\n\n"
        plan += "### Bước 1: Phân tích mô tả\n"
        plan += "- Thống kê mô tả cho tất cả biến\n"
        plan += "- Kiểm tra phân phối dữ liệu\n"
        plan += "- Xử lý dữ liệu thiếu và ngoại lai\n\n"
        
        plan += "### Bước 2: Kiểm tra giả định\n"
        plan += "- Tính chuẩn của phân phối (Shapiro-Wilk test)\n"
        plan += "- Tính đồng nhất phương sai (Levene's test)\n"
        plan += "- Tính độc lập của sai số\n"
        plan += "- Kiểm tra đa cộng tuyến (VIF)\n\n"
        
        plan += "### Bước 3: Phân tích tương quan\n"
        plan += "- Ma trận tương quan Pearson\n"
        plan += "- Kiểm định ý nghĩa thống kê\n"
        plan += "- Biểu đồ scatter plots\n\n"
        
        plan += "### Bước 4: Kiểm định giả thuyết\n"
        for i, hypothesis in enumerate(model.hypotheses, 1):
            plan += f"- {hypothesis['statement']}: Regression analysis\n"
        
        plan += "\n### Bước 5: Báo cáo kết quả\n"
        plan += "- Bảng hệ số hồi quy\n"
        plan += "- Biểu đồ mô hình cấu trúc\n"
        plan += "- Thảo luận ý nghĩa thống kê và thực tiễn\n"
        
        return plan
