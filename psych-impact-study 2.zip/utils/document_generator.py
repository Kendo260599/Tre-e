from docx import Document
from docx.shared import Inches, Pt
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.style import WD_STYLE_TYPE
import io

class DocumentGenerator:
    """
    Generate downloadable DOCX documents for thesis outlines
    """
    
    def create_document(self, outline, topic, field, level, objectives):
        """
        Create a formatted DOCX document with the thesis outline
        """
        doc = Document()
        
        # Set document margins
        sections = doc.sections
        for section in sections:
            section.top_margin = Inches(1)
            section.bottom_margin = Inches(1)
            section.left_margin = Inches(1)
            section.right_margin = Inches(1)
        
        # Title page
        self._add_title_page(doc, topic, field, level)
        
        # Add page break
        doc.add_page_break()
        
        # Table of contents header
        toc_heading = doc.add_heading('MỤC LỤC', level=1)
        toc_heading.alignment = WD_ALIGN_PARAGRAPH.CENTER
        
        # Generate table of contents
        self._add_table_of_contents(doc, outline)
        
        doc.add_page_break()
        
        # Add detailed outline
        self._add_detailed_outline(doc, outline, topic, objectives)
        
        # Save to buffer
        doc_buffer = io.BytesIO()
        doc.save(doc_buffer)
        doc_buffer.seek(0)
        
        return doc_buffer
    
    def _add_title_page(self, doc, topic, field, level):
        """
        Add a professional title page
        """
        # University info (placeholder - can be customized)
        university = doc.add_paragraph()
        university.alignment = WD_ALIGN_PARAGRAPH.CENTER
        run = university.add_run("TRƯỜNG ĐẠI HỌC [TÊN TRƯỜNG]\nKHOA [TÊN KHOA]")
        run.font.size = Pt(12)
        run.bold = True
        
        doc.add_paragraph()
        doc.add_paragraph()
        
        # Title
        title = doc.add_paragraph()
        title.alignment = WD_ALIGN_PARAGRAPH.CENTER
        title_run = title.add_run(f"ĐỀ CƯƠNG LUẬN ÁN {level.upper()}")
        title_run.font.size = Pt(16)
        title_run.bold = True
        
        doc.add_paragraph()
        
        # Topic
        topic_para = doc.add_paragraph()
        topic_para.alignment = WD_ALIGN_PARAGRAPH.CENTER
        topic_run = topic_para.add_run(f'"{topic.upper()}"')
        topic_run.font.size = Pt(14)
        topic_run.bold = True
        
        doc.add_paragraph()
        doc.add_paragraph()
        
        # Field of study
        field_para = doc.add_paragraph()
        field_para.alignment = WD_ALIGN_PARAGRAPH.CENTER
        field_run = field_para.add_run(f"Chuyên ngành: {field}")
        field_run.font.size = Pt(12)
        
        # Add some space
        for _ in range(8):
            doc.add_paragraph()
        
        # Footer info
        footer = doc.add_paragraph()
        footer.alignment = WD_ALIGN_PARAGRAPH.CENTER
        footer_run = footer.add_run("Hà Nội - 2024")
        footer_run.font.size = Pt(12)
        footer_run.bold = True
    
    def _add_table_of_contents(self, doc, outline):
        """
        Generate a table of contents
        """
        for chapter in outline:
            # Chapter title
            chapter_para = doc.add_paragraph()
            chapter_run = chapter_para.add_run(chapter['title'])
            chapter_run.bold = True
            
            # Sections
            if chapter.get('sections'):
                for section in chapter['sections']:
                    section_para = doc.add_paragraph()
                    section_para.paragraph_format.left_indent = Inches(0.5)
                    section_para.add_run(f"{section['number']} {section['title']}")
            
            doc.add_paragraph()
    
    def _add_detailed_outline(self, doc, outline, topic, objectives):
        """
        Add the detailed outline with descriptions
        """
        # Introduction section
        intro_heading = doc.add_heading('GIỚI THIỆU ĐỀ CƯƠNG', level=1)
        intro_heading.alignment = WD_ALIGN_PARAGRAPH.CENTER
        
        # Research info
        info_para = doc.add_paragraph()
        info_para.add_run("Chủ đề nghiên cứu: ").bold = True
        info_para.add_run(topic)
        
        obj_para = doc.add_paragraph()
        obj_para.add_run("Mục tiêu nghiên cứu: ").bold = True
        obj_para.add_run(objectives)
        
        doc.add_paragraph()
        doc.add_page_break()
        
        # Detailed chapters
        for chapter in outline:
            # Chapter heading
            chapter_heading = doc.add_heading(chapter['title'], level=1)
            
            # Chapter description
            if chapter.get('description'):
                desc_para = doc.add_paragraph(chapter['description'].strip())
                desc_para.paragraph_format.space_after = Pt(12)
            
            # Sections
            if chapter.get('sections'):
                for section in chapter['sections']:
                    # Section heading
                    section_heading = doc.add_heading(
                        f"{section['number']} {section['title']}", 
                        level=2
                    )
                    
                    # Section description
                    if section.get('description'):
                        section_desc = doc.add_paragraph(section['description'])
                        section_desc.paragraph_format.space_after = Pt(6)
            
            # Add space between chapters
            doc.add_paragraph()
