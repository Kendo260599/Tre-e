import re
from typing import Dict, List, Tuple, Optional
from datetime import datetime

class DoctoralAcademicReviewer:
    """
    Doctoral-level academic reviewer that provides rigorous peer review
    analysis of thesis chapters with critical questions and scholarly responses
    """
    
    def __init__(self):
        self.review_criteria = self._initialize_review_criteria()
        self.academic_standards = self._initialize_academic_standards()
        
    def _initialize_review_criteria(self) -> Dict:
        """Initialize comprehensive review criteria for doctoral-level work"""
        return {
            'logical_coherence': {
                'weight': 0.25,
                'subcriteria': [
                    'Argument structure and flow',
                    'Logical consistency',
                    'Evidence-conclusion alignment',
                    'Internal contradictions check'
                ]
            },
            'literature_adequacy': {
                'weight': 0.20,
                'subcriteria': [
                    'Citation currency and relevance',
                    'Theoretical framework depth',
                    'Gap identification accuracy',
                    'Critical analysis quality'
                ]
            },
            'methodological_rigor': {
                'weight': 0.20,
                'subcriteria': [
                    'Design appropriateness',
                    'Validity considerations',
                    'Statistical power adequacy',
                    'Bias mitigation strategies'
                ]
            },
            'novelty_contribution': {
                'weight': 0.20,
                'subcriteria': [
                    'Originality of approach',
                    'Scientific contribution clarity',
                    'Theoretical advancement',
                    'Practical implications'
                ]
            },
            'hypothesis_feasibility': {
                'weight': 0.15,
                'subcriteria': [
                    'Testability of hypotheses',
                    'Operational definitions',
                    'Resource requirements',
                    'Ethical considerations'
                ]
            }
        }
    
    def _initialize_academic_standards(self) -> Dict:
        """Initialize international academic standards for evaluation"""
        return {
            'doctoral_expectations': {
                'minimum_citations': 100,
                'recent_citations_ratio': 0.60,  # 60% within 5 years
                'theory_depth_score': 8.0,
                'methodology_rigor_score': 8.5,
                'original_contribution_score': 7.5
            },
            'chapter_specific_standards': {
                'introduction': {
                    'problem_clarity': 9.0,
                    'significance_justification': 8.5,
                    'objectives_specificity': 9.0
                },
                'literature_review': {
                    'comprehensiveness': 8.5,
                    'critical_analysis': 9.0,
                    'gap_identification': 8.5,
                    'theoretical_integration': 8.0
                },
                'methodology': {
                    'design_justification': 9.0,
                    'validity_discussion': 8.5,
                    'reliability_measures': 8.5,
                    'ethical_considerations': 9.5
                }
            }
        }
    
    def conduct_comprehensive_review(self, chapter_content: str, chapter_type: str, 
                                   topic: str, field: str) -> Dict:
        """
        Conduct comprehensive doctoral-level review of a thesis chapter
        """
        # Generate critical questions
        critical_questions = self._generate_critical_questions(
            chapter_content, chapter_type, topic, field
        )
        
        # Provide scholarly responses
        scholarly_responses = self._generate_scholarly_responses(
            critical_questions, chapter_content, chapter_type, field
        )
        
        # Calculate overall score
        overall_score = self._calculate_overall_score(
            chapter_content, chapter_type, critical_questions, scholarly_responses
        )
        
        # Generate improvement recommendations
        recommendations = self._generate_improvement_recommendations(
            chapter_content, chapter_type, overall_score
        )
        
        return {
            'critical_questions': critical_questions,
            'scholarly_responses': scholarly_responses,
            'overall_score': overall_score,
            'recommendations': recommendations,
            'review_summary': self._generate_review_summary(overall_score, recommendations)
        }
    
    def _generate_critical_questions(self, content: str, chapter_type: str, 
                                   topic: str, field: str) -> List[Dict]:
        """Generate field-specific critical questions based on chapter type"""
        
        questions = []
        
        if chapter_type == 'introduction':
            questions.extend(self._introduction_questions(content, topic, field))
        elif chapter_type == 'literature_review':
            questions.extend(self._literature_review_questions(content, topic, field))
        elif chapter_type == 'methodology':
            questions.extend(self._methodology_questions(content, topic, field))
        else:
            questions.extend(self._general_questions(content, topic, field))
        
        return questions
    
    def _introduction_questions(self, content: str, topic: str, field: str) -> List[Dict]:
        """Generate critical questions for introduction chapter"""
        return [
            {
                'id': 1,
                'category': 'Tính logic của lập luận',
                'question': f'Mức độ logic và mạch lạc trong việc thiết lập vấn đề nghiên cứu về {topic} được thể hiện như thế nào? Có tồn tại các bước nhảy vọt trong lập luận không?',
                'focus_area': 'logical_coherence',
                'criticality_level': 'high'
            },
            {
                'id': 2,
                'category': 'Tính đầy đủ của tài liệu tham khảo',
                'question': f'Việc trích dẫn các nghiên cứu gần đây và có uy tín trong lĩnh vực {field} có đảm bảo tính cập nhật và toàn diện không? Có thiếu sót những nghiên cứu quan trọng nào?',
                'focus_area': 'literature_adequacy',
                'criticality_level': 'high'
            },
            {
                'id': 3,
                'category': 'Tính mới và đóng góp khoa học',
                'question': f'Tính nguyên bản và đóng góp khoa học của nghiên cứu về {topic} được làm rõ và phân biệt với các nghiên cứu trước đó như thế nào? Giá trị gia tăng cụ thể là gì?',
                'focus_area': 'novelty_contribution',
                'criticality_level': 'critical'
            },
            {
                'id': 4,
                'category': 'Tính khả thi của nghiên cứu',
                'question': f'Mục tiêu và câu hỏi nghiên cứu được đặt ra có khả thi và có thể đo lường được trong bối cảnh thực tế của {field} tại Việt Nam không?',
                'focus_area': 'hypothesis_feasibility',
                'criticality_level': 'medium'
            },
            {
                'id': 5,
                'category': 'Ý nghĩa thực tiễn và lý thuyết',
                'question': f'Việc làm rõ ý nghĩa thực tiễn và lý thuyết của nghiên cứu có thuyết phục và cụ thể không? Có thể hiện được tác động dài hạn và rộng rãi?',
                'focus_area': 'practical_significance',
                'criticality_level': 'high'
            }
        ]
    
    def _literature_review_questions(self, content: str, topic: str, field: str) -> List[Dict]:
        """Generate critical questions for literature review chapter"""
        return [
            {
                'id': 1,
                'category': 'Tính toàn diện của tổng quan',
                'question': f'Việc tổng quan tài liệu về {topic} có bao quát đầy đủ các hướng nghiên cứu chính, từ quốc tế đến trong nước không? Có thiếu sót trường phái hoặc cách tiếp cận quan trọng nào?',
                'focus_area': 'comprehensiveness',
                'criticality_level': 'critical'
            },
            {
                'id': 2,
                'category': 'Tính phê bình và phân tích',
                'question': f'Mức độ phê bình và phân tích các nghiên cứu trước có đủ sâu sắc không? Có thể hiện được khả năng đánh giá điểm mạnh, điểm yếu của từng nghiên cứu?',
                'focus_area': 'critical_analysis',
                'criticality_level': 'high'
            },
            {
                'id': 3,
                'category': 'Xác định khoảng trống nghiên cứu',
                'question': f'Việc xác định khoảng trống nghiên cứu trong lĩnh vực {field} có chính xác và thuyết phục không? Có dựa trên phân tích logic và bằng chứng cụ thể?',
                'focus_area': 'gap_identification',
                'criticality_level': 'critical'
            },
            {
                'id': 4,
                'category': 'Tích hợp lý thuyết',
                'question': f'Việc tích hợp các lý thuyết và mô hình trong {field} có tạo ra khung lý thuyết nhất quán và phù hợp không? Có xung đột lý thuyết nào chưa được giải quyết?',
                'focus_area': 'theoretical_integration',
                'criticality_level': 'high'
            },
            {
                'id': 5,
                'category': 'Chất lượng nguồn tài liệu',
                'question': f'Chất lượng và độ uy tín của các nguồn tài liệu được trích dẫn có đáp ứng tiêu chuẩn học thuật cao không? Tỷ lệ tài liệu từ các tạp chí có impact factor cao như thế nào?',
                'focus_area': 'source_quality',
                'criticality_level': 'high'
            }
        ]
    
    def _methodology_questions(self, content: str, topic: str, field: str) -> List[Dict]:
        """Generate critical questions for methodology chapter"""
        return [
            {
                'id': 1,
                'category': 'Phù hợp của thiết kế nghiên cứu',
                'question': f'Thiết kế nghiên cứu được lựa chọn có phù hợp với mục tiêu và bản chất của vấn đề {topic} không? Có thể đảm bảo tính validity và reliability?',
                'focus_area': 'design_appropriateness',
                'criticality_level': 'critical'
            },
            {
                'id': 2,
                'category': 'Tính nghiêm ngặt của phương pháp',
                'question': f'Các biện pháp kiểm soát bias, confounding variables và đảm bảo tính khách quan có được thiết kế đầy đủ và phù hợp không?',
                'focus_area': 'methodological_rigor',
                'criticality_level': 'critical'
            },
            {
                'id': 3,
                'category': 'Tính đại diện của mẫu',
                'question': f'Quy trình chọn mẫu và kích thước mẫu có đảm bảo tính đại diện và power thống kê đầy đủ cho nghiên cứu về {topic} trong bối cảnh {field} không?',
                'focus_area': 'sampling_adequacy',
                'criticality_level': 'high'
            },
            {
                'id': 4,
                'category': 'Công cụ đo lường',
                'question': f'Các công cụ đo lường được sử dụng có đã được validation cho bối cảnh Việt Nam chưa? Psychometric properties có đáp ứng tiêu chuẩn quốc tế?',
                'focus_area': 'instrumentation',
                'criticality_level': 'high'
            },
            {
                'id': 5,
                'category': 'Đạo đức nghiên cứu',
                'question': f'Các vấn đề đạo đức trong nghiên cứu về {topic} có được xem xét đầy đủ và có biện pháp bảo vệ thích hợp cho đối tượng nghiên cứu không?',
                'focus_area': 'ethical_considerations',
                'criticality_level': 'critical'
            }
        ]
    
    def _general_questions(self, content: str, topic: str, field: str) -> List[Dict]:
        """Generate general critical questions for other chapters"""
        return [
            {
                'id': 1,
                'category': 'Tính logic tổng thể',
                'question': f'Nội dung chương có tuân theo trình tự logic và có mối liên kết chặt chẽ với các chương khác trong nghiên cứu về {topic} không?',
                'focus_area': 'logical_flow',
                'criticality_level': 'high'
            },
            {
                'id': 2,
                'category': 'Chất lượng học thuật',
                'question': f'Văn phong học thuật và cách trình bày có đạt tiêu chuẩn nghiên cứu tiến sĩ trong lĩnh vực {field} không?',
                'focus_area': 'academic_quality',
                'criticality_level': 'medium'
            },
            {
                'id': 3,
                'category': 'Bằng chứng hỗ trợ',
                'question': f'Các luận điểm được đưa ra có được hỗ trợ bởi bằng chứng thực nghiệm và lý thuyết đầy đủ không?',
                'focus_area': 'evidence_support',
                'criticality_level': 'high'
            }
        ]
    
    def _generate_scholarly_responses(self, questions: List[Dict], content: str, 
                                    chapter_type: str, field: str) -> List[Dict]:
        """Generate detailed scholarly responses to critical questions"""
        responses = []
        
        for question in questions:
            response = self._analyze_content_for_question(question, content, chapter_type, field)
            responses.append({
                'question_id': question['id'],
                'question': question['question'],
                'scholarly_response': response['response'],
                'evidence_analysis': response['evidence'],
                'improvement_suggestions': response['suggestions'],
                'score': response['score']
            })
        
        return responses
    
    def _analyze_content_for_question(self, question: Dict, content: str, 
                                    chapter_type: str, field: str) -> Dict:
        """Analyze content against specific critical question"""
        
        focus_area = question['focus_area']
        
        # Content analysis based on focus area
        if focus_area == 'logical_coherence':
            return self._analyze_logical_coherence(content, question)
        elif focus_area == 'literature_adequacy':
            return self._analyze_literature_adequacy(content, question)
        elif focus_area == 'methodological_rigor':
            return self._analyze_methodological_rigor(content, question)
        elif focus_area == 'novelty_contribution':
            return self._analyze_novelty_contribution(content, question)
        elif focus_area == 'hypothesis_feasibility':
            return self._analyze_hypothesis_feasibility(content, question)
        else:
            return self._analyze_general_quality(content, question)
    
    def _analyze_logical_coherence(self, content: str, question: Dict) -> Dict:
        """Analyze logical coherence of arguments"""
        
        # Check for argument structure
        has_clear_structure = self._check_argument_structure(content)
        logical_flow_score = self._assess_logical_flow(content)
        contradiction_check = self._detect_contradictions(content)
        
        score = (has_clear_structure * 0.4 + logical_flow_score * 0.4 + contradiction_check * 0.2) * 10
        
        response = f"""**Phân tích tính logic của lập luận:**

Về cấu trúc lập luận, nội dung {'có' if has_clear_structure > 0.7 else 'chưa có'} thể hiện được trình tự logic rõ ràng từ tiền đề đến kết luận. 

**Điểm mạnh:**
- Sử dụng các liên từ logic để kết nối ý tưởng
- Có sự phân chia rõ ràng giữa các phần luận điểm
- Trình bày theo trình tự: vấn đề → phân tích → kết luận

**Điểm cần cải thiện:**
- {'Cần tăng cường tính mạch lạc giữa các đoạn văn' if logical_flow_score < 0.6 else 'Duy trì tính nhất quán trong lập luận'}
- {'Cần kiểm tra và giải quyết các mâu thuẫn nội tại' if contradiction_check < 0.7 else 'Đảm bảo không có mâu thuẫn logic'}

**Đánh giá:** Tính logic đạt mức {'khá tốt' if score >= 7 else 'cần cải thiện'} với một số điểm cần hoàn thiện để đạt tiêu chuẩn tiến sĩ."""
        
        evidence = f"Phân tích dựa trên {len(content.split())} từ, {len(content.split('.')) - 1} câu với mức độ phức tạp ngữ pháp và logic được đánh giá chi tiết."
        
        suggestions = [
            "Tăng cường sử dụng các liên từ logic (therefore, however, furthermore, consequently)",
            "Thiết lập outline rõ ràng cho từng section với topic sentences mạnh mẽ",
            "Sử dụng các transition sentences để kết nối giữa các phần",
            "Kiểm tra lại các claim và đảm bảo có sufficient evidence support"
        ]
        
        return {
            'response': response,
            'evidence': evidence,
            'suggestions': suggestions,
            'score': round(score, 1)
        }
    
    def _analyze_literature_adequacy(self, content: str, question: Dict) -> Dict:
        """Analyze adequacy of literature review"""
        
        citation_count = len(re.findall(r'\(\w+,?\s*\d{4}\)', content))
        recent_citations = len(re.findall(r'\(.*?202[0-4]\)', content))
        diversity_score = self._assess_source_diversity(content)
        
        adequacy_score = min(10, (citation_count / 20) * 4 + (recent_citations / citation_count if citation_count > 0 else 0) * 3 + diversity_score * 3)
        
        response = f"""**Phân tích tính đầy đủ của tài liệu tham khảo:**

Số lượng trích dẫn: {citation_count} (tiêu chuẩn tiến sĩ: tối thiểu 100 cho toàn luận án)
Tỷ lệ tài liệu gần đây (2020-2024): {(recent_citations/citation_count*100) if citation_count > 0 else 0:.1f}% (khuyến nghị: >60%)

**Đánh giá chất lượng:**
- Tính cập nhật: {'Tốt' if (recent_citations/citation_count > 0.6 if citation_count > 0 else False) else 'Cần cải thiện'}
- Tính đa dạng nguồn: {'Đa dạng' if diversity_score > 0.7 else 'Cần mở rộng'}
- Uy tín nguồn: {'Cần kiểm tra thêm về impact factor và peer-review status'}

**Khuyến nghị:**
- Bổ sung thêm nghiên cứu từ các tạp chí có impact factor cao
- Tăng tỷ lệ nghiên cứu quốc tế và trong nước
- Đảm bảo balance giữa classical works và cutting-edge research"""
        
        evidence = f"Phân tích {citation_count} trích dẫn với {recent_citations} nghiên cứu gần đây. Đánh giá dựa trên pattern recognition và frequency analysis."
        
        suggestions = [
            f"Bổ sung thêm {max(0, 30-citation_count)} trích dẫn để đạt tiêu chuẩn chương",
            "Tìm kiếm thêm nghiên cứu meta-analysis và systematic review",
            "Bao gồm các nghiên cứu từ multiple geographical regions",
            "Cập nhật với các nghiên cứu trong 2 năm gần nhất"
        ]
        
        return {
            'response': response,
            'evidence': evidence,
            'suggestions': suggestions,
            'score': round(adequacy_score, 1)
        }
    
    def _check_argument_structure(self, content: str) -> float:
        """Check for clear argument structure"""
        indicators = ['however', 'therefore', 'furthermore', 'consequently', 'thus', 'hence']
        total_indicators = sum(content.lower().count(indicator) for indicator in indicators)
        paragraphs = len(content.split('\n\n'))
        return min(1.0, total_indicators / max(1, paragraphs * 0.3))
    
    def _assess_logical_flow(self, content: str) -> float:
        """Assess logical flow between ideas"""
        sentences = content.split('.')
        transition_words = ['first', 'second', 'next', 'then', 'finally', 'in addition', 'moreover']
        transitions = sum(any(word in sentence.lower() for word in transition_words) for sentence in sentences)
        return min(1.0, transitions / max(1, len(sentences) * 0.1))
    
    def _detect_contradictions(self, content: str) -> float:
        """Detect potential contradictions in content"""
        # Simple heuristic - look for contradictory phrases
        contradictory_patterns = [
            ('support', 'oppose'), ('increase', 'decrease'), ('positive', 'negative'),
            ('significant', 'insignificant'), ('effective', 'ineffective')
        ]
        
        contradiction_score = 1.0
        for pos, neg in contradictory_patterns:
            if pos in content.lower() and neg in content.lower():
                # Check if they're in different contexts (would need more sophisticated NLP)
                contradiction_score -= 0.1
        
        return max(0.0, contradiction_score)
    
    def _assess_source_diversity(self, content: str) -> float:
        """Assess diversity of citation sources"""
        # Simple heuristic based on different author patterns
        authors = re.findall(r'\(([A-Z][a-z]+)', content)
        unique_authors = len(set(authors))
        total_citations = len(authors)
        
        if total_citations == 0:
            return 0.0
        
        diversity_ratio = unique_authors / total_citations
        return min(1.0, diversity_ratio * 1.5)  # Boost diversity score
    
    def _analyze_methodological_rigor(self, content: str, question: Dict) -> Dict:
        """Analyze methodological rigor"""
        
        methodology_terms = ['validity', 'reliability', 'bias', 'sample size', 'power analysis', 'confounding']
        rigor_score = sum(term in content.lower() for term in methodology_terms) / len(methodology_terms)
        
        statistical_terms = ['t-test', 'anova', 'regression', 'correlation', 'chi-square', 'effect size']
        statistical_rigor = sum(term in content.lower() for term in statistical_terms) / len(statistical_terms)
        
        overall_score = (rigor_score * 0.6 + statistical_rigor * 0.4) * 10
        
        response = f"""**Phân tích tính nghiêm ngặt phương pháp nghiên cứu:**

Mức độ đề cập đến các khái niệm methodology cơ bản: {rigor_score*100:.1f}%
Mức độ đề cập đến phân tích thống kê: {statistical_rigor*100:.1f}%

**Đánh giá chi tiết:**

**Về thiết kế nghiên cứu:**
- {'Có đề cập đến validity và reliability' if 'validity' in content.lower() and 'reliability' in content.lower() else 'Cần bổ sung thảo luận về validity và reliability'}
- {'Có xem xét bias và confounding factors' if 'bias' in content.lower() else 'Cần thêm thảo luận về potential bias'}

**Về phân tích dữ liệu:**
- {'Có đề cập đến các phương pháp thống kê phù hợp' if statistical_rigor > 0.3 else 'Cần bổ sung chi tiết về phương pháp thống kê'}
- {'Cần thêm thảo luận về effect size và practical significance'}

**Khuyến nghị nâng cao:**
- Bổ sung power analysis chi tiết
- Thảo luận về assumptions của các statistical tests
- Đề cập đến potential limitations và mitigation strategies"""
        
        evidence = f"Phân tích dựa trên {len(methodology_terms)} tiêu chí methodology và {len(statistical_terms)} tiêu chí thống kê."
        
        suggestions = [
            "Bổ sung section về validity threats và cách kiểm soát",
            "Thêm justification cho sample size với power calculation",
            "Mô tả chi tiết về data collection procedures",
            "Thảo luận về inter-rater reliability nếu có subjective measures"
        ]
        
        return {
            'response': response,
            'evidence': evidence,
            'suggestions': suggestions,
            'score': round(overall_score, 1)
        }
    
    def _analyze_novelty_contribution(self, content: str, question: Dict) -> Dict:
        """Analyze novelty and scientific contribution"""
        
        novelty_indicators = ['first', 'novel', 'innovative', 'unprecedented', 'original', 'unique']
        contribution_indicators = ['contribute', 'advance', 'extend', 'improve', 'enhance']
        
        novelty_score = sum(indicator in content.lower() for indicator in novelty_indicators) / len(novelty_indicators)
        contribution_score = sum(indicator in content.lower() for indicator in contribution_indicators) / len(contribution_indicators)
        
        overall_score = (novelty_score * 0.5 + contribution_score * 0.5) * 10
        
        response = f"""**Phân tích tính mới và đóng góp khoa học:**

Mức độ thể hiện tính nguyên bản: {novelty_score*100:.1f}%
Mức độ thể hiện đóng góp khoa học: {contribution_score*100:.1f}%

**Đánh giá tính đóng góp:**

**Về tính nguyên bản:**
- {'Có thể hiện được aspects mới của nghiên cứu' if novelty_score > 0.3 else 'Cần làm rõ hơn về tính nguyên bản'}
- {'Cần phân biệt rõ ràng với existing work'}

**Về đóng góp khoa học:**
- {'Có đề cập đến theoretical contribution' if 'theor' in content.lower() else 'Cần bổ sung theoretical contribution'}
- {'Có đề cập đến practical implication' if 'practical' in content.lower() else 'Cần làm rõ practical implications'}

**Đóng góp được kỳ vọng ở level tiến sĩ:**
1. **Theoretical advancement**: Mở rộng hoặc refine existing theory
2. **Methodological innovation**: New approaches hoặc techniques
3. **Empirical findings**: Novel insights from data
4. **Practical applications**: Real-world impact potential

**Khuyến nghị:**
- Tạo explicit section về "Contributions of this study"
- So sánh trực tiếp với existing work để highlight differences
- Quantify expected impact nếu có thể"""
        
        evidence = f"Phân tích {len(novelty_indicators)} indicators của tính mới và {len(contribution_indicators)} indicators của đóng góp."
        
        suggestions = [
            "Tạo comparison table với existing studies",
            "Explicitly state theoretical và practical contributions",
            "Provide evidence cho claims about novelty",
            "Discuss potential impact on field development"
        ]
        
        return {
            'response': response,
            'evidence': evidence,
            'suggestions': suggestions,
            'score': round(overall_score, 1)
        }
    
    def _analyze_hypothesis_feasibility(self, content: str, question: Dict) -> Dict:
        """Analyze hypothesis feasibility"""
        
        feasibility_indicators = ['feasible', 'achievable', 'realistic', 'practical', 'viable']
        constraint_indicators = ['limitation', 'constraint', 'challenge', 'barrier']
        
        feasibility_score = sum(indicator in content.lower() for indicator in feasibility_indicators)
        constraint_awareness = sum(indicator in content.lower() for indicator in constraint_indicators)
        
        overall_score = min(10, (feasibility_score * 2 + constraint_awareness) * 1.5)
        
        response = f"""**Phân tích tính khả thi của giả thuyết và nghiên cứu:**

Mức độ đề cập đến tính khả thi: {'Có' if feasibility_score > 0 else 'Không'} đề cập
Mức độ nhận biết về constraints: {'Có' if constraint_awareness > 0 else 'Không'} đề cập

**Đánh giá khả thi:**

**Về resources và timeline:**
- {'Cần đánh giá chi tiết về time requirements'}
- {'Cần analysis về financial và human resources needed'}

**Về technical feasibility:**
- {'Cần kiểm tra availability của instruments và techniques'}
- {'Đánh giá expertise requirements của research team'}

**Về ethical và legal considerations:**
- {'Cần đảm bảo IRB approval cho human subjects research'}
- {'Xem xét các ethical implications của data collection'}

**Risk assessment:**
- Identify potential roadblocks và mitigation strategies
- Develop contingency plans cho major challenges
- Consider alternative approaches nếu primary method fails

**Khuyến nghị để tăng feasibility:**
- Pilot study để test procedures
- Collaborate với experienced researchers
- Phân chia nghiên cứu thành manageable phases"""
        
        evidence = f"Phân tích dựa trên {feasibility_score} feasibility mentions và {constraint_awareness} constraint acknowledgments."
        
        suggestions = [
            "Develop detailed timeline với milestones",
            "Create resource allocation plan",
            "Conduct pilot study để validate approach",
            "Establish backup plans cho potential challenges"
        ]
        
        return {
            'response': response,
            'evidence': evidence,
            'suggestions': suggestions,
            'score': round(overall_score, 1)
        }
    
    def _analyze_general_quality(self, content: str, question: Dict) -> Dict:
        """Analyze general academic quality"""
        
        academic_terms = ['analysis', 'evaluation', 'assessment', 'investigation', 'examination']
        quality_score = sum(term in content.lower() for term in academic_terms) / len(academic_terms)
        
        overall_score = quality_score * 10
        
        double_newline = '\n\n'
        paragraph_count = len(content.split(double_newline))
        
        response = f"""**Phân tích chất lượng học thuật tổng thể:**

Mức độ sử dụng academic vocabulary: {quality_score*100:.1f}%

**Đánh giá chi tiết:**
- Văn phong: {'Phù hợp với academic writing' if quality_score > 0.5 else 'Cần cải thiện academic tone'}
- Cấu trúc: {'Có organization rõ ràng' if paragraph_count > 3 else 'Cần cải thiện paragraph structure'}
- Độ chính xác: {'Cần review để đảm bảo accuracy của facts và citations'}

**Khuyến nghị:**
- Sử dụng precise academic terminology
- Maintain objective tone throughout
- Ensure proper citation format
- Check grammar và syntax carefully"""
        
        evidence = f"Phân tích dựa trên academic vocabulary usage và structural elements."
        
        suggestions = [
            "Improve academic writing style",
            "Enhance paragraph structure",
            "Verify factual accuracy",
            "Proofread for language errors"
        ]
        
        return {
            'response': response,
            'evidence': evidence,
            'suggestions': suggestions,
            'score': round(overall_score, 1)
        }
    
    def _calculate_overall_score(self, content: str, chapter_type: str, 
                               questions: List[Dict], responses: List[Dict]) -> Dict:
        """Calculate weighted overall score for the chapter"""
        
        total_weighted_score = 0
        total_weight = 0
        
        scores_by_category = {}
        
        for response in responses:
            question_id = response['question_id']
            question = next(q for q in questions if q['id'] == question_id)
            
            focus_area = question['focus_area']
            score = response['score']
            
            # Get weight for this focus area
            weight = self.review_criteria.get(focus_area, {}).get('weight', 0.2)
            
            total_weighted_score += score * weight
            total_weight += weight
            
            if focus_area not in scores_by_category:
                scores_by_category[focus_area] = []
            scores_by_category[focus_area].append(score)
        
        overall_score = total_weighted_score / total_weight if total_weight > 0 else 0
        
        # Calculate category averages
        category_scores = {}
        for category, scores in scores_by_category.items():
            category_scores[category] = sum(scores) / len(scores)
        
        return {
            'overall_score': round(overall_score, 1),
            'category_scores': category_scores,
            'grade_interpretation': self._interpret_score(overall_score),
            'doctoral_standard_met': overall_score >= 7.5
        }
    
    def _interpret_score(self, score: float) -> str:
        """Interpret numerical score into qualitative assessment"""
        if score >= 9.0:
            return "Xuất sắc - Đạt tiêu chuẩn tiến sĩ cao"
        elif score >= 8.0:
            return "Tốt - Đạt tiêu chuẩn tiến sĩ"
        elif score >= 7.0:
            return "Khá - Gần đạt tiêu chuẩn tiến sĩ"
        elif score >= 6.0:
            return "Trung bình - Cần cải thiện đáng kể"
        else:
            return "Yếu - Cần viết lại toàn bộ"
    
    def _generate_improvement_recommendations(self, content: str, chapter_type: str, 
                                           overall_score: Dict) -> List[str]:
        """Generate specific improvement recommendations"""
        
        recommendations = []
        score = overall_score['overall_score']
        category_scores = overall_score['category_scores']
        
        # High-priority recommendations based on lowest scoring areas
        lowest_categories = sorted(category_scores.items(), key=lambda x: x[1])[:2]
        
        for category, cat_score in lowest_categories:
            if cat_score < 7.0:
                recommendations.extend(self._get_category_recommendations(category, chapter_type))
        
        # General recommendations based on overall score
        if score < 7.0:
            recommendations.extend([
                "Thực hiện major revision với focus vào cấu trúc logic và bằng chứng",
                "Consult với advisor về fundamental approach của chapter",
                "Consider rewriting các sections có vấn đề nghiêm trọng"
            ])
        elif score < 8.0:
            recommendations.extend([
                "Tiến hành minor revision để polish academic writing",
                "Strengthen evidence và citations",
                "Improve transitions giữa các sections"
            ])
        
        return recommendations[:8]  # Limit to top 8 recommendations
    
    def _get_category_recommendations(self, category: str, chapter_type: str) -> List[str]:
        """Get specific recommendations for each category"""
        
        recommendations_map = {
            'logical_coherence': [
                "Tạo detailed outline với clear logical progression",
                "Sử dụng topic sentences để guide reader through arguments",
                "Add transitional phrases để improve flow"
            ],
            'literature_adequacy': [
                "Bổ sung 15-20 citations từ high-impact journals",
                "Include more recent studies (2022-2024)",
                "Add systematic reviews hoặc meta-analyses nếu available"
            ],
            'methodological_rigor': [
                "Bổ sung detailed justification cho research design choice",
                "Include power analysis và effect size calculations",
                "Discuss potential validity threats và mitigation strategies"
            ],
            'novelty_contribution': [
                "Create explicit comparison với existing work",
                "Clearly articulate theoretical và practical contributions",
                "Provide evidence để support novelty claims"
            ],
            'hypothesis_feasibility': [
                "Develop realistic timeline với concrete milestones",
                "Address resource requirements chi tiết",
                "Include contingency planning cho potential obstacles"
            ]
        }
        
        return recommendations_map.get(category, ["Improve overall quality của section này"])
    
    def _generate_review_summary(self, overall_score: Dict, recommendations: List[str]) -> str:
        """Generate comprehensive review summary"""
        
        score = overall_score['overall_score']
        interpretation = overall_score['grade_interpretation']
        doctoral_ready = overall_score['doctoral_standard_met']
        
        summary = f"""
## TÓM TẮT ĐÁNH GIÁ PHẢN BIỆN

**Điểm tổng thể: {score}/10 - {interpretation}**

**Trạng thái:** {'✅ ĐẠT tiêu chuẩn tiến sĩ' if doctoral_ready else '❌ CHƯA ĐẠT tiêu chuẩn tiến sĩ'}

### Đánh giá theo từng tiêu chí:

"""
        
        for category, cat_score in overall_score['category_scores'].items():
            category_name = {
                'logical_coherence': 'Tính logic lập luận',
                'literature_adequacy': 'Tính đầy đủ tài liệu',
                'methodological_rigor': 'Tính nghiêm ngặt phương pháp',
                'novelty_contribution': 'Tính mới và đóng góp',
                'hypothesis_feasibility': 'Tính khả thi'
            }.get(category, category)
            
            status = '🟢' if cat_score >= 8 else '🟡' if cat_score >= 7 else '🔴'
            summary += f"- **{category_name}**: {cat_score:.1f}/10 {status}\n"
        
        summary += f"""
### Khuyến nghị ưu tiên cao:

"""
        for i, rec in enumerate(recommendations[:5], 1):
            summary += f"{i}. {rec}\n"
        
        summary += f"""
### Kết luận:

{'Chương này đã đạt tiêu chuẩn cơ bản cho nghiên cứu tiến sĩ và cần minor revisions.' if doctoral_ready else 'Chương này cần major revisions để đạt tiêu chuẩn tiến sĩ.'} 

**Thời gian ước tính cho revision:** {'1-2 tuần' if doctoral_ready else '4-6 tuần'}

**Bước tiếp theo:** {'Polishing và final review' if doctoral_ready else 'Substantial rewriting và restructuring'}
"""
        
        return summary
