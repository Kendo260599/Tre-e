import random
from typing import Dict, List, Optional
from datetime import datetime

class SimulatedPeerReviewPanel:
    """
    Simulates a panel of 3-5 academic reviewers with different expertise and review styles
    Each reviewer has unique perspectives and focuses on different aspects
    """
    
    def __init__(self):
        self.reviewers = self._initialize_reviewers()
        self.review_templates = self._initialize_review_templates()
        
    def _initialize_reviewers(self) -> List[Dict]:
        """Initialize panel of diverse academic reviewers"""
        return [
            {
                'id': 'reviewer_1',
                'name': 'TS. Nguyễn Văn A',
                'expertise': 'Methodology and Statistics',
                'style': 'methodological_rigor',
                'personality': 'strict',
                'focus_areas': ['research_design', 'statistical_analysis', 'validity', 'reliability'],
                'typical_concerns': [
                    'sample size adequacy',
                    'statistical power',
                    'confounding variables',
                    'measurement validity'
                ]
            },
            {
                'id': 'reviewer_2', 
                'name': 'PGS.TS. Trần Thị B',
                'expertise': 'Theory and Literature Review',
                'style': 'theoretical_depth',
                'personality': 'scholarly',
                'focus_areas': ['theoretical_framework', 'literature_review', 'conceptual_model', 'citations'],
                'typical_concerns': [
                    'theoretical contribution',
                    'literature gaps',
                    'conceptual clarity',
                    'citation quality'
                ]
            },
            {
                'id': 'reviewer_3',
                'name': 'TS. Lê Văn C', 
                'expertise': 'Practical Applications',
                'style': 'practical_relevance',
                'personality': 'pragmatic',
                'focus_areas': ['practical_implications', 'real_world_application', 'policy_relevance', 'industry_impact'],
                'typical_concerns': [
                    'practical significance',
                    'implementation feasibility',
                    'stakeholder value',
                    'generalizability'
                ]
            },
            {
                'id': 'reviewer_4',
                'name': 'PGS.TS. Phạm Thị D',
                'expertise': 'Research Innovation',
                'style': 'novelty_contribution',
                'personality': 'innovative',
                'focus_areas': ['originality', 'innovation', 'novel_methods', 'creative_approaches'],
                'typical_concerns': [
                    'research novelty',
                    'methodological innovation',
                    'unique insights',
                    'field advancement'
                ]
            },
            {
                'id': 'reviewer_5',
                'name': 'TS. Hoàng Văn E',
                'expertise': 'Academic Writing',
                'style': 'clarity_presentation',
                'personality': 'detail_oriented',
                'focus_areas': ['writing_quality', 'structure', 'clarity', 'presentation'],
                'typical_concerns': [
                    'writing clarity',
                    'logical flow',
                    'presentation quality',
                    'academic standards'
                ]
            }
        ]
    
    def _initialize_review_templates(self) -> Dict:
        """Initialize review templates for different reviewer styles"""
        return {
            'methodological_rigor': {
                'positive': [
                    "Phương pháp nghiên cứu được thiết kế chặt chẽ và phù hợp với mục tiêu nghiên cứu.",
                    "Việc lựa chọn mẫu và phương pháp thu thập dữ liệu có cơ sở khoa học vững chắc.",
                    "Các biện pháp đảm bảo validity và reliability được thực hiện đầy đủ."
                ],
                'negative': [
                    "Kích thước mẫu cần được justification bằng power analysis chi tiết hơn.",
                    "Cần làm rõ hơn về các biện pháp kiểm soát bias trong quá trình thu thập dữ liệu.",
                    "Phương pháp phân tích thống kê cần được giải thích rõ ràng hơn và phù hợp với nature của dữ liệu."
                ],
                'questions': [
                    "Tại sao tác giả lựa chọn phương pháp này thay vì các alternatives khác?",
                    "Làm thế nào để đảm bảo internal validity trong nghiên cứu này?",
                    "Sample size có đủ statistical power để detect expected effect size không?"
                ]
            },
            'theoretical_depth': {
                'positive': [
                    "Khung lý thuyết được xây dựng một cách logic và có cơ sở vững chắc từ literature.",
                    "Việc tích hợp các lý thuyết khác nhau tạo ra framework mới có giá trị.",
                    "Literature review comprehensive và up-to-date với các nghiên cứu recent."
                ],
                'negative': [
                    "Cần bổ sung thêm recent literature để support cho theoretical framework.",
                    "Mối liên kết giữa các lý thuyết trong framework chưa được explicate đầy đủ.",
                    "Gap trong literature cần được identified rõ ràng hơn để justify research necessity."
                ],
                'questions': [
                    "Tại sao combination của các lý thuyết này lại suitable cho research context?",
                    "Làm thế nào để đảm bảo theoretical contribution của nghiên cứu?",
                    "Có những alternative theoretical perspectives nào khác cần được considered?"
                ]
            },
            'practical_relevance': {
                'positive': [
                    "Nghiên cứu có practical significance cao và có thể application trong thực tế.",
                    "Kết quả nghiên cứu có thể inform policy và practice một cách concrete.",
                    "Implications cho stakeholders được articulate rõ ràng và realistic."
                ],
                'negative': [
                    "Cần làm rõ hơn về practical implications và feasibility của implementation.",
                    "Limitations của research findings trong real-world context cần được discuss.",
                    "Cost-benefit analysis của proposed solutions chưa được addressed adequately."
                ],
                'questions': [
                    "Làm thế nào để implement findings này trong practice?",
                    "Những barriers nào có thể prevent successful implementation?",
                    "Stakeholders nào sẽ benefit most từ research findings này?"
                ]
            },
            'novelty_contribution': {
                'positive': [
                    "Nghiên cứu mang tính novelty cao và contribute significantly vào field knowledge.",
                    "Methodological approach innovative và open new directions cho future research.",
                    "Findings provide unique insights chưa được explored trong previous studies."
                ],
                'negative': [
                    "Novelty của research cần được articulate rõ ràng hơn so với existing work.",
                    "Contribution to theory và practice cần được quantify và specify cụ thể.",
                    "Innovative aspects của methodology cần được validate và justify thoroughly."
                ],
                'questions': [
                    "Điểm mới của nghiên cứu này so với existing literature là gì?",
                    "Innovation methodology có được validated và proven effective chưa?",
                    "Làm thế nào để ensure findings này advance field knowledge significantly?"
                ]
            },
            'clarity_presentation': {
                'positive': [
                    "Văn phong academic clear và structure logical, dễ follow.",
                    "Presentation của data và findings professional và comprehensive.",
                    "Writing quality meets high academic standards với proper citations."
                ],
                'negative': [
                    "Một số sections cần improve clarity và reduce ambiguity trong expression.",
                    "Logical flow giữa các chapters cần được strengthen để enhance coherence.",
                    "Tables và figures cần better labeling và more detailed captions."
                ],
                'questions': [
                    "Có thể simplify complex concepts để increase accessibility không?",
                    "Structure của thesis có optimal cho reader comprehension không?",
                    "Presentation style có consistent throughout toàn bộ document không?"
                ]
            }
        }
    
    def conduct_panel_review(self, chapter_content: str, chapter_type: str, 
                           topic: str, field: str, num_reviewers: int = 3) -> Dict:
        """
        Conduct comprehensive panel review with multiple simulated reviewers
        """
        # Select reviewers for this review
        selected_reviewers = self._select_reviewers(num_reviewers, chapter_type, field)
        
        # Generate reviews from each reviewer
        individual_reviews = []
        
        for reviewer in selected_reviewers:
            review = self._generate_individual_review(
                reviewer, chapter_content, chapter_type, topic, field
            )
            individual_reviews.append(review)
        
        # Generate panel consensus
        panel_consensus = self._generate_panel_consensus(individual_reviews, chapter_type)
        
        # Generate response recommendations
        response_strategies = self._generate_response_strategies(individual_reviews, panel_consensus)
        
        return {
            'individual_reviews': individual_reviews,
            'panel_consensus': panel_consensus,
            'response_strategies': response_strategies,
            'review_summary': self._generate_review_summary(individual_reviews, panel_consensus),
            'defense_preparation': self._generate_defense_preparation(individual_reviews)
        }
    
    def _select_reviewers(self, num_reviewers: int, chapter_type: str, field: str) -> List[Dict]:
        """Select appropriate reviewers based on chapter type and field"""
        
        # Always include methodology expert for any chapter
        selected = [self.reviewers[0]]  # Methodology expert
        
        # Add theory expert for intro, literature review, theoretical framework
        if chapter_type in ['introduction', 'literature_review', 'theoretical_framework']:
            selected.append(self.reviewers[1])  # Theory expert
        
        # Add practical expert for discussion, conclusion, implications
        if chapter_type in ['discussion', 'conclusion', 'implications']:
            selected.append(self.reviewers[2])  # Practical expert
        
        # Add innovation expert for methodology, novel approaches
        if chapter_type in ['methodology', 'innovation'] or 'innovation' in chapter_type:
            selected.append(self.reviewers[3])  # Innovation expert
        
        # Add writing expert for any chapter
        if len(selected) < num_reviewers:
            selected.append(self.reviewers[4])  # Writing expert
        
        # Fill remaining slots randomly if needed
        remaining_reviewers = [r for r in self.reviewers if r not in selected]
        while len(selected) < num_reviewers and remaining_reviewers:
            selected.append(remaining_reviewers.pop(0))
        
        return selected[:num_reviewers]
    
    def _generate_individual_review(self, reviewer: Dict, content: str, 
                                  chapter_type: str, topic: str, field: str) -> Dict:
        """Generate individual review from specific reviewer perspective"""
        
        # Analyze content from reviewer's perspective
        content_analysis = self._analyze_content_by_reviewer(reviewer, content, chapter_type)
        
        # Generate reviewer-specific feedback
        strengths = self._generate_strengths(reviewer, content_analysis)
        weaknesses = self._generate_weaknesses(reviewer, content_analysis)
        questions = self._generate_questions(reviewer, content, chapter_type)
        recommendations = self._generate_recommendations(reviewer, weaknesses)
        
        # Score from reviewer's perspective
        score = self._calculate_reviewer_score(reviewer, content_analysis)
        
        return {
            'reviewer_info': {
                'name': reviewer['name'],
                'expertise': reviewer['expertise'],
                'style': reviewer['style']
            },
            'overall_score': score,
            'strengths': strengths,
            'weaknesses': weaknesses,
            'critical_questions': questions,
            'recommendations': recommendations,
            'detailed_comments': self._generate_detailed_comments(reviewer, content_analysis),
            'decision': self._make_review_decision(score)
        }
    
    def _analyze_content_by_reviewer(self, reviewer: Dict, content: str, chapter_type: str) -> Dict:
        """Analyze content from specific reviewer's expertise perspective"""
        
        analysis = {
            'word_count': len(content.split()),
            'citation_count': len([x for x in content.split() if '(' in x and ')' in x]),
            'structure_score': self._assess_structure(content),
            'focus_area_coverage': {}
        }
        
        # Analyze based on reviewer's focus areas
        for focus_area in reviewer['focus_areas']:
            coverage_score = self._assess_focus_area_coverage(content, focus_area, reviewer['style'])
            analysis['focus_area_coverage'][focus_area] = coverage_score
        
        # Calculate overall quality from reviewer's perspective
        analysis['overall_quality'] = sum(analysis['focus_area_coverage'].values()) / len(analysis['focus_area_coverage'])
        
        return analysis
    
    def _assess_structure(self, content: str) -> float:
        """Assess structural quality of content"""
        paragraphs = content.split('\n\n')
        
        # Check for clear structure indicators
        structure_indicators = ['introduction', 'methodology', 'results', 'discussion', 'conclusion']
        structure_score = sum(1 for indicator in structure_indicators if indicator.lower() in content.lower()) / len(structure_indicators)
        
        # Check paragraph count
        paragraph_score = min(1.0, len(paragraphs) / 10)  # Ideal around 10 paragraphs
        
        return (structure_score + paragraph_score) / 2
    
    def _assess_focus_area_coverage(self, content: str, focus_area: str, reviewer_style: str) -> float:
        """Assess how well content covers specific focus area"""
        
        focus_keywords = {
            'research_design': ['design', 'method', 'approach', 'strategy', 'framework'],
            'statistical_analysis': ['analysis', 'statistical', 'test', 'model', 'data'],
            'validity': ['valid', 'reliable', 'accuracy', 'precision', 'measurement'],
            'theoretical_framework': ['theory', 'framework', 'model', 'concept', 'construct'],
            'literature_review': ['literature', 'study', 'research', 'previous', 'scholar'],
            'practical_implications': ['practical', 'application', 'implementation', 'real-world', 'impact'],
            'originality': ['novel', 'new', 'original', 'innovative', 'unique'],
            'writing_quality': ['clear', 'coherent', 'logical', 'structured', 'organized']
        }
        
        keywords = focus_keywords.get(focus_area, [])
        content_lower = content.lower()
        
        keyword_coverage = sum(1 for keyword in keywords if keyword in content_lower) / max(1, len(keywords))
        
        # Adjust based on content length
        length_factor = min(1.0, len(content.split()) / 500)  # Ideal around 500 words
        
        return (keyword_coverage + length_factor) / 2
    
    def _generate_strengths(self, reviewer: Dict, analysis: Dict) -> List[str]:
        """Generate strengths from reviewer's perspective"""
        
        strengths = []
        templates = self.review_templates[reviewer['style']]['positive']
        
        # Add strengths based on good coverage scores
        high_coverage_areas = [area for area, score in analysis['focus_area_coverage'].items() if score > 0.7]
        
        for area in high_coverage_areas:
            if area in reviewer['focus_areas']:
                # Select appropriate template
                strength = random.choice(templates)
                strengths.append(strength)
        
        # Add general strengths if overall quality is good
        if analysis['overall_quality'] > 0.7:
            general_strengths = [
                f"Nội dung thể hiện sự hiểu biết sâu sắc về {reviewer['expertise'].lower()}",
                f"Cách tiếp cận từ góc độ {reviewer['style'].replace('_', ' ')} rất ấn tượng",
                "Chất lượng academic writing đạt tiêu chuẩn cao"
            ]
            strengths.extend(random.sample(general_strengths, min(2, len(general_strengths))))
        
        return strengths[:4]  # Limit to 4 strengths
    
    def _generate_weaknesses(self, reviewer: Dict, analysis: Dict) -> List[str]:
        """Generate weaknesses from reviewer's perspective"""
        
        weaknesses = []
        templates = self.review_templates[reviewer['style']]['negative']
        
        # Add weaknesses based on low coverage scores
        low_coverage_areas = [area for area, score in analysis['focus_area_coverage'].items() if score < 0.5]
        
        for area in low_coverage_areas:
            if area in reviewer['focus_areas']:
                weakness = random.choice(templates)
                weaknesses.append(weakness)
        
        # Add concerns specific to reviewer
        if reviewer['personality'] == 'strict':
            weaknesses.extend([
                "Cần tăng cường tính rigor trong methodology",
                "Statistical assumptions cần được kiểm tra kỹ lưỡng hơn"
            ])
        elif reviewer['personality'] == 'pragmatic':
            weaknesses.extend([
                "Practical implications cần được elaborate rõ ràng hơn",
                "Implementation feasibility chưa được addressed adequately"
            ])
        
        return weaknesses[:4]  # Limit to 4 weaknesses
    
    def _generate_questions(self, reviewer: Dict, content: str, chapter_type: str) -> List[str]:
        """Generate critical questions from reviewer's perspective"""
        
        questions = []
        template_questions = self.review_templates[reviewer['style']]['questions']
        
        # Add template questions
        questions.extend(random.sample(template_questions, min(2, len(template_questions))))
        
        # Add reviewer-specific questions
        specific_questions = {
            'methodological_rigor': [
                "Có alternative research designs nào có thể strengthen findings không?",
                "Effect size practical significance như thế nào so với statistical significance?"
            ],
            'theoretical_depth': [
                "Theoretical framework này có thể generalize sang contexts khác không?",
                "Contribution to existing theory cụ thể là gì?"
            ],
            'practical_relevance': [
                "Implementation của findings này require resources gì?",
                "Potential unintended consequences của recommendations là gì?"
            ],
            'novelty_contribution': [
                "Innovation này có sustainable và replicable không?",
                "Ethical implications của novel approach này là gì?"
            ],
            'clarity_presentation': [
                "Target audience của research này có understand được findings không?",
                "Visual aids có enhance comprehension không?"
            ]
        }
        
        style_questions = specific_questions.get(reviewer['style'], [])
        questions.extend(random.sample(style_questions, min(2, len(style_questions))))
        
        return questions[:5]  # Limit to 5 questions
    
    def _generate_recommendations(self, reviewer: Dict, weaknesses: List[str]) -> List[str]:
        """Generate actionable recommendations"""
        
        recommendations = []
        
        # Convert weaknesses to actionable recommendations
        for weakness in weaknesses:
            if 'cần' in weakness.lower():
                # Extract recommendation from weakness
                rec = weakness.replace('Cần', 'Khuyến nghị').replace('cần', 'nên')
                recommendations.append(rec)
        
        # Add reviewer-specific recommendations
        style_recommendations = {
            'methodological_rigor': [
                "Thực hiện pilot study để validate instruments",
                "Bổ sung sensitivity analysis để test robustness",
                "Consider mixed-methods approach để triangulate findings"
            ],
            'theoretical_depth': [
                "Develop propositions để extend theory",
                "Create conceptual model diagram để clarify relationships",
                "Link findings back to theoretical implications"
            ],
            'practical_relevance': [
                "Develop implementation roadmap với specific steps",
                "Identify stakeholders và their roles trong implementation",
                "Estimate costs và benefits của proposed solutions"
            ],
            'novelty_contribution': [
                "Highlight unique aspects rõ ràng hơn",
                "Compare innovation với existing approaches systematically",
                "Discuss potential for future research directions"
            ],
            'clarity_presentation': [
                "Simplify technical jargon cho broader audience",
                "Add executive summary cho key findings",
                "Improve visual presentation của complex data"
            ]
        }
        
        style_recs = style_recommendations.get(reviewer['style'], [])
        recommendations.extend(random.sample(style_recs, min(3, len(style_recs))))
        
        return recommendations[:6]  # Limit to 6 recommendations
    
    def _calculate_reviewer_score(self, reviewer: Dict, analysis: Dict) -> float:
        """Calculate score from individual reviewer's perspective"""
        
        base_score = analysis['overall_quality'] * 10
        
        # Adjust based on reviewer personality
        if reviewer['personality'] == 'strict':
            base_score *= 0.85  # Stricter scoring
        elif reviewer['personality'] == 'pragmatic':
            base_score *= 0.90  # Moderate scoring
        elif reviewer['personality'] == 'innovative':
            base_score *= 1.05  # Slightly more generous for innovation
        
        # Ensure score is within bounds
        return max(1.0, min(10.0, base_score))
    
    def _generate_detailed_comments(self, reviewer: Dict, analysis: Dict) -> str:
        """Generate detailed comments from reviewer"""
        
        comments = f"""## Nhận xét chi tiết từ {reviewer['name']}

**Chuyên môn:** {reviewer['expertise']}

### Đánh giá tổng quan

Từ góc độ {reviewer['expertise'].lower()}, tôi đánh giá chương này có chất lượng {'tốt' if analysis['overall_quality'] > 0.7 else 'cần cải thiện'}. 

### Phân tích chi tiết

**Về cấu trúc và tổ chức:** 
Chương có structure {'rõ ràng' if analysis['structure_score'] > 0.6 else 'cần cải thiện'} với logical flow {'tốt' if analysis['structure_score'] > 0.7 else 'có thể tăng cường'}.

**Về nội dung chuyên môn:**
"""
        
        for area, score in analysis['focus_area_coverage'].items():
            if area in reviewer['focus_areas']:
                assessment = 'xuất sắc' if score > 0.8 else 'tốt' if score > 0.6 else 'trung bình' if score > 0.4 else 'yếu'
                comments += f"- {area.replace('_', ' ').title()}: {assessment} ({score:.1%})\n"
        
        comments += f"""
**Về citations và references:**
Với {analysis['citation_count']} citations, mức độ support literature {'đầy đủ' if analysis['citation_count'] > 20 else 'cần bổ sung'}.

### Khuyến nghị prioritization

1. **Immediate actions:** Address các weaknesses có impact cao nhất
2. **Short-term improvements:** Enhance areas với moderate coverage
3. **Long-term development:** Consider advanced methodologies

### Conclusion

{'Chấp nhận với minor revisions' if analysis['overall_quality'] > 0.7 else 'Cần major revisions trước khi chấp nhận'}.
"""
        
        return comments
    
    def _make_review_decision(self, score: float) -> str:
        """Make review decision based on score"""
        
        if score >= 8.5:
            return "Accept"
        elif score >= 7.0:
            return "Minor Revisions"
        elif score >= 5.5:
            return "Major Revisions"
        else:
            return "Reject"
    
    def _generate_panel_consensus(self, individual_reviews: List[Dict], chapter_type: str) -> Dict:
        """Generate consensus from panel reviews"""
        
        scores = [review['overall_score'] for review in individual_reviews]
        decisions = [review['decision'] for review in individual_reviews]
        
        # Calculate consensus metrics
        avg_score = sum(scores) / len(scores)
        score_std = (sum((s - avg_score) ** 2 for s in scores) / len(scores)) ** 0.5
        
        # Determine consensus decision
        decision_weights = {'Accept': 4, 'Minor Revisions': 3, 'Major Revisions': 2, 'Reject': 1}
        weighted_decision = sum(decision_weights[decision] for decision in decisions) / len(decisions)
        
        if weighted_decision >= 3.5:
            consensus_decision = "Accept with Minor Revisions"
        elif weighted_decision >= 2.5:
            consensus_decision = "Major Revisions Required"
        elif weighted_decision >= 1.5:
            consensus_decision = "Reject and Resubmit"
        else:
            consensus_decision = "Reject"
        
        # Identify common themes
        all_strengths = []
        all_weaknesses = []
        all_questions = []
        
        for review in individual_reviews:
            all_strengths.extend(review['strengths'])
            all_weaknesses.extend(review['weaknesses'])
            all_questions.extend(review['critical_questions'])
        
        return {
            'average_score': avg_score,
            'score_range': f"{min(scores):.1f} - {max(scores):.1f}",
            'score_consistency': 'High' if score_std < 1.0 else 'Moderate' if score_std < 1.5 else 'Low',
            'consensus_decision': consensus_decision,
            'common_strengths': self._find_common_themes(all_strengths)[:3],
            'common_concerns': self._find_common_themes(all_weaknesses)[:3],
            'priority_questions': self._prioritize_questions(all_questions)[:5],
            'revision_timeline': self._estimate_revision_time(consensus_decision)
        }
    
    def _find_common_themes(self, items: List[str]) -> List[str]:
        """Find common themes in feedback items"""
        
        # Simple keyword-based theme detection
        keywords = {}
        for item in items:
            words = item.lower().split()
            for word in words:
                if len(word) > 4:  # Filter out short words
                    keywords[word] = keywords.get(word, 0) + 1
        
        # Find most common themes
        common_keywords = sorted(keywords.items(), key=lambda x: x[1], reverse=True)[:5]
        
        # Return original items that contain common keywords
        themed_items = []
        for keyword, count in common_keywords:
            if count > 1:  # Mentioned multiple times
                for item in items:
                    if keyword in item.lower() and item not in themed_items:
                        themed_items.append(item)
                        break
        
        return themed_items
    
    def _prioritize_questions(self, questions: List[str]) -> List[str]:
        """Prioritize questions by importance indicators"""
        
        priority_keywords = ['tại sao', 'làm thế nào', 'có thể', 'should', 'could', 'would']
        
        prioritized = []
        for question in questions:
            priority_score = sum(1 for keyword in priority_keywords if keyword in question.lower())
            prioritized.append((question, priority_score))
        
        # Sort by priority score and return top questions
        prioritized.sort(key=lambda x: x[1], reverse=True)
        return [q[0] for q in prioritized]
    
    def _estimate_revision_time(self, decision: str) -> str:
        """Estimate revision timeline based on decision"""
        
        timelines = {
            "Accept with Minor Revisions": "1-2 tuần",
            "Major Revisions Required": "4-6 tuần", 
            "Reject and Resubmit": "2-3 tháng",
            "Reject": "Cần thiết kế lại hoàn toàn"
        }
        
        return timelines.get(decision, "4-6 tuần")
    
    def _generate_response_strategies(self, individual_reviews: List[Dict], consensus: Dict) -> Dict:
        """Generate strategies for responding to reviewer feedback"""
        
        strategies = {
            'immediate_actions': [],
            'revision_plan': [],
            'response_template': "",
            'defense_preparation': []
        }
        
        # Immediate actions based on consensus decision
        if consensus['consensus_decision'] == "Accept with Minor Revisions":
            strategies['immediate_actions'] = [
                "Address các minor concerns được raised bởi reviewers",
                "Clarify ambiguous points trong writing",
                "Enhance references và citations quality"
            ]
        elif consensus['consensus_decision'] == "Major Revisions Required":
            strategies['immediate_actions'] = [
                "Revise methodology section để address concerns",
                "Strengthen theoretical framework",
                "Rewrite các sections với major issues"
            ]
        
        # Detailed revision plan
        for review in individual_reviews:
            reviewer_name = review['reviewer_info']['name']
            for recommendation in review['recommendations'][:2]:  # Top 2 recommendations
                strategies['revision_plan'].append(f"{reviewer_name}: {recommendation}")
        
        # Response template
        strategies['response_template'] = self._create_response_template(individual_reviews, consensus)
        
        return strategies
    
    def _create_response_template(self, reviews: List[Dict], consensus: Dict) -> str:
        """Create template for responding to reviewers"""
        
        template = f"""# RESPONSE TO REVIEWERS

**Overall Assessment:** {consensus['consensus_decision']}
**Average Score:** {consensus['average_score']:.1f}/10

## Response to Individual Reviewers

"""
        
        for i, review in enumerate(reviews, 1):
            reviewer_info = review['reviewer_info']
            template += f"""### Response to {reviewer_info['name']} ({reviewer_info['expertise']})

**Reviewer Score:** {review['overall_score']:.1f}/10

**Our Response to Key Concerns:**

"""
            for j, question in enumerate(review['critical_questions'][:2], 1):
                template += f"""**Question {j}:** {question}

**Response:** [Tác giả cần điền response chi tiết vào đây]

"""
        
        template += """## Summary of Major Changes

1. [Liệt kê major changes made]
2. [Additional improvements]
3. [Clarifications added]

## Additional Improvements

- [Voluntary improvements beyond reviewer requests]
- [Enhanced methodology/analysis]
- [Improved presentation]

**Estimated completion time:** {timeline}
""".format(timeline=consensus['revision_timeline'])
        
        return template
    
    def _generate_defense_preparation(self, reviews: List[Dict]) -> Dict:
        """Generate defense preparation materials based on reviews"""
        
        # Collect all critical questions
        all_questions = []
        for review in reviews:
            for question in review['critical_questions']:
                all_questions.append({
                    'question': question,
                    'reviewer': review['reviewer_info']['name'],
                    'expertise': review['reviewer_info']['expertise']
                })
        
        # Generate potential follow-up questions
        follow_ups = [
            "Có thể explain methodology choice chi tiết hơn không?",
            "Alternative approaches nào khác đã được considered?",
            "Limitations của study này impact findings như thế nào?",
            "Future research directions từ findings này là gì?",
            "Practical implications có feasible để implement không?"
        ]
        
        # Prepare defense structure
        defense_structure = {
            'opening_statement': "Chuẩn bị 3-5 phút overview về key contributions",
            'key_findings_summary': "Highlight 3 main findings với evidence",
            'methodology_defense': "Justify research design choices với alternatives",
            'limitation_acknowledgment': "Proactive discussion về limitations",
            'contribution_emphasis': "Clear articulation của theoretical và practical contributions"
        }
        
        return {
            'anticipated_questions': all_questions,
            'follow_up_questions': follow_ups,
            'defense_structure': defense_structure,
            'preparation_timeline': "4-6 tuần preparation recommended",
            'practice_recommendations': [
                "Mock defense sessions với advisors",
                "Present findings tại conferences hoặc seminars", 
                "Prepare visual aids để support explanations",
                "Practice handling challenging questions diplomatically"
            ]
        }
    
    def _generate_review_summary(self, reviews: List[Dict], consensus: Dict) -> str:
        """Generate comprehensive review summary"""
        
        summary = f"""# TÓM TẮT PHẢN BIỆN HỘI ĐỒNG

## Kết quả đánh giá tổng thể

**Điểm trung bình:** {consensus['average_score']:.1f}/10 ({consensus['score_range']})
**Tính nhất quán:** {consensus['score_consistency']}
**Quyết định:** {consensus['consensus_decision']}
**Thời gian sửa chữa dự kiến:** {consensus['revision_timeline']}

## Đánh giá từng phản biện viên

"""
        
        for review in reviews:
            reviewer = review['reviewer_info']
            summary += f"""### {reviewer['name']} - {reviewer['expertise']}
- **Điểm số:** {review['overall_score']:.1f}/10
- **Quyết định:** {review['decision']}
- **Điểm mạnh chính:** {review['strengths'][0] if review['strengths'] else 'Không nêu cụ thể'}
- **Mối quan tâm chính:** {review['weaknesses'][0] if review['weaknesses'] else 'Không có'}

"""
        
        summary += f"""## Các vấn đề chung được nêu ra

**Điểm mạnh được công nhận:**
"""
        for strength in consensus['common_strengths']:
            summary += f"- {strength}\n"
        
        summary += f"""
**Mối quan tâm chung:**
"""
        for concern in consensus['common_concerns']:
            summary += f"- {concern}\n"
        
        summary += f"""
## Câu hỏi ưu tiên cần trả lời

"""
        for i, question in enumerate(consensus['priority_questions'], 1):
            summary += f"{i}. {question}\n"
        
        summary += f"""
## Khuyến nghị cho tác giả

1. **Ưu tiên cao:** Address các common concerns được multiple reviewers nêu ra
2. **Trung hạn:** Improve areas được individual reviewers focus
3. **Dài hạn:** Consider advanced methodologies để strengthen future research

## Chuẩn bị bảo vệ

- **Timeline chuẩn bị:** 4-6 tuần
- **Focus areas:** Methodology justification, theoretical contribution, practical implications
- **Practice needed:** Mock defense sessions và presentation skills

---

*Báo cáo được tạo tự động bởi AutoThesis Writer Academic Review System*
"""
        
        return summary

    def export_review_report(self, panel_review: Dict, topic: str, chapter_type: str) -> str:
        """Export complete review report for download"""
        
        report = f"""# BÁO CÁO PHẢN BIỆN HỘI ĐỒNG HỌC THUẬT

**Đề tài:** {topic}
**Chương được phản biện:** {chapter_type.title()}
**Ngày phản biện:** {datetime.now().strftime('%d/%m/%Y')}
**Số phản biện viên:** {len(panel_review['individual_reviews'])}

{panel_review['review_summary']}

## CHI TIẾT PHẢN BIỆN TỪNG THÀNH VIÊN

"""
        
        for review in panel_review['individual_reviews']:
            report += f"""
---

{review['detailed_comments']}

**Câu hỏi phản biện:**
"""
            for i, question in enumerate(review['critical_questions'], 1):
                report += f"{i}. {question}\n"
            
            report += f"""
**Khuyến nghị cải thiện:**
"""
            for i, rec in enumerate(review['recommendations'], 1):
                report += f"{i}. {rec}\n"
        
        report += f"""

## CHIẾN LƯỢC PHẢN HỒI

{panel_review['response_strategies']['response_template']}

## CHUẨN BỊ BẢO VỆ

**Cấu trúc bảo vệ được khuyến nghị:**
"""
        
        defense_prep = panel_review['defense_preparation']
        for key, value in defense_prep['defense_structure'].items():
            report += f"- **{key.replace('_', ' ').title()}:** {value}\n"
        
        report += f"""

**Timeline chuẩn bị:** {defense_prep['preparation_timeline']}

**Khuyến nghị luyện tập:**
"""
        for rec in defense_prep['practice_recommendations']:
            report += f"- {rec}\n"
        
        report += """

---

*Báo cáo này được tạo bởi AutoThesis Writer để hỗ trợ quá trình hoàn thiện luận văn tiến sĩ*
"""
        
        return report
