"""
Enhanced AI Panel Defense Simulator
Provides comprehensive academic peer review with detailed reviewer profiles,
formal defense simulation, and transcript generation.
"""
import random
from typing import Dict, List, Any
from datetime import datetime

class ReviewerProfile:
    """Academic reviewer profile with expertise and reviewing style"""
    
    def __init__(self, name: str, title: str, expertise: List[str], 
                 institution: str, style: str, experience_years: int):
        self.name = name
        self.title = title
        self.expertise = expertise
        self.institution = institution
        self.style = style  # "encouraging", "critical", "methodical", "innovative"
        self.experience_years = experience_years
        self.publications = self._generate_publications()
        
    def _generate_publications(self) -> List[str]:
        """Generate sample publications based on expertise"""
        base_topics = self.expertise[:2]  # First two areas
        publications = []
        
        for topic in base_topics:
            pub_count = min(self.experience_years // 3, 10)
            for i in range(pub_count):
                year = 2024 - random.randint(1, self.experience_years)
                title = f"Advanced research in {topic.lower()} methodology ({year})"
                publications.append(title)
        
        return publications[:8]  # Limit to 8 publications

class EnhancedPeerReviewPanel:
    """Enhanced peer review panel with detailed academic simulation"""
    
    def __init__(self):
        self.reviewer_profiles = self._create_reviewer_database()
        
    def _create_reviewer_database(self) -> Dict[str, List[ReviewerProfile]]:
        """Create comprehensive database of academic reviewers by field"""
        
        profiles = {
            "giáo dục": [
                ReviewerProfile(
                    "PGS.TS. Nguyễn Minh Anh", "Phó Giáo sư, Tiến sĩ",
                    ["Quản lý giáo dục", "Chính sách giáo dục", "Đánh giá giáo dục"],
                    "Đại học Sư phạm Hà Nội", "methodical", 25
                ),
                ReviewerProfile(
                    "TS. Trần Thị Bích", "Tiến sĩ",
                    ["Tâm lý giáo dục", "Phương pháp dạy học", "Công nghệ giáo dục"],
                    "Đại học Giáo dục Việt Nam", "encouraging", 15
                ),
                ReviewerProfile(
                    "GS.TS. Lê Văn Cường", "Giáo sư, Tiến sĩ",
                    ["Khoa học giáo dục", "Nghiên cứu giáo dục", "Quốc tế hóa giáo dục"],
                    "Đại học Quốc gia Hà Nội", "critical", 30
                )
            ],
            "kinh tế": [
                ReviewerProfile(
                    "PGS.TS. Phạm Minh Đức", "Phó Giáo sư, Tiến sĩ",
                    ["Kinh tế vi mô", "Phân tích chính sách", "Kinh tế lượng"],
                    "Đại học Kinh tế Quốc dân", "methodical", 20
                ),
                ReviewerProfile(
                    "TS. Hoàng Thị Lan", "Tiến sĩ",
                    ["Tài chính ngân hàng", "Quản trị rủi ro", "Kinh tế số"],
                    "Đại học Ngoại thương", "innovative", 12
                ),
                ReviewerProfile(
                    "GS.TS. Võ Thanh Nam", "Giáo sư, Tiến sĩ",
                    ["Kinh tế phát triển", "Kinh tế quốc tế", "Chính sách công"],
                    "Học viện Tài chính", "critical", 28
                )
            ],
            "y học": [
                ReviewerProfile(
                    "PGS.TS.BS. Nguyễn Văn An", "Phó Giáo sư, Tiến sĩ, Bác sĩ",
                    ["Y học lâm sàng", "Nghiên cứu y sinh học", "Dịch tễ học"],
                    "Đại học Y Hà Nội", "methodical", 22
                ),
                ReviewerProfile(
                    "TS.BS. Trần Thị Hoa", "Tiến sĩ, Bác sĩ",
                    ["Y học cộng đồng", "Chăm sóc sức khỏe", "Thống kê y học"],
                    "Đại học Y Dược TP.HCM", "encouraging", 18
                ),
                ReviewerProfile(
                    "GS.TS.BS. Lê Minh Khôi", "Giáo sư, Tiến sĩ, Bác sĩ",
                    ["Nghiên cứu y học", "Y học chứng cứ", "Đạo đức y học"],
                    "Đại học Y Dược Huế", "critical", 35
                )
            ],
            "kỹ thuật": [
                ReviewerProfile(
                    "PGS.TS. Bùi Văn Toàn", "Phó Giáo sư, Tiến sĩ",
                    ["Kỹ thuật phần mềm", "Trí tuệ nhân tạo", "Hệ thống thông tin"],
                    "Đại học Bách khoa Hà Nội", "innovative", 16
                ),
                ReviewerProfile(
                    "TS. Đặng Thị Mai", "Tiến sĩ",
                    ["Mạng máy tính", "An toàn thông tin", "Blockchain"],
                    "Đại học Công nghệ", "methodical", 14
                ),
                ReviewerProfile(
                    "GS.TS. Phạm Quang Dũng", "Giáo sư, Tiến sĩ",
                    ["Kỹ thuật điện", "Tự động hóa", "IoT"],
                    "Đại học Bách khoa TP.HCM", "critical", 32
                )
            ]
        }
        
        return profiles

    def select_review_panel(self, field: str, num_reviewers: int = 3) -> List[ReviewerProfile]:
        """Select appropriate reviewers for the field"""
        
        # Normalize field name
        field_lower = field.lower()
        field_key = None
        
        for key in self.reviewer_profiles.keys():
            if key in field_lower or field_lower in key:
                field_key = key
                break
        
        if not field_key:
            # Default to education if field not found
            field_key = "giáo dục"
        
        available_reviewers = self.reviewer_profiles[field_key]
        
        # Ensure we have enough reviewers
        if len(available_reviewers) < num_reviewers:
            # Add reviewers from other fields if needed
            all_reviewers = []
            for profiles in self.reviewer_profiles.values():
                all_reviewers.extend(profiles)
            available_reviewers = all_reviewers
        
        # Select reviewers with different styles
        selected = []
        styles_used = set()
        
        for reviewer in available_reviewers:
            if len(selected) >= num_reviewers:
                break
            if reviewer.style not in styles_used or len(available_reviewers) <= num_reviewers:
                selected.append(reviewer)
                styles_used.add(reviewer.style)
        
        return selected[:num_reviewers]

    def conduct_defense_simulation(self, thesis_content: str, topic: str, 
                                 field: str, num_reviewers: int = 3) -> Dict[str, Any]:
        """Conduct complete defense simulation with dialogue transcript"""
        
        panel = self.select_review_panel(field, num_reviewers)
        
        # Generate defense session
        defense_session = {
            "session_info": {
                "date": datetime.now().strftime("%d/%m/%Y"),
                "time": "14:00 - 16:00",
                "topic": topic,
                "field": field,
                "panel_size": len(panel)
            },
            "panel_members": [],
            "defense_transcript": [],
            "individual_evaluations": [],
            "panel_decision": {},
            "formal_minutes": ""
        }
        
        # Add panel member details
        for reviewer in panel:
            defense_session["panel_members"].append({
                "name": reviewer.name,
                "title": reviewer.title,
                "institution": reviewer.institution,
                "expertise": reviewer.expertise,
                "experience": f"{reviewer.experience_years} năm",
                "role": "Thành viên hội đồng" if reviewer != panel[0] else "Chủ tịch hội đồng"
            })
        
        # Generate defense dialogue
        transcript = self._generate_defense_dialogue(panel, topic, thesis_content)
        defense_session["defense_transcript"] = transcript
        
        # Generate individual evaluations
        evaluations = self._generate_individual_evaluations(panel, thesis_content, topic)
        defense_session["individual_evaluations"] = evaluations
        
        # Generate panel decision
        decision = self._generate_panel_decision(evaluations)
        defense_session["panel_decision"] = decision
        
        # Generate formal minutes
        minutes = self._generate_formal_minutes(defense_session)
        defense_session["formal_minutes"] = minutes
        
        return defense_session

    def _generate_defense_dialogue(self, panel: List[ReviewerProfile], 
                                 topic: str, content: str) -> List[Dict[str, str]]:
        """Generate realistic defense dialogue"""
        
        dialogue = []
        chair = panel[0]
        
        # Opening
        dialogue.append({
            "speaker": chair.name,
            "role": "Chủ tịch hội đồng",
            "timestamp": "14:00",
            "content": f"Hội đồng chính thức bắt đầu phiên bảo vệ luận văn với đề tài: '{topic}'. Mời nghiên cứu sinh trình bày tóm tắt nghiên cứu trong 15 phút."
        })
        
        dialogue.append({
            "speaker": "Nghiên cứu sinh",
            "role": "Ứng viên",
            "timestamp": "14:02",
            "content": "Kính thưa hội đồng, em xin trình bày tóm tắt nghiên cứu về đề tài này. Nghiên cứu tập trung giải quyết vấn đề... [Trình bày 15 phút]"
        })
        
        # Questions from each panel member
        question_time = 14.17  # 14:17
        for i, reviewer in enumerate(panel):
            questions = self._generate_reviewer_questions(reviewer, topic, content)
            
            for j, question in enumerate(questions[:2]):  # 2 questions per reviewer
                dialogue.append({
                    "speaker": reviewer.name,
                    "role": f"Phản biện {i+1}",
                    "timestamp": f"{int(question_time)}:{int((question_time % 1) * 60):02d}",
                    "content": question
                })
                
                dialogue.append({
                    "speaker": "Nghiên cứu sinh",
                    "role": "Ứng viên",
                    "timestamp": f"{int(question_time + 0.05)}:{int(((question_time + 0.05) % 1) * 60):02d}",
                    "content": self._generate_answer(question, reviewer.style)
                })
                
                question_time += 0.1
        
        # Closing
        dialogue.append({
            "speaker": chair.name,
            "role": "Chủ tịch hội đồng",
            "timestamp": f"{int(question_time + 0.15)}:{int(((question_time + 0.15) % 1) * 60):02d}",
            "content": "Hội đồng sẽ nghỉ 15 phút để thảo luận và đưa ra quyết định cuối cùng."
        })
        
        return dialogue

    def _generate_reviewer_questions(self, reviewer: ReviewerProfile, 
                                   topic: str, content: str) -> List[str]:
        """Generate questions based on reviewer's style and expertise"""
        
        if reviewer.style == "critical":
            return [
                f"Anh/chị có thể giải thích rõ hơn về tính mới và đóng góp khoa học của nghiên cứu này so với các nghiên cứu đã công bố trong lĩnh vực {reviewer.expertise[0].lower()}?",
                f"Phương pháp nghiên cứu được sử dụng có đảm bảo tính khách quan và độ tin cậy? Tại sao không sử dụng phương pháp {reviewer.expertise[1].lower()}?",
                "Kết quả nghiên cứu có thể áp dụng trong thực tế như thế nào? Có bằng chứng cụ thể nào không?"
            ]
        elif reviewer.style == "methodical":
            return [
                f"Quy trình thu thập và phân tích dữ liệu có tuân thủ đúng chuẩn khoa học trong lĩnh vực {reviewer.expertise[0].lower()} không?",
                "Anh/chị có thể trình bày chi tiết hơn về thiết kế nghiên cứu và cách kiểm soát các biến số?",
                "Các hạn chế của nghiên cứu và hướng phát triển tiếp theo được xác định như thế nào?"
            ]
        elif reviewer.style == "encouraging":
            return [
                f"Nghiên cứu thể hiện hiểu biết sâu sắc về {reviewer.expertise[0].lower()}. Anh/chị có thể chia sẻ thêm về quá trình nghiên cứu?",
                "Những khó khăn chính trong quá trình thực hiện nghiên cứu và cách giải quyết?",
                "Nghiên cứu này có thể mở ra những hướng nghiên cứu mới nào trong tương lai?"
            ]
        else:  # innovative
            return [
                f"Nghiên cứu có đưa ra những góc nhìn mới về {reviewer.expertise[0].lower()} không? Điểm đột phá ở đâu?",
                "Có thể áp dụng công nghệ hoặc phương pháp tiên tiến nào để nâng cao hiệu quả nghiên cứu?",
                "Nghiên cứu này có tiềm năng phát triển thành sản phẩm hoặc giải pháp thực tế không?"
            ]

    def _generate_answer(self, question: str, reviewer_style: str) -> str:
        """Generate appropriate answer based on question type"""
        
        if "phương pháp" in question.lower():
            return "Em đã lựa chọn phương pháp này dựa trên đặc điểm của đối tượng nghiên cứu và tham khảo các nghiên cứu quốc tế tương tự. Em đã thực hiện pilot test để đảm bảo tính khả thi..."
        elif "tính mới" in question.lower() or "đóng góp" in question.lower():
            return "Nghiên cứu của em góp phần làm rõ thêm về lý thuyết hiện có và đưa ra mô hình mới phù hợp với bối cảnh Việt Nam. Kết quả cho thấy..."
        elif "thực tế" in question.lower() or "ứng dụng" in question.lower():
            return "Kết quả nghiên cứu có thể được áp dụng trực tiếp trong thực tế thông qua việc xây dựng quy trình chuẩn và hướng dẫn thực hiện cụ thể..."
        else:
            return "Cảm ơn thầy/cô đã đưa ra câu hỏi quan trọng. Em xin trình bày như sau... [Trả lời chi tiết với dẫn chứng cụ thể]"

    def _generate_individual_evaluations(self, panel: List[ReviewerProfile], 
                                       content: str, topic: str) -> List[Dict[str, Any]]:
        """Generate individual evaluation from each panel member"""
        
        evaluations = []
        
        for reviewer in panel:
            # Generate score based on reviewer style
            if reviewer.style == "critical":
                base_score = random.uniform(7.0, 8.5)
            elif reviewer.style == "encouraging":
                base_score = random.uniform(8.0, 9.2)
            elif reviewer.style == "methodical":
                base_score = random.uniform(7.5, 8.8)
            else:  # innovative
                base_score = random.uniform(7.8, 9.0)
            
            evaluation = {
                "reviewer": {
                    "name": reviewer.name,
                    "title": reviewer.title,
                    "institution": reviewer.institution
                },
                "overall_score": round(base_score, 1),
                "detailed_scores": {
                    "Tính khoa học của đề tài": round(base_score + random.uniform(-0.3, 0.3), 1),
                    "Phương pháp nghiên cứu": round(base_score + random.uniform(-0.2, 0.2), 1),
                    "Kết quả và thảo luận": round(base_score + random.uniform(-0.4, 0.4), 1),
                    "Ý nghĩa thực tiễn": round(base_score + random.uniform(-0.3, 0.5), 1),
                    "Trình bày và bảo vệ": round(base_score + random.uniform(-0.2, 0.3), 1)
                },
                "comments": self._generate_reviewer_comments(reviewer, base_score),
                "recommendation": "Đạt" if base_score >= 7.0 else "Không đạt"
            }
            
            evaluations.append(evaluation)
        
        return evaluations

    def _generate_reviewer_comments(self, reviewer: ReviewerProfile, score: float) -> str:
        """Generate comments based on reviewer style and score"""
        
        if reviewer.style == "critical":
            if score >= 8.0:
                return f"Nghiên cứu thể hiện tính nghiêm túc khoa học cao. Phương pháp {reviewer.expertise[0].lower()} được áp dụng phù hợp. Tuy nhiên, cần làm rõ hơn về tính ứng dụng trong thực tế."
            else:
                return f"Nghiên cứu có cơ sở khoa học nhưng cần củng cố thêm về mặt lý thuyết và phương pháp. Đề xuất bổ sung thêm nghiên cứu so sánh với các mô hình quốc tế."
        
        elif reviewer.style == "encouraging":
            return f"Nghiên cứu thể hiện nỗ lực và sự hiểu biết tốt về lĩnh vực {reviewer.expertise[0].lower()}. Kết quả có ý nghĩa thực tế cao. Khuyến khích tiếp tục phát triển nghiên cứu theo hướng này."
        
        elif reviewer.style == "methodical":
            if score >= 8.0:
                return f"Thiết kế nghiên cứu chặt chẽ, quy trình thực hiện đúng chuẩn khoa học. Phân tích dữ liệu {reviewer.expertise[1].lower()} được thực hiện tốt. Báo cáo trình bày logic và rõ ràng."
            else:
                return f"Cần hoàn thiện thêm về phương pháp nghiên cứu và cách trình bày kết quả. Đề xuất bổ sung thêm phân tích thống kê chi tiết."
        
        else:  # innovative
            return f"Nghiên cứu mang tính đột phá trong cách tiếp cận {reviewer.expertise[0].lower()}. Có tiềm năng ứng dụng cao và mở ra hướng nghiên cứu mới. Đánh giá tích cực về tính sáng tạo."

    def _generate_panel_decision(self, evaluations: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Generate final panel decision"""
        
        scores = [eval["overall_score"] for eval in evaluations]
        average_score = round(sum(scores) / len(scores), 1)
        
        # Determine result
        passing_votes = sum(1 for eval in evaluations if eval["recommendation"] == "Đạt")
        total_votes = len(evaluations)
        
        decision = {
            "average_score": average_score,
            "individual_scores": scores,
            "passing_votes": f"{passing_votes}/{total_votes}",
            "result": "ĐẠT" if passing_votes >= total_votes // 2 + 1 else "KHÔNG ĐẠT",
            "classification": self._get_classification(average_score),
            "conditions": [],
            "panel_comments": ""
        }
        
        # Add conditions based on score
        if average_score >= 8.5:
            decision["panel_comments"] = "Hội đồng đánh giá cao chất lượng nghiên cứu. Nghiên cứu sinh đã thể hiện kiến thức vững vàng và khả năng nghiên cứu độc lập tốt."
        elif average_score >= 7.5:
            decision["panel_comments"] = "Nghiên cứu đạt yêu cầu với một số điểm cần hoàn thiện. Hội đồng đề xuất nghiên cứu sinh tiếp tục phát triển nghiên cứu theo các hướng đã thảo luận."
            decision["conditions"] = [
                "Hoàn thiện phần thảo luận kết quả",
                "Bổ sung tài liệu tham khảo gần đây",
                "Làm rõ hơn về ý nghĩa thực tiễn"
            ]
        else:
            decision["panel_comments"] = "Nghiên cứu cần được hoàn thiện đáng kể trước khi có thể đạt yêu cầu."
            decision["conditions"] = [
                "Hoàn thiện lại phương pháp nghiên cứu",
                "Thu thập thêm dữ liệu",
                "Tăng cường phân tích lý thuyết"
            ]
        
        return decision

    def _get_classification(self, score: float) -> str:
        """Get degree classification based on score"""
        if score >= 9.0:
            return "Xuất sắc"
        elif score >= 8.5:
            return "Giỏi"
        elif score >= 8.0:
            return "Khá giỏi"
        elif score >= 7.0:
            return "Khá"
        else:
            return "Trung bình"

    def _generate_formal_minutes(self, session: Dict[str, Any]) -> str:
        """Generate formal defense minutes document"""
        
        minutes = f"""
BIÊN BẢN BẢO VỆ LUẬN VĂN TIẾN SĨ

I. THÔNG TIN CHUNG
- Ngày bảo vệ: {session['session_info']['date']}
- Thời gian: {session['session_info']['time']}
- Đề tài: {session['session_info']['topic']}
- Lĩnh vực: {session['session_info']['field']}

II. THÀNH PHẦN HỘI ĐỒNG
"""
        
        for i, member in enumerate(session['panel_members']):
            minutes += f"""
{i+1}. {member['name']} - {member['title']}
   - Cơ quan: {member['institution']}
   - Vai trò: {member['role']}
   - Kinh nghiệm: {member['experience']}
"""
        
        minutes += f"""
III. DIỄN BIẾN BUỔI BẢO VỆ
- Nghiên cứu sinh trình bày tóm tắt luận văn (15 phút)
- Hội đồng đặt câu hỏi và thảo luận ({len(session['defense_transcript']) - 3} câu hỏi)
- Nghiên cứu sinh trả lời các câu hỏi của hội đồng

IV. ĐÁNH GIÁ CỦA HỘI ĐỒNG
"""
        
        for eval in session['individual_evaluations']:
            minutes += f"""
- {eval['reviewer']['name']}: {eval['overall_score']}/10 điểm
  Nhận xét: {eval['comments'][:100]}...
"""
        
        decision = session['panel_decision']
        minutes += f"""
V. QUYẾT ĐỊNH CỦA HỘI ĐỒNG
- Điểm trung bình: {decision['average_score']}/10
- Kết quả bỏ phiếu: {decision['passing_votes']}
- Quyết định: {decision['result']}
- Xếp loại: {decision['classification']}

VI. KIẾN NGHỊ VÀ YÊU CẦU
{chr(10).join(f'- {condition}' for condition in decision['conditions'])}

VII. KẾT LUẬN
{decision['panel_comments']}

Biên bản được lập ngày {session['session_info']['date']}

CHỦ TỊCH HỘI ĐỒNG
{session['panel_members'][0]['name']}
"""
        
        return minutes

    def export_defense_report(self, session: Dict[str, Any], format: str = "full") -> str:
        """Export comprehensive defense report"""
        
        if format == "transcript":
            # Export dialogue transcript only
            report = f"BIÊN BẢN PHIÊN BẢO VỆ\n{'='*50}\n\n"
            
            for dialogue in session['defense_transcript']:
                report += f"[{dialogue['timestamp']}] {dialogue['speaker']} ({dialogue['role']}):\n"
                report += f"{dialogue['content']}\n\n"
            
            return report
        
        elif format == "evaluations":
            # Export evaluation details only
            report = f"BÁO CÁO ĐÁNH GIÁ CHI TIẾT\n{'='*50}\n\n"
            
            for eval in session['individual_evaluations']:
                report += f"\nĐÁNH GIÁ CỦA {eval['reviewer']['name']}\n{'-'*30}\n"
                report += f"Điểm tổng thể: {eval['overall_score']}/10\n\n"
                
                report += "Chi tiết điểm số:\n"
                for criterion, score in eval['detailed_scores'].items():
                    report += f"- {criterion}: {score}/10\n"
                
                report += f"\nNhận xét: {eval['comments']}\n"
                report += f"Khuyến nghị: {eval['recommendation']}\n\n"
            
            return report
        
        else:  # full report
            return session['formal_minutes']
