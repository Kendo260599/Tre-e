import re
from typing import Dict, List, Optional, Tuple
from datetime import datetime

class TheoreticalFrameworkGenerator:
    """
    Automatically builds theoretical frameworks and research models based on topic analysis
    """
    
    def __init__(self):
        self.theoretical_frameworks = self._initialize_frameworks()
        self.research_paradigms = self._initialize_paradigms()
        
    def _initialize_frameworks(self) -> Dict:
        """Initialize comprehensive theoretical frameworks database"""
        return {
            'psychology': {
                'motivation': ['Self-Determination Theory', 'Achievement Goal Theory', 'Expectancy-Value Theory'],
                'learning': ['Social Cognitive Theory', 'Constructivist Learning Theory', 'Experiential Learning Theory'],
                'behavior': ['Theory of Planned Behavior', 'Social Learning Theory', 'Behavioral Economics'],
                'personality': ['Big Five Model', 'Myers-Briggs Theory', 'Trait Theory'],
                'cognition': ['Cognitive Load Theory', 'Dual Process Theory', 'Information Processing Theory']
            },
            'business': {
                'management': ['Systems Theory', 'Contingency Theory', 'Resource-Based View'],
                'marketing': ['Consumer Behavior Theory', 'Relationship Marketing Theory', 'Brand Equity Theory'],
                'finance': ['Modern Portfolio Theory', 'Efficient Market Hypothesis', 'Behavioral Finance Theory'],
                'strategy': ['Porter\'s Five Forces', 'Dynamic Capabilities Theory', 'Stakeholder Theory'],
                'leadership': ['Transformational Leadership Theory', 'Situational Leadership Theory', 'Leader-Member Exchange Theory']
            },
            'education': {
                'pedagogy': ['Constructivism', 'Bloom\'s Taxonomy', 'Multiple Intelligence Theory'],
                'curriculum': ['Tyler Model', 'Taba Model', 'Constructivist Curriculum Theory'],
                'assessment': ['Authentic Assessment Theory', 'Formative Assessment Theory', 'Competency-Based Assessment'],
                'technology': ['Technology Acceptance Model', 'SAMR Model', 'TPACK Framework'],
                'student_development': ['Student Development Theory', 'Experiential Learning Theory', 'Self-Regulated Learning Theory']
            },
            'technology': {
                'adoption': ['Technology Acceptance Model', 'Diffusion of Innovation Theory', 'Unified Theory of Acceptance'],
                'design': ['Human-Computer Interaction Theory', 'User Experience Theory', 'Design Thinking Framework'],
                'systems': ['Systems Theory', 'Socio-Technical Systems Theory', 'Actor-Network Theory'],
                'innovation': ['Innovation Diffusion Theory', 'Disruptive Innovation Theory', 'Open Innovation Theory']
            },
            'health': {
                'behavior': ['Health Belief Model', 'Theory of Planned Behavior', 'Social Cognitive Theory'],
                'promotion': ['Ecological Model', 'Transtheoretical Model', 'Community Organization Theory'],
                'psychology': ['Stress and Coping Theory', 'Self-Efficacy Theory', 'Biopsychosocial Model'],
                'care': ['Patient-Centered Care Theory', 'Care Transition Theory', 'Quality Improvement Theory']
            }
        }
    
    def _initialize_paradigms(self) -> Dict:
        """Initialize research paradigms and methodological approaches"""
        return {
            'positivist': {
                'philosophy': 'Objective reality exists and can be measured',
                'methodology': 'Quantitative methods, experiments, surveys',
                'suitable_for': ['causal relationships', 'hypothesis testing', 'statistical analysis']
            },
            'interpretivist': {
                'philosophy': 'Reality is socially constructed and subjective',
                'methodology': 'Qualitative methods, interviews, ethnography',
                'suitable_for': ['understanding meaning', 'cultural analysis', 'lived experiences']
            },
            'pragmatist': {
                'philosophy': 'Focus on practical consequences and mixed methods',
                'methodology': 'Mixed methods, action research, case studies',
                'suitable_for': ['complex problems', 'practical solutions', 'real-world applications']
            },
            'critical': {
                'philosophy': 'Research should challenge and transform society',
                'methodology': 'Critical analysis, participatory research, emancipatory methods',
                'suitable_for': ['social justice', 'power structures', 'systemic change']
            }
        }
    
    def generate_theoretical_framework(self, topic: str, field: str, research_approach: str) -> Dict:
        """
        Generate comprehensive theoretical framework based on topic analysis
        """
        # Analyze topic to identify key concepts
        key_concepts = self._extract_key_concepts(topic, field)
        
        # Select appropriate theories
        recommended_theories = self._select_theories(key_concepts, field, research_approach)
        
        # Build conceptual model
        conceptual_model = self._build_conceptual_model(key_concepts, recommended_theories, field)
        
        # Generate research hypotheses
        hypotheses = self._generate_hypotheses(conceptual_model, research_approach)
        
        # Create theoretical justification
        theoretical_justification = self._create_theoretical_justification(recommended_theories, topic, field)
        
        return {
            'key_concepts': key_concepts,
            'recommended_theories': recommended_theories,
            'conceptual_model': conceptual_model,
            'hypotheses': hypotheses,
            'theoretical_justification': theoretical_justification,
            'research_paradigm': self._recommend_paradigm(research_approach, field),
            'variables': self._identify_variables(conceptual_model),
            'framework_diagram': self._generate_framework_description(conceptual_model)
        }
    
    def _extract_key_concepts(self, topic: str, field: str) -> List[str]:
        """Extract key concepts from research topic"""
        
        # Define concept mappings by field
        concept_keywords = {
            'psychology': {
                'motivation': ['động lực', 'khuyến khích', 'thúc đẩy', 'motivation', 'incentive'],
                'learning': ['học tập', 'học', 'giáo dục', 'learning', 'education'],
                'behavior': ['hành vi', 'cách thức', 'behavior', 'conduct'],
                'satisfaction': ['hài lòng', 'thỏa mãn', 'satisfaction'],
                'performance': ['hiệu suất', 'kết quả', 'performance', 'achievement'],
                'attitude': ['thái độ', 'quan điểm', 'attitude', 'perception']
            },
            'business': {
                'management': ['quản lý', 'quản trị', 'management', 'administration'],
                'leadership': ['lãnh đạo', 'leadership'],
                'performance': ['hiệu quả', 'năng suất', 'performance', 'productivity'],
                'strategy': ['chiến lược', 'strategy', 'strategic'],
                'innovation': ['đổi mới', 'sáng tạo', 'innovation', 'creativity'],
                'quality': ['chất lượng', 'quality']
            },
            'education': {
                'teaching': ['giảng dạy', 'teaching', 'instruction'],
                'learning': ['học tập', 'learning'],
                'curriculum': ['chương trình', 'curriculum'],
                'assessment': ['đánh giá', 'assessment', 'evaluation'],
                'technology': ['công nghệ', 'technology', 'digital'],
                'student': ['sinh viên', 'học sinh', 'student']
            },
            'technology': {
                'adoption': ['áp dụng', 'chấp nhận', 'adoption', 'acceptance'],
                'innovation': ['đổi mới', 'innovation'],
                'digital': ['số hóa', 'digital', 'digitalization'],
                'system': ['hệ thống', 'system'],
                'user': ['người dùng', 'user']
            }
        }
        
        identified_concepts = []
        topic_lower = topic.lower()
        
        field_concepts = concept_keywords.get(field, {})
        for concept, keywords in field_concepts.items():
            if any(keyword in topic_lower for keyword in keywords):
                identified_concepts.append(concept)
        
        # Ensure at least 3-5 key concepts
        if len(identified_concepts) < 3:
            # Add common concepts based on field
            default_concepts = {
                'psychology': ['behavior', 'attitude', 'performance'],
                'business': ['performance', 'management', 'quality'],
                'education': ['learning', 'teaching', 'student'],
                'technology': ['adoption', 'system', 'user']
            }
            identified_concepts.extend(default_concepts.get(field, ['performance', 'behavior', 'satisfaction']))
        
        return list(set(identified_concepts[:5]))  # Limit to 5 key concepts
    
    def _select_theories(self, concepts: List[str], field: str, research_approach: str) -> List[Dict]:
        """Select appropriate theories based on concepts and field"""
        
        theories = []
        field_frameworks = self.theoretical_frameworks.get(field, {})
        
        for concept in concepts:
            if concept in field_frameworks:
                theory_list = field_frameworks[concept]
                # Select 1-2 theories per concept
                for theory in theory_list[:2]:
                    theories.append({
                        'name': theory,
                        'concept': concept,
                        'description': self._get_theory_description(theory, field),
                        'relevance': self._assess_theory_relevance(theory, concept, research_approach)
                    })
        
        # Sort by relevance and select top theories
        theories.sort(key=lambda x: x['relevance'], reverse=True)
        return theories[:4]  # Limit to 4 main theories
    
    def _get_theory_description(self, theory: str, field: str) -> str:
        """Get detailed description of theoretical framework"""
        
        theory_descriptions = {
            'Technology Acceptance Model': {
                'description': 'Mô hình chấp nhận công nghệ (TAM) giải thích cách người dùng chấp nhận và sử dụng công nghệ dựa trên perceived usefulness và perceived ease of use.',
                'key_constructs': ['Perceived Usefulness', 'Perceived Ease of Use', 'Attitude', 'Behavioral Intention'],
                'application': 'Nghiên cứu việc chấp nhận công nghệ mới trong tổ chức và cá nhân'
            },
            'Social Cognitive Theory': {
                'description': 'Lý thuyết nhận thức xã hội của Bandura nhấn mạnh tương tác ba chiều giữa yếu tố cá nhân, hành vi và môi trường.',
                'key_constructs': ['Self-efficacy', 'Observational Learning', 'Outcome Expectations', 'Self-regulation'],
                'application': 'Nghiên cứu học tập, thay đổi hành vi và phát triển kỹ năng'
            },
            'Theory of Planned Behavior': {
                'description': 'Lý thuyết hành vi có kế hoạch giải thích hành vi thông qua attitude, subjective norms và perceived behavioral control.',
                'key_constructs': ['Attitude', 'Subjective Norms', 'Perceived Behavioral Control', 'Behavioral Intention'],
                'application': 'Dự đoán và giải thích hành vi có ý thức của con người'
            },
            'Self-Determination Theory': {
                'description': 'Lý thuyết tự quyết định tập trung vào ba nhu cầu tâm lý cơ bản: autonomy, competence và relatedness.',
                'key_constructs': ['Autonomy', 'Competence', 'Relatedness', 'Intrinsic Motivation'],
                'application': 'Nghiên cứu động lực, engagement và well-being'
            }
        }
        
        return theory_descriptions.get(theory, {
            'description': f'Lý thuyết {theory} cung cấp framework lý thuyết quan trọng trong lĩnh vực {field}.',
            'key_constructs': ['Construct 1', 'Construct 2', 'Construct 3'],
            'application': f'Ứng dụng trong nghiên cứu {field}'
        })
    
    def _assess_theory_relevance(self, theory: str, concept: str, research_approach: str) -> float:
        """Assess relevance of theory to research context"""
        
        # Base relevance score
        relevance = 0.7
        
        # Boost for common theories
        popular_theories = ['Technology Acceptance Model', 'Social Cognitive Theory', 'Theory of Planned Behavior']
        if theory in popular_theories:
            relevance += 0.2
        
        # Adjust for research approach
        if research_approach == 'quantitative':
            quantitative_friendly = ['Technology Acceptance Model', 'Theory of Planned Behavior', 'Self-Determination Theory']
            if theory in quantitative_friendly:
                relevance += 0.1
        
        return min(1.0, relevance)
    
    def _build_conceptual_model(self, concepts: List[str], theories: List[Dict], field: str) -> Dict:
        """Build conceptual research model with variables and relationships"""
        
        # Identify variable types based on concepts
        independent_vars = []
        dependent_vars = []
        mediating_vars = []
        moderating_vars = []
        
        # Common variable mappings
        var_mappings = {
            'psychology': {
                'independent': ['motivation', 'attitude', 'self_efficacy'],
                'dependent': ['performance', 'satisfaction', 'behavior'],
                'mediating': ['engagement', 'commitment'],
                'moderating': ['experience', 'demographics']
            },
            'business': {
                'independent': ['leadership', 'management_practices', 'organizational_culture'],
                'dependent': ['performance', 'productivity', 'innovation'],
                'mediating': ['employee_satisfaction', 'engagement'],
                'moderating': ['firm_size', 'industry_type']
            },
            'education': {
                'independent': ['teaching_method', 'technology_use', 'curriculum_design'],
                'dependent': ['learning_outcomes', 'student_satisfaction', 'academic_performance'],
                'mediating': ['student_engagement', 'motivation'],
                'moderating': ['student_characteristics', 'learning_environment']
            },
            'technology': {
                'independent': ['system_quality', 'information_quality', 'service_quality'],
                'dependent': ['user_satisfaction', 'system_usage', 'performance_impact'],
                'mediating': ['perceived_usefulness', 'perceived_ease_of_use'],
                'moderating': ['user_experience', 'organizational_support']
            }
        }
        
        field_vars = var_mappings.get(field, var_mappings['business'])
        
        # Map concepts to variable types
        for concept in concepts:
            if concept in ['motivation', 'leadership', 'teaching', 'system']:
                independent_vars.append(concept)
            elif concept in ['performance', 'satisfaction', 'learning', 'usage']:
                dependent_vars.append(concept)
            else:
                mediating_vars.append(concept)
        
        # Ensure we have at least one of each type
        if not independent_vars:
            independent_vars = field_vars['independent'][:2]
        if not dependent_vars:
            dependent_vars = field_vars['dependent'][:2]
        if not mediating_vars:
            mediating_vars = field_vars['mediating'][:1]
        
        moderating_vars = field_vars['moderating'][:1]
        
        return {
            'independent_variables': independent_vars,
            'dependent_variables': dependent_vars,
            'mediating_variables': mediating_vars,
            'moderating_variables': moderating_vars,
            'relationships': self._define_relationships(independent_vars, dependent_vars, mediating_vars),
            'theoretical_basis': [theory['name'] for theory in theories]
        }
    
    def _define_relationships(self, independent: List[str], dependent: List[str], mediating: List[str]) -> List[Dict]:
        """Define relationships between variables"""
        
        relationships = []
        
        # Direct relationships (IV -> DV)
        for iv in independent:
            for dv in dependent:
                relationships.append({
                    'from': iv,
                    'to': dv,
                    'type': 'direct',
                    'hypothesis': f'H{len(relationships)+1}: {iv.title()} có ảnh hưởng tích cực đến {dv.title()}'
                })
        
        # Mediated relationships (IV -> MV -> DV)
        if mediating:
            for iv in independent:
                for mv in mediating:
                    for dv in dependent:
                        relationships.append({
                            'from': iv,
                            'to': dv,
                            'through': mv,
                            'type': 'mediated',
                            'hypothesis': f'H{len(relationships)+1}: {mv.title()} đóng vai trò trung gian trong mối quan hệ giữa {iv.title()} và {dv.title()}'
                        })
        
        return relationships[:6]  # Limit to 6 main relationships
    
    def _generate_hypotheses(self, model: Dict, research_approach: str) -> List[str]:
        """Generate research hypotheses based on conceptual model"""
        
        hypotheses = []
        
        for relationship in model['relationships']:
            hypotheses.append(relationship['hypothesis'])
        
        # Add additional hypotheses based on research approach
        if research_approach == 'quantitative':
            hypotheses.append(f"H{len(hypotheses)+1}: Các yếu tố trong mô hình giải thích đáng kể variance trong biến phụ thuộc")
        
        return hypotheses
    
    def _create_theoretical_justification(self, theories: List[Dict], topic: str, field: str) -> str:
        """Create comprehensive theoretical justification"""
        
        justification = f"""## KHUNG LÝ THUYẾT VÀ CƠ SỞ LÝ LUẬN

### 1. Tổng quan khung lý thuyết

Nghiên cứu về "{topic}" trong lĩnh vực {field} đòi hỏi một khung lý thuyết đa chiều để giải thích các mối quan hệ phức tạp giữa các yếu tố. Dựa trên phân tích tài liệu và bản chất của vấn đề nghiên cứu, khung lý thuyết được xây dựng dựa trên {len(theories)} lý thuyết chính:

"""
        
        for i, theory in enumerate(theories, 1):
            theory_desc = self._get_theory_description(theory['name'], field)
            justification += f"""### {i}.{i}. {theory['name']}

{theory_desc['description']}

**Các khái niệm chính:**
"""
            for construct in theory_desc['key_constructs']:
                justification += f"- **{construct}**: Vai trò quan trọng trong việc giải thích {theory['concept']}\n"
            
            justification += f"""
**Ứng dụng trong nghiên cứu:** {theory_desc['application']}

**Tính phù hợp:** Lý thuyết này phù hợp với nghiên cứu hiện tại vì khả năng giải thích {theory['concept']} trong bối cảnh {field}.

"""
        
        justification += """### Tích hợp các lý thuyết

Việc tích hợp các lý thuyết trên tạo ra một khung lý thuyết toàn diện, giúp:
- Giải thích các mối quan hệ nhân quả giữa các biến nghiên cứu
- Cung cấp cơ sở lý luận vững chắc cho các giả thuyết nghiên cứu
- Đảm bảo tính học thuật và độ tin cậy của nghiên cứu
- Góp phần mở rộng hiểu biết trong lĩnh vực nghiên cứu

### Đóng góp lý thuyết dự kiến

Nghiên cứu này dự kiến đóng góp vào việc:
1. Mở rộng và kiểm chứng các lý thuyết hiện có trong bối cảnh mới
2. Khám phá các mối quan hệ mới giữa các biến số
3. Cung cấp bằng chứng thực nghiệm cho việc ứng dụng lý thuyết
4. Đề xuất các điều chỉnh hoặc mở rộng lý thuyết phù hợp với bối cảnh nghiên cứu
"""
        
        return justification
    
    def _recommend_paradigm(self, research_approach: str, field: str) -> Dict:
        """Recommend research paradigm based on approach and field"""
        
        paradigm_mapping = {
            'quantitative': 'positivist',
            'qualitative': 'interpretivist',
            'mixed_methods': 'pragmatist'
        }
        
        recommended_paradigm = paradigm_mapping.get(research_approach, 'pragmatist')
        return {
            'paradigm': recommended_paradigm,
            'details': self.research_paradigms[recommended_paradigm],
            'justification': f'Paradigm {recommended_paradigm} phù hợp với nghiên cứu {research_approach} trong lĩnh vực {field}'
        }
    
    def _identify_variables(self, model: Dict) -> Dict:
        """Identify and categorize all research variables"""
        
        return {
            'independent': {
                'variables': model['independent_variables'],
                'definition': 'Các biến độc lập - yếu tố nguyên nhân được giả định tác động đến biến phụ thuộc',
                'measurement': 'Đo lường thông qua thang đo đã được validate hoặc phát triển mới'
            },
            'dependent': {
                'variables': model['dependent_variables'],
                'definition': 'Các biến phụ thuộc - kết quả được dự đoán sẽ thay đổi do tác động của biến độc lập',
                'measurement': 'Đo lường bằng các chỉ số khách quan hoặc thang đo nhận thức'
            },
            'mediating': {
                'variables': model['mediating_variables'],
                'definition': 'Các biến trung gian - giải thích cơ chế tác động từ biến độc lập đến biến phụ thuộc',
                'measurement': 'Đo lường để kiểm định vai trò trung gian trong mô hình'
            },
            'moderating': {
                'variables': model['moderating_variables'],
                'definition': 'Các biến điều tiết - ảnh hưởng đến mức độ mạnh/yếu của mối quan hệ chính',
                'measurement': 'Đo lường để phân tích tương tác với các biến khác'
            }
        }
    
    def _generate_framework_description(self, model: Dict) -> str:
        """Generate textual description of the theoretical framework diagram"""
        
        description = """## MÔ TẢ SƠ ĐỒ KHUNG LÝ THUYẾT

### Cấu trúc mô hình:

**Biến độc lập (Independent Variables):**
"""
        for var in model['independent_variables']:
            description += f"- {var.title().replace('_', ' ')}\n"
        
        description += "\n**Biến phụ thuộc (Dependent Variables):**\n"
        for var in model['dependent_variables']:
            description += f"- {var.title().replace('_', ' ')}\n"
        
        if model['mediating_variables']:
            description += "\n**Biến trung gian (Mediating Variables):**\n"
            for var in model['mediating_variables']:
                description += f"- {var.title().replace('_', ' ')}\n"
        
        if model['moderating_variables']:
            description += "\n**Biến điều tiết (Moderating Variables):**\n"
            for var in model['moderating_variables']:
                description += f"- {var.title().replace('_', ' ')}\n"
        
        description += "\n### Mối quan hệ trong mô hình:\n\n"
        for relationship in model['relationships']:
            if relationship['type'] == 'direct':
                description += f"• {relationship['from'].title()} → {relationship['to'].title()}\n"
            elif relationship['type'] == 'mediated':
                description += f"• {relationship['from'].title()} → {relationship['through'].title()} → {relationship['to'].title()}\n"
        
        description += f"""
### Cơ sở lý thuyết:

Mô hình được xây dựng dựa trên: {', '.join(model['theoretical_basis'])}

### Ghi chú thiết kế:
- Sử dụng mũi tên thẳng (→) cho mối quan hệ trực tiếp
- Sử dụng mũi tên đứt nét (⇢) cho mối quan hệ điều tiết
- Các biến được thể hiện trong hình chữ nhật
- Mối quan hệ trung gian được thể hiện qua chuỗi mũi tên
"""
        
        return description

    def export_framework_content(self, framework: Dict, topic: str) -> str:
        """Export complete framework content for document generation"""
        
        content = f"""# KHUNG LÝ THUYẾT NGHIÊN CỨU

## Đề tài: {topic}

{framework['theoretical_justification']}

## MÔ HÌNH NGHIÊN CỨU

{framework['framework_diagram']}

## CÁC GIẢ THUYẾT NGHIÊN CỨU

"""
        for i, hypothesis in enumerate(framework['hypotheses'], 1):
            content += f"{hypothesis}\n\n"
        
        content += """## ĐỊNH NGHĨA CÁC BIẾN NGHIÊN CỨU

"""
        variables = framework['variables']
        for var_type, var_info in variables.items():
            if var_info['variables']:
                content += f"### {var_type.title()} Variables\n\n"
                content += f"{var_info['definition']}\n\n"
                for var in var_info['variables']:
                    content += f"- **{var.title().replace('_', ' ')}**: [Định nghĩa chi tiết sẽ được bổ sung]\n"
                content += f"\n**Cách đo lường:** {var_info['measurement']}\n\n"
        
        return content
