import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LinearRegression
from sklearn.metrics import r2_score
from scipy import stats
from scipy.stats import chi2_contingency, pearsonr, spearmanr
import warnings
warnings.filterwarnings('ignore')

class AdvancedDataAnalyzer:
    """
    Advanced AI-powered data analyzer that automatically selects appropriate 
    statistical methods and generates academic-quality interpretations
    """
    
    def __init__(self):
        self.analysis_results = {}
        self.statistical_methods = self._initialize_statistical_methods()
        self.interpretation_templates = self._initialize_interpretation_templates()
        
    def _initialize_statistical_methods(self) -> dict:
        """Initialize available statistical methods with their requirements"""
        return {
            'descriptive': {
                'methods': ['mean', 'median', 'std', 'min', 'max', 'quartiles'],
                'requirements': 'Any numerical data',
                'purpose': 'Mô tả đặc điểm cơ bản của dữ liệu'
            },
            'correlation': {
                'methods': ['pearson', 'spearman', 'kendall'],
                'requirements': 'Two or more numerical variables',
                'purpose': 'Phân tích mối quan hệ tương quan giữa các biến'
            },
            'regression': {
                'methods': ['linear', 'multiple', 'logistic', 'polynomial'],
                'requirements': 'Independent and dependent variables',
                'purpose': 'Mô hình hóa mối quan hệ nhân quả'
            },
            'comparison': {
                'methods': ['t_test', 'anova', 'chi_square', 'mann_whitney'],
                'requirements': 'Groups to compare',
                'purpose': 'So sánh giữa các nhóm'
            },
            'advanced': {
                'methods': ['factor_analysis', 'cluster_analysis', 'sem'],
                'requirements': 'Multiple variables, large sample size',
                'purpose': 'Phân tích cấu trúc và mô hình phức tạp'
            }
        }
    
    def _initialize_interpretation_templates(self) -> dict:
        """Initialize academic interpretation templates"""
        return {
            'correlation': {
                'strong_positive': "Kết quả cho thấy có mối tương quan thuận mạnh (r = {r:.3f}, p < 0.001) giữa {var1} và {var2}. Điều này có nghĩa là khi {var1} tăng, {var2} có xu hướng tăng theo một cách đáng kể về mặt thống kê.",
                'moderate_positive': "Phân tích tương quan cho thấy mối quan hệ thuận vừa phải (r = {r:.3f}, p < 0.05) giữa {var1} và {var2}. Mặc dù mối quan hệ này có ý nghĩa thống kê, nhưng mức độ tương quan ở mức trung bình.",
                'weak_positive': "Có một mối tương quan thuận yếu (r = {r:.3f}, p < 0.05) giữa {var1} và {var2}. Mối quan hệ này có ý nghĩa thống kê nhưng mức độ ảnh hưởng khá thấp.",
                'no_correlation': "Không tìm thấy mối tương quan có ý nghĩa thống kê giữa {var1} và {var2} (r = {r:.3f}, p > 0.05). Điều này cho thấy hai biến này độc lập với nhau trong mẫu nghiên cứu."
            },
            'regression': {
                'significant': "Mô hình hồi quy cho thấy {independent} có ảnh hưởng đáng kể đến {dependent} (β = {beta:.3f}, p < 0.05). Mô hình giải thích được {r2:.1%} variance trong {dependent} (R² = {r2:.3f}).",
                'highly_significant': "Kết quả hồi quy cho thấy {independent} có tác động mạnh và có ý nghĩa cao đến {dependent} (β = {beta:.3f}, p < 0.001). Với R² = {r2:.3f}, mô hình có khả năng dự đoán tốt.",
                'not_significant': "Mô hình hồi quy không cho thấy ảnh hưởng có ý nghĩa thống kê của {independent} đến {dependent} (β = {beta:.3f}, p > 0.05). Cần xem xét các yếu tố khác."
            },
            'comparison': {
                't_test_significant': "Kiểm định t-test cho thấy có sự khác biệt có ý nghĩa thống kê giữa {group1} và {group2} (t = {t_stat:.3f}, p < 0.05). Giá trị trung bình của {group1} ({mean1:.2f}) cao hơn đáng kể so với {group2} ({mean2:.2f}).",
                'anova_significant': "Phân tích ANOVA cho thấy có sự khác biệt có ý nghĩa thống kê giữa các nhóm (F = {f_stat:.3f}, p < 0.05). Kiểm định post-hoc sẽ được thực hiện để xác định các cặp nhóm khác biệt.",
                'chi_square_significant': "Kiểm định Chi-square cho thấy có mối quan hệ có ý nghĩa thống kê giữa các biến phân loại (χ² = {chi2:.3f}, p < 0.05). Điều này cho thấy sự phân bố không ngẫu nhiên."
            }
        }
    
    def analyze_dataset(self, df: pd.DataFrame, research_question: str, 
                       variables_info: dict = None) -> dict:
        """
        Comprehensive dataset analysis with automatic method selection
        """
        # Data preprocessing and quality check
        data_quality = self._assess_data_quality(df)
        
        # Automatic variable type detection
        variable_types = self._detect_variable_types(df)
        
        # Select appropriate analysis methods
        recommended_methods = self._recommend_analysis_methods(df, variable_types, research_question)
        
        # Perform analyses
        analysis_results = {}
        
        # 1. Descriptive Analysis
        analysis_results['descriptive'] = self._perform_descriptive_analysis(df, variable_types)
        
        # 2. Correlation Analysis
        if len([col for col, vtype in variable_types.items() if vtype == 'numerical']) >= 2:
            analysis_results['correlation'] = self._perform_correlation_analysis(df, variable_types)
        
        # 3. Regression Analysis
        if self._can_perform_regression(df, variable_types):
            analysis_results['regression'] = self._perform_regression_analysis(df, variable_types)
        
        # 4. Group Comparison
        if self._can_perform_comparison(df, variable_types):
            analysis_results['comparison'] = self._perform_comparison_analysis(df, variable_types)
        
        # 5. Generate visualizations
        visualizations = self._generate_visualizations(df, variable_types, analysis_results)
        
        # 6. Academic interpretation
        interpretation = self._generate_academic_interpretation(analysis_results, variable_types)
        
        # 7. Results summary for thesis chapter
        results_chapter = self._generate_results_chapter(analysis_results, interpretation, visualizations)
        
        return {
            'data_quality': data_quality,
            'variable_types': variable_types,
            'recommended_methods': recommended_methods,
            'analysis_results': analysis_results,
            'visualizations': visualizations,
            'interpretation': interpretation,
            'results_chapter': results_chapter
        }
    
    def _assess_data_quality(self, df: pd.DataFrame) -> dict:
        """Assess data quality and provide recommendations"""
        
        quality_report = {
            'total_rows': len(df),
            'total_columns': len(df.columns),
            'missing_data': {},
            'data_types': {},
            'outliers': {},
            'recommendations': []
        }
        
        # Missing data analysis
        for col in df.columns:
            missing_count = df[col].isnull().sum()
            missing_percent = (missing_count / len(df)) * 100
            quality_report['missing_data'][col] = {
                'count': missing_count,
                'percentage': missing_percent
            }
            
            if missing_percent > 5:
                quality_report['recommendations'].append(
                    f"Cột '{col}' có {missing_percent:.1f}% dữ liệu thiếu - cần xem xét xử lý"
                )
        
        # Data type analysis
        for col in df.columns:
            quality_report['data_types'][col] = str(df[col].dtype)
        
        # Outlier detection for numerical columns
        numerical_cols = df.select_dtypes(include=[np.number]).columns
        for col in numerical_cols:
            Q1 = df[col].quantile(0.25)
            Q3 = df[col].quantile(0.75)
            IQR = Q3 - Q1
            lower_bound = Q1 - 1.5 * IQR
            upper_bound = Q3 + 1.5 * IQR
            outliers = df[(df[col] < lower_bound) | (df[col] > upper_bound)]
            
            quality_report['outliers'][col] = {
                'count': len(outliers),
                'percentage': (len(outliers) / len(df)) * 100
            }
        
        # Sample size adequacy
        if len(df) < 30:
            quality_report['recommendations'].append("Kích thước mẫu nhỏ (n < 30) - cần thận trọng với các kiểm định thống kê")
        elif len(df) < 100:
            quality_report['recommendations'].append("Kích thước mẫu trung bình - phù hợp cho phân tích cơ bản")
        else:
            quality_report['recommendations'].append("Kích thước mẫu tốt - có thể thực hiện các phân tích nâng cao")
        
        return quality_report
    
    def _detect_variable_types(self, df: pd.DataFrame) -> dict:
        """Automatically detect variable types"""
        
        variable_types = {}
        
        for col in df.columns:
            # Check if numerical
            if df[col].dtype in ['int64', 'float64']:
                # Check if it's actually categorical (few unique values)
                unique_values = df[col].nunique()
                if unique_values <= 5 and unique_values < len(df) * 0.05:
                    variable_types[col] = 'categorical_numerical'
                else:
                    variable_types[col] = 'numerical'
            
            # Check if categorical
            elif df[col].dtype == 'object':
                # Check if it can be converted to numerical
                try:
                    pd.to_numeric(df[col])
                    variable_types[col] = 'numerical_string'
                except:
                    variable_types[col] = 'categorical'
            
            # Boolean type
            elif df[col].dtype == 'bool':
                variable_types[col] = 'binary'
            
            # DateTime
            elif 'datetime' in str(df[col].dtype):
                variable_types[col] = 'datetime'
            
            else:
                variable_types[col] = 'other'
        
        return variable_types
    
    def _recommend_analysis_methods(self, df: pd.DataFrame, variable_types: dict, research_question: str) -> list:
        """Recommend appropriate analysis methods based on data and research question"""
        
        recommendations = []
        
        numerical_vars = [col for col, vtype in variable_types.items() if vtype == 'numerical']
        categorical_vars = [col for col, vtype in variable_types.items() if vtype in ['categorical', 'binary']]
        
        # Always recommend descriptive analysis
        recommendations.append({
            'method': 'Descriptive Statistics',
            'purpose': 'Mô tả đặc điểm cơ bản của dữ liệu',
            'priority': 'High'
        })
        
        # Correlation analysis
        if len(numerical_vars) >= 2:
            recommendations.append({
                'method': 'Correlation Analysis',
                'purpose': 'Phân tích mối quan hệ giữa các biến số',
                'priority': 'High'
            })
        
        # Regression analysis
        if len(numerical_vars) >= 2:
            recommendations.append({
                'method': 'Regression Analysis',
                'purpose': 'Mô hình hóa mối quan hệ nhân quả',
                'priority': 'High'
            })
        
        # Group comparison
        if len(categorical_vars) >= 1 and len(numerical_vars) >= 1:
            recommendations.append({
                'method': 'Group Comparison (t-test/ANOVA)',
                'purpose': 'So sánh giữa các nhóm',
                'priority': 'Medium'
            })
        
        # Chi-square test
        if len(categorical_vars) >= 2:
            recommendations.append({
                'method': 'Chi-square Test',
                'purpose': 'Kiểm định mối quan hệ giữa biến phân loại',
                'priority': 'Medium'
            })
        
        # Advanced methods
        if len(numerical_vars) >= 5 and len(df) >= 100:
            recommendations.append({
                'method': 'Factor Analysis',
                'purpose': 'Giảm chiều dữ liệu và khám phá cấu trúc ẩn',
                'priority': 'Low'
            })
        
        return recommendations
    
    def _perform_descriptive_analysis(self, df: pd.DataFrame, variable_types: dict) -> dict:
        """Perform comprehensive descriptive analysis"""
        
        results = {
            'numerical_summary': {},
            'categorical_summary': {},
            'distribution_analysis': {}
        }
        
        # Numerical variables
        numerical_cols = [col for col, vtype in variable_types.items() if vtype == 'numerical']
        
        for col in numerical_cols:
            stats_summary = {
                'count': df[col].count(),
                'mean': df[col].mean(),
                'median': df[col].median(),
                'std': df[col].std(),
                'min': df[col].min(),
                'max': df[col].max(),
                'q25': df[col].quantile(0.25),
                'q75': df[col].quantile(0.75),
                'skewness': df[col].skew(),
                'kurtosis': df[col].kurtosis()
            }
            
            results['numerical_summary'][col] = stats_summary
            
            # Distribution analysis
            shapiro_stat, shapiro_p = stats.shapiro(df[col].dropna().sample(min(5000, len(df[col].dropna()))))
            results['distribution_analysis'][col] = {
                'normality_test': {
                    'shapiro_stat': shapiro_stat,
                    'shapiro_p': shapiro_p,
                    'is_normal': shapiro_p > 0.05
                }
            }
        
        # Categorical variables
        categorical_cols = [col for col, vtype in variable_types.items() if vtype in ['categorical', 'binary']]
        
        for col in categorical_cols:
            value_counts = df[col].value_counts()
            proportions = df[col].value_counts(normalize=True)
            
            results['categorical_summary'][col] = {
                'unique_values': df[col].nunique(),
                'value_counts': value_counts.to_dict(),
                'proportions': proportions.to_dict(),
                'mode': df[col].mode().iloc[0] if len(df[col].mode()) > 0 else None
            }
        
        return results
    
    def _perform_correlation_analysis(self, df: pd.DataFrame, variable_types: dict) -> dict:
        """Perform correlation analysis with statistical significance"""
        
        numerical_cols = [col for col, vtype in variable_types.items() if vtype == 'numerical']
        
        if len(numerical_cols) < 2:
            return {}
        
        results = {
            'correlation_matrix': {},
            'significant_correlations': [],
            'correlation_interpretation': {}
        }
        
        # Calculate correlation matrix
        corr_data = df[numerical_cols].corr()
        results['correlation_matrix'] = corr_data.to_dict()
        
        # Calculate significance and detailed analysis
        for i in range(len(numerical_cols)):
            for j in range(i+1, len(numerical_cols)):
                var1, var2 = numerical_cols[i], numerical_cols[j]
                
                # Pearson correlation with significance
                corr_coef, p_value = pearsonr(df[var1].dropna(), df[var2].dropna())
                
                correlation_info = {
                    'var1': var1,
                    'var2': var2,
                    'correlation': corr_coef,
                    'p_value': p_value,
                    'significant': p_value < 0.05,
                    'strength': self._interpret_correlation_strength(abs(corr_coef)),
                    'direction': 'positive' if corr_coef > 0 else 'negative'
                }
                
                results['significant_correlations'].append(correlation_info)
                
                # Generate interpretation
                results['correlation_interpretation'][f"{var1}_{var2}"] = self._generate_correlation_interpretation(correlation_info)
        
        return results
    
    def _interpret_correlation_strength(self, abs_corr: float) -> str:
        """Interpret correlation strength"""
        if abs_corr >= 0.7:
            return 'strong'
        elif abs_corr >= 0.5:
            return 'moderate'
        elif abs_corr >= 0.3:
            return 'weak'
        else:
            return 'very_weak'
    
    def _generate_correlation_interpretation(self, corr_info: dict) -> str:
        """Generate academic interpretation for correlation"""
        
        templates = self.interpretation_templates['correlation']
        strength = corr_info['strength']
        direction = corr_info['direction']
        
        key = f"{strength}_{direction}" if corr_info['significant'] else 'no_correlation'
        
        if key in templates:
            return templates[key].format(
                r=corr_info['correlation'],
                var1=corr_info['var1'],
                var2=corr_info['var2']
            )
        else:
            return templates['no_correlation'].format(
                r=corr_info['correlation'],
                var1=corr_info['var1'],
                var2=corr_info['var2']
            )
    
    def _can_perform_regression(self, df: pd.DataFrame, variable_types: dict) -> bool:
        """Check if regression analysis can be performed"""
        numerical_vars = [col for col, vtype in variable_types.items() if vtype == 'numerical']
        return len(numerical_vars) >= 2
    
    def _perform_regression_analysis(self, df: pd.DataFrame, variable_types: dict) -> dict:
        """Perform regression analysis"""
        
        numerical_cols = [col for col, vtype in variable_types.items() if vtype == 'numerical']
        
        if len(numerical_cols) < 2:
            return {}
        
        results = {
            'simple_regressions': [],
            'multiple_regression': None,
            'regression_interpretation': {}
        }
        
        # Simple regressions (each independent variable predicting the last numerical variable as dependent)
        dependent_var = numerical_cols[-1]  # Use last numerical variable as dependent
        independent_vars = numerical_cols[:-1]
        
        for independent_var in independent_vars:
            # Prepare data
            X = df[[independent_var]].dropna()
            y = df[dependent_var].dropna()
            
            # Align the data
            common_index = X.index.intersection(y.index)
            X_aligned = X.loc[common_index]
            y_aligned = y.loc[common_index]
            
            if len(X_aligned) < 10:  # Minimum sample size
                continue
            
            # Fit regression
            model = LinearRegression()
            model.fit(X_aligned, y_aligned)
            
            # Calculate statistics
            y_pred = model.predict(X_aligned)
            r2 = r2_score(y_aligned, y_pred)
            
            # Calculate t-statistic for coefficient
            n = len(X_aligned)
            mse = np.mean((y_aligned - y_pred) ** 2)
            var_beta = mse / np.sum((X_aligned.iloc[:, 0] - X_aligned.iloc[:, 0].mean()) ** 2)
            se_beta = np.sqrt(var_beta)
            t_stat = model.coef_[0] / se_beta
            p_value = 2 * (1 - stats.t.cdf(abs(t_stat), n - 2))
            
            regression_result = {
                'independent_var': independent_var,
                'dependent_var': dependent_var,
                'coefficient': model.coef_[0],
                'intercept': model.intercept_,
                'r_squared': r2,
                't_statistic': t_stat,
                'p_value': p_value,
                'significant': p_value < 0.05,
                'sample_size': n
            }
            
            results['simple_regressions'].append(regression_result)
            
            # Generate interpretation
            results['regression_interpretation'][f"{independent_var}_{dependent_var}"] = self._generate_regression_interpretation(regression_result)
        
        # Multiple regression (if enough variables)
        if len(independent_vars) >= 2:
            try:
                X_multi = df[independent_vars].dropna()
                y_multi = df[dependent_var].dropna()
                
                common_index = X_multi.index.intersection(y_multi.index)
                X_multi_aligned = X_multi.loc[common_index]
                y_multi_aligned = y_multi.loc[common_index]
                
                if len(X_multi_aligned) >= 20:  # Minimum sample size for multiple regression
                    model_multi = LinearRegression()
                    model_multi.fit(X_multi_aligned, y_multi_aligned)
                    
                    y_pred_multi = model_multi.predict(X_multi_aligned)
                    r2_multi = r2_score(y_multi_aligned, y_pred_multi)
                    
                    results['multiple_regression'] = {
                        'independent_vars': independent_vars,
                        'dependent_var': dependent_var,
                        'coefficients': dict(zip(independent_vars, model_multi.coef_)),
                        'intercept': model_multi.intercept_,
                        'r_squared': r2_multi,
                        'sample_size': len(X_multi_aligned)
                    }
            except Exception as e:
                pass  # Multiple regression failed, continue with simple regressions
        
        return results
    
    def _generate_regression_interpretation(self, reg_result: dict) -> str:
        """Generate academic interpretation for regression"""
        
        templates = self.interpretation_templates['regression']
        
        if reg_result['significant']:
            if reg_result['p_value'] < 0.001:
                template = templates['highly_significant']
            else:
                template = templates['significant']
        else:
            template = templates['not_significant']
        
        return template.format(
            independent=reg_result['independent_var'],
            dependent=reg_result['dependent_var'],
            beta=reg_result['coefficient'],
            r2=reg_result['r_squared']
        )
    
    def _can_perform_comparison(self, df: pd.DataFrame, variable_types: dict) -> bool:
        """Check if group comparison can be performed"""
        categorical_vars = [col for col, vtype in variable_types.items() if vtype in ['categorical', 'binary']]
        numerical_vars = [col for col, vtype in variable_types.items() if vtype == 'numerical']
        return len(categorical_vars) >= 1 and len(numerical_vars) >= 1
    
    def _perform_comparison_analysis(self, df: pd.DataFrame, variable_types: dict) -> dict:
        """Perform group comparison analysis"""
        
        categorical_cols = [col for col, vtype in variable_types.items() if vtype in ['categorical', 'binary']]
        numerical_cols = [col for col, vtype in variable_types.items() if vtype == 'numerical']
        
        results = {
            't_tests': [],
            'anova_tests': [],
            'chi_square_tests': [],
            'comparison_interpretation': {}
        }
        
        # T-tests and ANOVA for categorical vs numerical
        for cat_var in categorical_cols:
            for num_var in numerical_cols:
                unique_groups = df[cat_var].dropna().unique()
                
                if len(unique_groups) == 2:
                    # T-test for two groups
                    group1_data = df[df[cat_var] == unique_groups[0]][num_var].dropna()
                    group2_data = df[df[cat_var] == unique_groups[1]][num_var].dropna()
                    
                    if len(group1_data) >= 5 and len(group2_data) >= 5:
                        t_stat, p_value = stats.ttest_ind(group1_data, group2_data)
                        
                        t_result = {
                            'categorical_var': cat_var,
                            'numerical_var': num_var,
                            'group1': unique_groups[0],
                            'group2': unique_groups[1],
                            'mean1': group1_data.mean(),
                            'mean2': group2_data.mean(),
                            't_statistic': t_stat,
                            'p_value': p_value,
                            'significant': p_value < 0.05
                        }
                        
                        results['t_tests'].append(t_result)
                        results['comparison_interpretation'][f"{cat_var}_{num_var}_ttest"] = self._generate_ttest_interpretation(t_result)
                
                elif len(unique_groups) > 2:
                    # ANOVA for multiple groups
                    group_data = [df[df[cat_var] == group][num_var].dropna() for group in unique_groups]
                    group_data = [group for group in group_data if len(group) >= 3]
                    
                    if len(group_data) >= 2:
                        f_stat, p_value = stats.f_oneway(*group_data)
                        
                        anova_result = {
                            'categorical_var': cat_var,
                            'numerical_var': num_var,
                            'groups': unique_groups.tolist(),
                            'f_statistic': f_stat,
                            'p_value': p_value,
                            'significant': p_value < 0.05,
                            'group_means': {group: df[df[cat_var] == group][num_var].mean() for group in unique_groups}
                        }
                        
                        results['anova_tests'].append(anova_result)
                        results['comparison_interpretation'][f"{cat_var}_{num_var}_anova"] = self._generate_anova_interpretation(anova_result)
        
        # Chi-square tests for categorical vs categorical
        for i in range(len(categorical_cols)):
            for j in range(i+1, len(categorical_cols)):
                var1, var2 = categorical_cols[i], categorical_cols[j]
                
                # Create contingency table
                contingency_table = pd.crosstab(df[var1], df[var2])
                
                if contingency_table.shape[0] >= 2 and contingency_table.shape[1] >= 2:
                    chi2_stat, p_value, dof, expected = chi2_contingency(contingency_table)
                    
                    chi2_result = {
                        'var1': var1,
                        'var2': var2,
                        'chi2_statistic': chi2_stat,
                        'p_value': p_value,
                        'degrees_of_freedom': dof,
                        'significant': p_value < 0.05,
                        'contingency_table': contingency_table.to_dict()
                    }
                    
                    results['chi_square_tests'].append(chi2_result)
                    results['comparison_interpretation'][f"{var1}_{var2}_chi2"] = self._generate_chi2_interpretation(chi2_result)
        
        return results
    
    def _generate_ttest_interpretation(self, t_result: dict) -> str:
        """Generate interpretation for t-test"""
        template = self.interpretation_templates['comparison']['t_test_significant']
        return template.format(**t_result)
    
    def _generate_anova_interpretation(self, anova_result: dict) -> str:
        """Generate interpretation for ANOVA"""
        template = self.interpretation_templates['comparison']['anova_significant']
        return template.format(**anova_result)
    
    def _generate_chi2_interpretation(self, chi2_result: dict) -> str:
        """Generate interpretation for Chi-square test"""
        template = self.interpretation_templates['comparison']['chi_square_significant']
        return template.format(**chi2_result)
    
    def _generate_visualizations(self, df: pd.DataFrame, variable_types: dict, analysis_results: dict) -> dict:
        """Generate comprehensive visualizations for the analysis"""
        
        visualizations = {
            'descriptive_plots': [],
            'correlation_plots': [],
            'regression_plots': [],
            'comparison_plots': []
        }
        
        numerical_cols = [col for col, vtype in variable_types.items() if vtype == 'numerical']
        categorical_cols = [col for col, vtype in variable_types.items() if vtype in ['categorical', 'binary']]
        
        # Descriptive plots
        for col in numerical_cols:
            # Histogram
            fig_hist = px.histogram(df, x=col, title=f'Phân phối của {col}')
            visualizations['descriptive_plots'].append({
                'type': 'histogram',
                'variable': col,
                'figure': fig_hist,
                'description': f'Biểu đồ phân phối tần số của biến {col}'
            })
            
            # Box plot
            fig_box = px.box(df, y=col, title=f'Box plot của {col}')
            visualizations['descriptive_plots'].append({
                'type': 'boxplot',
                'variable': col,
                'figure': fig_box,
                'description': f'Box plot cho thấy median, quartiles và outliers của {col}'
            })
        
        # Correlation heatmap
        if len(numerical_cols) >= 2:
            corr_matrix = df[numerical_cols].corr()
            fig_corr = px.imshow(corr_matrix, text_auto=True, aspect="auto",
                               title='Ma trận tương quan giữa các biến số')
            visualizations['correlation_plots'].append({
                'type': 'correlation_heatmap',
                'variables': numerical_cols,
                'figure': fig_corr,
                'description': 'Ma trận tương quan cho thấy mức độ tương quan giữa các biến số'
            })
        
        # Scatter plots for significant correlations
        if 'correlation' in analysis_results:
            for corr_info in analysis_results['correlation']['significant_correlations']:
                if corr_info['significant']:
                    fig_scatter = px.scatter(df, x=corr_info['var1'], y=corr_info['var2'],
                                           title=f'Mối quan hệ giữa {corr_info["var1"]} và {corr_info["var2"]}',
                                           trendline="ols")
                    visualizations['correlation_plots'].append({
                        'type': 'scatter',
                        'variables': [corr_info['var1'], corr_info['var2']],
                        'figure': fig_scatter,
                        'description': f'Biểu đồ tương quan giữa {corr_info["var1"]} và {corr_info["var2"]}'
                    })
        
        # Group comparison plots
        for cat_var in categorical_cols:
            for num_var in numerical_cols:
                # Box plot by group
                fig_group_box = px.box(df, x=cat_var, y=num_var,
                                     title=f'{num_var} theo {cat_var}')
                visualizations['comparison_plots'].append({
                    'type': 'group_boxplot',
                    'variables': [cat_var, num_var],
                    'figure': fig_group_box,
                    'description': f'So sánh {num_var} giữa các nhóm {cat_var}'
                })
        
        return visualizations
    
    def _generate_academic_interpretation(self, analysis_results: dict, variable_types: dict) -> str:
        """Generate comprehensive academic interpretation"""
        
        interpretation = """## GIẢI THÍCH KẾT QUẢ PHÂN TÍCH DỮ LIỆU

### Phân tích mô tả (Descriptive Analysis)

"""
        
        # Descriptive interpretation
        if 'descriptive' in analysis_results:
            descriptive = analysis_results['descriptive']
            
            interpretation += "#### Thống kê mô tả cho các biến số:\n\n"
            
            for var, stats in descriptive['numerical_summary'].items():
                interpretation += f"""**{var}:**
- Giá trị trung bình: {stats['mean']:.2f} (SD = {stats['std']:.2f})
- Median: {stats['median']:.2f}
- Khoảng giá trị: {stats['min']:.2f} - {stats['max']:.2f}
- Phân phối: {'Chuẩn' if descriptive['distribution_analysis'][var]['normality_test']['is_normal'] else 'Không chuẩn'}

"""
        
        # Correlation interpretation
        if 'correlation' in analysis_results:
            interpretation += "### Phân tích tương quan (Correlation Analysis)\n\n"
            
            for corr_key, corr_text in analysis_results['correlation']['correlation_interpretation'].items():
                interpretation += f"{corr_text}\n\n"
        
        # Regression interpretation
        if 'regression' in analysis_results:
            interpretation += "### Phân tích hồi quy (Regression Analysis)\n\n"
            
            for reg_key, reg_text in analysis_results['regression']['regression_interpretation'].items():
                interpretation += f"{reg_text}\n\n"
        
        # Comparison interpretation
        if 'comparison' in analysis_results:
            interpretation += "### Phân tích so sánh nhóm (Group Comparison)\n\n"
            
            for comp_key, comp_text in analysis_results['comparison']['comparison_interpretation'].items():
                interpretation += f"{comp_text}\n\n"
        
        interpretation += """### Tóm tắt và ý nghĩa

Kết quả phân tích dữ liệu cho thấy:
1. Dữ liệu đã được kiểm tra chất lượng và xử lý phù hợp
2. Các mối quan hệ giữa biến số đã được xác định và kiểm định
3. Các giả thuyết nghiên cứu được hỗ trợ/bác bỏ bởi bằng chứng thực nghiệm
4. Kết quả có ý nghĩa thống kê và thực tiễn cho lĩnh vực nghiên cứu

### Khuyến nghị cho nghiên cứu tiếp theo

- Mở rộng kích thước mẫu để tăng sức mạnh thống kê
- Xem xét thêm các biến kiểm soát để tăng độ chính xác mô hình
- Thực hiện nghiên cứu longitudinal để xác định mối quan hệ nhân quả
- Áp dụng các phương pháp phân tích nâng cao như SEM hoặc máy học
"""
        
        return interpretation
    
    def _generate_results_chapter(self, analysis_results: dict, interpretation: str, visualizations: dict) -> str:
        """Generate complete results chapter for thesis"""
        
        chapter = """# CHƯƠNG 4: KẾT QUẢ NGHIÊN CỨU

## 4.1. Giới thiệu

Chương này trình bày kết quả phân tích dữ liệu được thu thập từ nghiên cứu. Dữ liệu được phân tích bằng phần mềm thống kê với các phương pháp phù hợp để trả lời các câu hỏi nghiên cứu và kiểm định các giả thuyết đã đề ra.

## 4.2. Đặc điểm mẫu nghiên cứu

"""
        
        # Add descriptive statistics
        if 'descriptive' in analysis_results:
            chapter += """### 4.2.1. Thống kê mô tả

"""
            descriptive = analysis_results['descriptive']
            
            for var, stats in descriptive['numerical_summary'].items():
                chapter += f"""**Biến {var}:**
- Số quan sát: {stats['count']}
- Giá trị trung bình: {stats['mean']:.3f}
- Độ lệch chuẩn: {stats['std']:.3f}
- Giá trị nhỏ nhất: {stats['min']:.3f}
- Giá trị lớn nhất: {stats['max']:.3f}

"""
        
        chapter += """## 4.3. Kết quả kiểm định giả thuyết

"""
        
        # Add correlation results
        if 'correlation' in analysis_results:
            chapter += """### 4.3.1. Phân tích tương quan

Bảng dưới đây cho thấy ma trận tương quan giữa các biến nghiên cứu:

"""
            for corr_key, corr_text in analysis_results['correlation']['correlation_interpretation'].items():
                chapter += f"{corr_text}\n\n"
        
        # Add regression results
        if 'regression' in analysis_results:
            chapter += """### 4.3.2. Phân tích hồi quy

"""
            for reg_key, reg_text in analysis_results['regression']['regression_interpretation'].items():
                chapter += f"{reg_text}\n\n"
        
        # Add comparison results
        if 'comparison' in analysis_results:
            chapter += """### 4.3.3. Phân tích so sánh

"""
            for comp_key, comp_text in analysis_results['comparison']['comparison_interpretation'].items():
                chapter += f"{comp_text}\n\n"
        
        chapter += """## 4.4. Biểu đồ và hình ảnh minh họa

[Chèn các biểu đồ được tạo tự động:]

"""
        
        # List visualizations
        all_viz = []
        all_viz.extend(visualizations.get('descriptive_plots', []))
        all_viz.extend(visualizations.get('correlation_plots', []))
        all_viz.extend(visualizations.get('comparison_plots', []))
        
        for i, viz in enumerate(all_viz, 1):
            chapter += f"- Hình 4.{i}: {viz['description']}\n"
        
        chapter += f"""

## 4.5. Tóm tắt kết quả

{interpretation}

## 4.6. Kết luận chương

Kết quả phân tích dữ liệu đã cung cấp bằng chứng thực nghiệm để trả lời các câu hỏi nghiên cứu và kiểm định các giả thuyết. Các phát hiện này sẽ được thảo luận chi tiết trong chương tiếp theo để rút ra những ý nghĩa lý thuyết và thực tiễn.
"""
        
        return chapter
