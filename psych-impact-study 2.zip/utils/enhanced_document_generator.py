from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_LINE_SPACING
from docx.enum.style import WD_STYLE_TYPE
from docx.oxml.shared import OxmlElement, qn
import io
import base64
from typing import Dict, List, Optional

class EnhancedDocumentGenerator:
    """
    Enhanced document generator for complete thesis with AI content, charts, and citations
    """
    
    def __init__(self):
        self.doc = None
        
    def create_complete_thesis(self, thesis_data: Dict) -> io.BytesIO:
        """
        Create a complete thesis document with all components
        """
        self.doc = Document()
        
        # Set document margins and styles
        self._setup_document_format()
        
        # Add title page
        self._add_title_page(thesis_data)
        self.doc.add_page_break()
        
        # Add abstract if available
        if 'ai_content' in thesis_data and 'abstract' in thesis_data['ai_content']:
            self._add_abstract(thesis_data['ai_content']['abstract'])
            self.doc.add_page_break()
        
        # Add table of contents
        self._add_table_of_contents(thesis_data.get('outline', []))
        self.doc.add_page_break()
        
        # Add main chapters
        if 'ai_content' in thesis_data:
            self._add_ai_chapters(thesis_data['ai_content'], thesis_data)
        else:
            # Add outline-based structure
            self._add_outline_chapters(thesis_data.get('outline', []))
        
        # Add statistical analysis if available
        if 'statistical_analysis' in thesis_data:
            self._add_statistical_chapter(thesis_data['statistical_analysis'])
        
        # Add references if available
        if 'ai_content' in thesis_data and 'citations' in thesis_data['ai_content']:
            self._add_references(thesis_data['ai_content']['citations'])
        
        # Save to buffer
        doc_buffer = io.BytesIO()
        self.doc.save(doc_buffer)
        doc_buffer.seek(0)
        
        return doc_buffer
    
    def _setup_document_format(self):
        """Setup document formatting and styles"""
        sections = self.doc.sections
        for section in sections:
            section.top_margin = Inches(1)
            section.bottom_margin = Inches(1)
            section.left_margin = Inches(1.25)
            section.right_margin = Inches(1)
        
        # Configure styles
        styles = self.doc.styles
        
        # Normal style
        normal_style = styles['Normal']
        normal_font = normal_style.font
        normal_font.name = 'Times New Roman'
        normal_font.size = Pt(12)
        
        # Heading styles
        for i in range(1, 4):
            heading_style = styles[f'Heading {i}']
            heading_font = heading_style.font
            heading_font.name = 'Times New Roman'
            heading_font.bold = True
            heading_font.size = Pt(14 + (3-i)*2)
    
    def _add_title_page(self, thesis_data: Dict):
        """Add professional title page"""
        # University header
        university_para = self.doc.add_paragraph()
        university_para.alignment = WD_ALIGN_PARAGRAPH.CENTER
        run = university_para.add_run("ĐẠI HỌC QUỐC GIA HÀ NỘI\nTRƯỜNG ĐẠI HỌC KHOA HỌC XÃ HỘI VÀ NHÂN VĂN")
        run.font.size = Pt(12)
        run.font.bold = True
        
        # Add spacing
        for _ in range(3):
            self.doc.add_paragraph()
        
        # Thesis title
        title_para = self.doc.add_paragraph()
        title_para.alignment = WD_ALIGN_PARAGRAPH.CENTER
        title_run = title_para.add_run(f"LUẬN ÁN {thesis_data.get('level', 'TIẾN SĨ').upper()}")
        title_run.font.size = Pt(16)
        title_run.font.bold = True
        
        self.doc.add_paragraph()
        
        # Topic
        topic_para = self.doc.add_paragraph()
        topic_para.alignment = WD_ALIGN_PARAGRAPH.CENTER
        topic_run = topic_para.add_run(f'"{thesis_data.get("topic", "").upper()}"')
        topic_run.font.size = Pt(14)
        topic_run.font.bold = True
        
        # Add spacing
        for _ in range(2):
            self.doc.add_paragraph()
        
        # Field info
        field_para = self.doc.add_paragraph()
        field_para.alignment = WD_ALIGN_PARAGRAPH.CENTER
        field_run = field_para.add_run(f"Chuyên ngành: {thesis_data.get('field', '')}")
        field_run.font.size = Pt(12)
        
        # Add spacing
        for _ in range(6):
            self.doc.add_paragraph()
        
        # Author and supervisor info
        author_para = self.doc.add_paragraph()
        author_para.alignment = WD_ALIGN_PARAGRAPH.CENTER
        author_run = author_para.add_run("Nghiên cứu sinh: [Tên tác giả]\nNgười hướng dẫn: [Tên giáo viên hướng dẫn]")
        author_run.font.size = Pt(12)
        
        # Add spacing
        for _ in range(4):
            self.doc.add_paragraph()
        
        # Footer
        footer_para = self.doc.add_paragraph()
        footer_para.alignment = WD_ALIGN_PARAGRAPH.CENTER
        footer_run = footer_para.add_run("Hà Nội - 2024")
        footer_run.font.size = Pt(12)
        footer_run.font.bold = True
    
    def _add_abstract(self, abstract_content: str):
        """Add abstract page"""
        abstract_heading = self.doc.add_heading('TÓM TẮT', level=1)
        abstract_heading.alignment = WD_ALIGN_PARAGRAPH.CENTER
        
        # Add abstract content
        abstract_para = self.doc.add_paragraph()
        abstract_para.add_run(abstract_content)
        abstract_para.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
    
    def _add_table_of_contents(self, outline: List[Dict]):
        """Generate table of contents"""
        toc_heading = self.doc.add_heading('MỤC LỤC', level=1)
        toc_heading.alignment = WD_ALIGN_PARAGRAPH.CENTER
        
        # Add TOC entries
        for chapter in outline:
            chapter_para = self.doc.add_paragraph()
            chapter_run = chapter_para.add_run(chapter.get('title', ''))
            chapter_run.bold = True
            
            if chapter.get('sections'):
                for section in chapter['sections']:
                    section_para = self.doc.add_paragraph()
                    section_para.paragraph_format.left_indent = Inches(0.5)
                    section_para.add_run(f"{section.get('number', '')} {section.get('title', '')}")
            
            self.doc.add_paragraph()
    
    def _add_ai_chapters(self, ai_content: Dict, thesis_data: Dict):
        """Add AI-generated chapter content"""
        chapter_mapping = {
            'introduction': 'CHƯƠNG 1: MỞ ĐẦU',
            'literature_review': 'CHƯƠNG 2: TỔNG QUAN NGHIÊN CỨU',
            'methodology': 'CHƯƠNG 3: PHƯƠNG PHÁP NGHIÊN CỨU',
            'results': 'CHƯƠNG 4: KẾT QUẢ NGHIÊN CỨU',
            'discussion': 'CHƯƠNG 5: THẢO LUẬN KẾT QUẢ',
            'conclusion': 'CHƯƠNG 6: KẾT LUẬN VÀ KIẾN NGHỊ'
        }
        
        for chapter_key, content in ai_content.items():
            if chapter_key in chapter_mapping and chapter_key != 'abstract' and chapter_key != 'citations':
                # Add chapter heading
                chapter_heading = self.doc.add_heading(chapter_mapping[chapter_key], level=1)
                chapter_heading.alignment = WD_ALIGN_PARAGRAPH.CENTER
                
                # Add chapter content
                paragraphs = content.split('\n\n')
                for paragraph in paragraphs:
                    if paragraph.strip():
                        if paragraph.startswith('##'):
                            # This is a section heading
                            section_title = paragraph.replace('##', '').strip()
                            section_heading = self.doc.add_heading(section_title, level=2)
                        elif paragraph.startswith('#'):
                            # This is a chapter heading (skip as we already added it)
                            continue
                        else:
                            # Regular paragraph
                            para = self.doc.add_paragraph()
                            para.add_run(paragraph.strip())
                            para.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
                            para.paragraph_format.line_spacing_rule = WD_LINE_SPACING.ONE_POINT_FIVE
                
                self.doc.add_page_break()
    
    def _add_outline_chapters(self, outline: List[Dict]):
        """Add chapters based on outline structure"""
        for chapter in outline:
            # Chapter heading
            chapter_heading = self.doc.add_heading(chapter.get('title', ''), level=1)
            chapter_heading.alignment = WD_ALIGN_PARAGRAPH.CENTER
            
            # Chapter description
            if chapter.get('description'):
                desc_para = self.doc.add_paragraph()
                desc_para.add_run(chapter['description'].strip())
                desc_para.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
                desc_para.paragraph_format.space_after = Pt(12)
            
            # Sections
            if chapter.get('sections'):
                for section in chapter['sections']:
                    # Section heading
                    section_heading = self.doc.add_heading(
                        f"{section.get('number', '')} {section.get('title', '')}", 
                        level=2
                    )
                    
                    # Section description
                    if section.get('description'):
                        section_para = self.doc.add_paragraph()
                        section_para.add_run(section['description'])
                        section_para.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
                        section_para.paragraph_format.space_after = Pt(6)
            
            self.doc.add_page_break()
    
    def _add_statistical_chapter(self, statistical_content: str):
        """Add statistical analysis chapter"""
        stats_heading = self.doc.add_heading('PHỤ LỤC: PHÂN TÍCH THỐNG KÊ', level=1)
        stats_heading.alignment = WD_ALIGN_PARAGRAPH.CENTER
        
        # Add statistical content
        paragraphs = statistical_content.split('\n\n')
        for paragraph in paragraphs:
            if paragraph.strip():
                if paragraph.startswith('###'):
                    # Subsection heading
                    subsection_title = paragraph.replace('###', '').strip()
                    subsection_heading = self.doc.add_heading(subsection_title, level=3)
                elif paragraph.startswith('##'):
                    # Section heading
                    section_title = paragraph.replace('##', '').strip()
                    section_heading = self.doc.add_heading(section_title, level=2)
                elif paragraph.startswith('**') and paragraph.endswith('**'):
                    # Bold paragraph
                    para = self.doc.add_paragraph()
                    run = para.add_run(paragraph.replace('**', ''))
                    run.bold = True
                    para.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
                else:
                    # Regular paragraph
                    para = self.doc.add_paragraph()
                    para.add_run(paragraph.strip())
                    para.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
        
        self.doc.add_page_break()
    
    def _add_references(self, citations: List[str]):
        """Add references section"""
        ref_heading = self.doc.add_heading('TÀI LIỆU THAM KHẢO', level=1)
        ref_heading.alignment = WD_ALIGN_PARAGRAPH.CENTER
        
        # Add citations
        for i, citation in enumerate(citations, 1):
            ref_para = self.doc.add_paragraph()
            ref_para.add_run(f"{i}. {citation}")
            ref_para.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
            ref_para.paragraph_format.left_indent = Inches(0.5)
            ref_para.paragraph_format.first_line_indent = Inches(-0.5)
    
    def add_chart_to_document(self, chart_data: bytes, chart_title: str):
        """Add chart to document (placeholder for future implementation)"""
        # This would require additional libraries like python-docx-template or docx2pdf
        # For now, we'll add a placeholder
        chart_para = self.doc.add_paragraph()
        chart_para.add_run(f"[Biểu đồ: {chart_title}]")
        chart_para.alignment = WD_ALIGN_PARAGRAPH.CENTER
    
    def create_outline_document(self, outline: List[Dict], thesis_data: Dict) -> io.BytesIO:
        """Create outline-only document (original functionality)"""
        self.doc = Document()
        self._setup_document_format()
        
        # Title page
        self._add_title_page(thesis_data)
        self.doc.add_page_break()
        
        # Table of contents
        self._add_table_of_contents(outline)
        self.doc.add_page_break()
        
        # Detailed outline
        self._add_outline_chapters(outline)
        
        # Save to buffer
        doc_buffer = io.BytesIO()
        self.doc.save(doc_buffer)
        doc_buffer.seek(0)
        
        return doc_buffer
