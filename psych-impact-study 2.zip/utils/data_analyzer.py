import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import plotly.express as px
import plotly.graph_objects as go
from scipy import stats
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans
from sklearn.linear_model import LinearRegression
from sklearn.metrics import r2_score
import io
import base64

class DataAnalyzer:
    """
    Comprehensive data analysis for thesis research
    """
    
    def __init__(self):
        self.data = None
        self.numeric_columns = []
        self.categorical_columns = []
        
    def load_data(self, uploaded_file):
        """
        Load data from uploaded file (Excel, CSV)
        """
        try:
            if uploaded_file.name.endswith('.xlsx') or uploaded_file.name.endswith('.xls'):
                self.data = pd.read_excel(uploaded_file)
            elif uploaded_file.name.endswith('.csv'):
                self.data = pd.read_csv(uploaded_file)
            else:
                raise ValueError("Định dạng file không được hỗ trợ. Vui lòng sử dụng Excel hoặc CSV.")
            
            # Classify columns
            self.numeric_columns = self.data.select_dtypes(include=[np.number]).columns.tolist()
            self.categorical_columns = self.data.select_dtypes(include=['object', 'category']).columns.tolist()
            
            return True, "Tải dữ liệu thành công!"
            
        except Exception as e:
            return False, f"Lỗi tải dữ liệu: {str(e)}"
    
    def get_descriptive_statistics(self):
        """
        Generate comprehensive descriptive statistics
        """
        if self.data is None:
            return None
            
        stats_dict = {
            'basic_info': {
                'total_records': len(self.data),
                'total_variables': len(self.data.columns),
                'numeric_variables': len(self.numeric_columns),
                'categorical_variables': len(self.categorical_columns),
                'missing_values': self.data.isnull().sum().sum()
            },
            'numeric_stats': {},
            'categorical_stats': {}
        }
        
        # Numeric variables statistics
        if self.numeric_columns:
            numeric_desc = self.data[self.numeric_columns].describe()
            for col in self.numeric_columns:
                stats_dict['numeric_stats'][col] = {
                    'mean': numeric_desc.loc['mean', col],
                    'std': numeric_desc.loc['std', col],
                    'min': numeric_desc.loc['min', col],
                    'max': numeric_desc.loc['max', col],
                    'median': numeric_desc.loc['50%', col],
                    'missing_count': self.data[col].isnull().sum(),
                    'missing_percent': (self.data[col].isnull().sum() / len(self.data)) * 100
                }
        
        # Categorical variables statistics
        if self.categorical_columns:
            for col in self.categorical_columns:
                value_counts = self.data[col].value_counts()
                stats_dict['categorical_stats'][col] = {
                    'unique_values': self.data[col].nunique(),
                    'most_frequent': value_counts.index[0] if len(value_counts) > 0 else None,
                    'most_frequent_count': value_counts.iloc[0] if len(value_counts) > 0 else 0,
                    'missing_count': self.data[col].isnull().sum(),
                    'missing_percent': (self.data[col].isnull().sum() / len(self.data)) * 100
                }
        
        return stats_dict
    
    def create_visualizations(self):
        """
        Create various visualizations for the data
        """
        if self.data is None:
            return []
        
        visualizations = []
        
        # Distribution plots for numeric variables
        for col in self.numeric_columns[:4]:  # Limit to first 4 to avoid too many plots
            fig = px.histogram(
                self.data, 
                x=col, 
                title=f'Phân bố của {col}',
                labels={col: col, 'count': 'Tần số'}
            )
            fig.update_layout(
                title_font_size=16,
                xaxis_title=col,
                yaxis_title='Tần số'
            )
            visualizations.append({
                'type': 'histogram',
                'variable': col,
                'figure': fig
            })
        
        # Box plots for numeric variables
        if len(self.numeric_columns) >= 2:
            fig = go.Figure()
            for col in self.numeric_columns[:4]:
                fig.add_trace(go.Box(y=self.data[col], name=col))
            fig.update_layout(
                title='Biểu đồ hộp so sánh các biến số',
                yaxis_title='Giá trị'
            )
            visualizations.append({
                'type': 'boxplot',
                'variable': 'multiple',
                'figure': fig
            })
        
        # Bar charts for categorical variables
        for col in self.categorical_columns[:3]:  # Limit to first 3
            value_counts = self.data[col].value_counts().head(10)  # Top 10 categories
            fig = px.bar(x=value_counts.index, y=value_counts.values, 
                        title=f'Tần số của {col}')
            fig.update_layout(
                title_font_size=16,
                xaxis_title=col,
                yaxis_title='Tần số'
            )
            visualizations.append({
                'type': 'bar_chart',
                'variable': col,
                'figure': fig
            })
        
        # Correlation heatmap if we have enough numeric variables
        if len(self.numeric_columns) >= 2:
            correlation_matrix = self.data[self.numeric_columns].corr()
            fig = px.imshow(correlation_matrix, 
                          title='Ma trận tương quan',
                          color_continuous_scale='RdBu_r',
                          aspect='auto',
                          x=correlation_matrix.columns,
                          y=correlation_matrix.columns)
            fig.update_layout(title_font_size=16)
            visualizations.append({
                'type': 'correlation_heatmap',
                'variable': 'correlation',
                'figure': fig
            })
        
        return visualizations
    
    def perform_correlation_analysis(self):
        """
        Perform correlation analysis between numeric variables
        """
        if self.data is None or len(self.numeric_columns) < 2:
            return None
        
        correlation_matrix = self.data[self.numeric_columns].corr()
        
        # Find strong correlations (|r| > 0.5)
        strong_correlations = []
        for i in range(len(correlation_matrix.columns)):
            for j in range(i+1, len(correlation_matrix.columns)):
                var1 = correlation_matrix.columns[i]
                var2 = correlation_matrix.columns[j]
                corr_value = correlation_matrix.iloc[i, j]
                
                if abs(corr_value) > 0.5:
                    # Determine correlation strength
                    if abs(corr_value) > 0.8:
                        strength = "rất mạnh"
                    elif abs(corr_value) > 0.6:
                        strength = "mạnh"
                    else:
                        strength = "trung bình"
                    
                    direction = "dương" if corr_value > 0 else "âm"
                    
                    strong_correlations.append({
                        'var1': var1,
                        'var2': var2,
                        'correlation': corr_value,
                        'strength': strength,
                        'direction': direction
                    })
        
        return {
            'correlation_matrix': correlation_matrix.to_dict(),
            'strong_correlations': strong_correlations
        }
    
    def perform_regression_analysis(self, dependent_var, independent_vars):
        """
        Perform linear regression analysis
        """
        if self.data is None:
            return None
        
        try:
            # Prepare data
            X = self.data[independent_vars].dropna()
            y = self.data[dependent_var].loc[X.index]
            
            # Fit regression model
            model = LinearRegression()
            model.fit(X, y)
            
            # Predictions
            y_pred = model.predict(X)
            
            # Calculate metrics
            r2 = r2_score(y, y_pred)
            
            # Coefficients
            coefficients = {}
            for i, var in enumerate(independent_vars):
                coefficients[var] = model.coef_[i]
            
            return {
                'r_squared': r2,
                'intercept': model.intercept_,
                'coefficients': coefficients,
                'n_observations': len(X),
                'dependent_variable': dependent_var,
                'independent_variables': independent_vars
            }
            
        except Exception as e:
            return {'error': str(e)}
    
    def generate_statistical_summary(self):
        """
        Generate a comprehensive statistical summary for thesis
        """
        if self.data is None:
            return "Không có dữ liệu để phân tích."
        
        desc_stats = self.get_descriptive_statistics()
        corr_analysis = self.perform_correlation_analysis()
        
        summary = f"""
## PHÂN TÍCH THỐNG KÊ MÔ TẢ

### 1. Thông tin tổng quan về dữ liệu
- Tổng số quan sát: {desc_stats['basic_info']['total_records']}
- Tổng số biến: {desc_stats['basic_info']['total_variables']}
- Biến định lượng: {desc_stats['basic_info']['numeric_variables']}
- Biến định tính: {desc_stats['basic_info']['categorical_variables']}
- Giá trị thiếu: {desc_stats['basic_info']['missing_values']}

### 2. Thống kê mô tả các biến định lượng
"""
        
        for var, stats in desc_stats['numeric_stats'].items():
            summary += f"""
**{var}:**
- Trung bình: {stats['mean']:.2f}
- Độ lệch chuẩn: {stats['std']:.2f}
- Giá trị nhỏ nhất: {stats['min']:.2f}
- Giá trị lớn nhất: {stats['max']:.2f}
- Trung vị: {stats['median']:.2f}
- Tỷ lệ thiếu: {stats['missing_percent']:.1f}%
"""
        
        summary += "\n### 3. Thống kê mô tả các biến định tính\n"
        
        for var, stats in desc_stats['categorical_stats'].items():
            summary += f"""
**{var}:**
- Số lượng nhóm: {stats['unique_values']}
- Nhóm phổ biến nhất: {stats['most_frequent']} ({stats['most_frequent_count']} quan sát)
- Tỷ lệ thiếu: {stats['missing_percent']:.1f}%
"""
        
        if corr_analysis and corr_analysis.get('strong_correlations'):
            summary += "\n### 4. Phân tích tương quan\n"
            summary += "Các mối tương quan mạnh được phát hiện:\n"
            
            for corr in corr_analysis['strong_correlations']:
                summary += f"- {corr['var1']} và {corr['var2']}: r = {corr['correlation']:.3f} (tương quan {corr['direction']} {corr['strength']})\n"
        
        return summary
