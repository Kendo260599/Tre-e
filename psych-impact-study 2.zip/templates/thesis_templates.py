class ThesisTemplates:
    """
    Templates for Vietnamese academic thesis outlines
    """
    
    def get_masters_structure(self):
        """
        Standard structure for Master's thesis in Vietnam
        """
        return [
            {
                "id": "introduction",
                "title": "CHƯƠNG 1: MỞ ĐẦU",
                "description": "",
                "sections": [
                    {"number": "1.1", "title": "Lý do chọn đề tài", "description": "Trình bày bối cảnh và tính cấp thiết của vấn đề nghiên cứu"},
                    {"number": "1.2", "title": "Mục tiêu nghiên cứu", "description": "Xác định mục tiêu tổng quát và các mục tiêu cụ thể"},
                    {"number": "1.3", "title": "Câu hỏi nghiên cứu", "description": "Đặt ra các câu hỏi nghiên cứu chính và phụ"},
                    {"number": "1.4", "title": "Đối tượng và phạm vi nghiên cứu", "description": "Xác định đối tượng, địa bàn và thời gian nghiên cứu"},
                    {"number": "1.5", "title": "Ý nghĩa khoa học và thực tiễn", "description": "Đóng góp lý thuyết và ứng dụng thực tiễn của nghiên cứu"},
                    {"number": "1.6", "title": "Cấu trúc luận văn", "description": "Tổng quan về cấu trúc và nội dung các chương"}
                ]
            },
            {
                "id": "literature_review",
                "title": "CHƯƠNG 2: TỔNG QUAN NGHIÊN CỨU",
                "description": "",
                "sections": [
                    {"number": "2.1", "title": "Các nghiên cứu trong nước", "description": "Tổng quan các nghiên cứu đã thực hiện tại Việt Nam"},
                    {"number": "2.2", "title": "Các nghiên cứu nước ngoài", "description": "Tổng quan các nghiên cứu quốc tế có liên quan"},
                    {"number": "2.3", "title": "Đánh giá tổng quan", "description": "Phân tích ưu điểm, hạn chế và khoảng trống nghiên cứu"},
                    {"number": "2.4", "title": "Định vị nghiên cứu", "description": "Xác định vị trí và đóng góp của nghiên cứu hiện tại"}
                ]
            },
            {
                "id": "theoretical_framework",
                "title": "CHƯƠNG 3: CƠ SỞ LÝ LUẬN",
                "description": "",
                "sections": [
                    {"number": "3.1", "title": "Hệ thống khái niệm", "description": "Định nghĩa và làm rõ các khái niệm cơ bản"},
                    {"number": "3.2", "title": "Cơ sở lý thuyết", "description": "Trình bày các lý thuyết nền tảng cho nghiên cứu"},
                    {"number": "3.3", "title": "Mô hình nghiên cứu", "description": "Xây dựng mô hình lý thuyết và các giả thuyết nghiên cứu"}
                ]
            },
            {
                "id": "methodology",
                "title": "CHƯƠNG 4: PHƯƠNG PHÁP NGHIÊN CỨU",
                "description": "",
                "sections": []  # Will be customized based on research approach
            },
            {
                "id": "results",
                "title": "CHƯƠNG 5: KẾT QUẢ NGHIÊN CỨU",
                "description": "",
                "sections": [
                    {"number": "5.1", "title": "Đặc điểm mẫu nghiên cứu", "description": "Mô tả chi tiết về mẫu nghiên cứu đã thu thập"},
                    {"number": "5.2", "title": "Kết quả phân tích dữ liệu", "description": "Trình bày kết quả phân tích theo từng câu hỏi nghiên cứu"},
                    {"number": "5.3", "title": "Kiểm định giả thuyết", "description": "Kiểm tra các giả thuyết nghiên cứu (nếu có)"}
                ]
            },
            {
                "id": "discussion",
                "title": "CHƯƠNG 6: THẢO LUẬN KẾT QUẢ",
                "description": "",
                "sections": [
                    {"number": "6.1", "title": "Thảo luận các phát hiện chính", "description": "Giải thích và bình luận về các kết quả quan trọng"},
                    {"number": "6.2", "title": "So sánh với các nghiên cứu trước", "description": "Đối chiếu kết quả với các nghiên cứu đã công bố"},
                    {"number": "6.3", "title": "Hạn chế của nghiên cứu", "description": "Thành thật trình bày những hạn chế và khó khăn"}
                ]
            },
            {
                "id": "conclusion",
                "title": "CHƯƠNG 7: KẾT LUẬN VÀ KIẾN NGHỊ",
                "description": "",
                "sections": [
                    {"number": "7.1", "title": "Tóm tắt các phát hiện chính", "description": "Tổng hợp những đóng góp chủ yếu của nghiên cứu"},
                    {"number": "7.2", "title": "Kiến nghị thực tiễn", "description": "Đề xuất các giải pháp và ứng dụng thực tế"},
                    {"number": "7.3", "title": "Hướng nghiên cứu tiếp theo", "description": "Gợi ý cho các nghiên cứu tương lai"}
                ]
            }
        ]
    
    def get_doctoral_structure(self):
        """
        Extended structure for Doctoral dissertation in Vietnam
        """
        return [
            {
                "id": "introduction",
                "title": "CHƯƠNG 1: MỞ ĐẦU",
                "description": "",
                "sections": [
                    {"number": "1.1", "title": "Lý do chọn đề tài", "description": "Tính cấp thiết và ý nghĩa khoa học của vấn đề nghiên cứu"},
                    {"number": "1.2", "title": "Tình hình nghiên cứu liên quan", "description": "Tổng quan nhanh về tình hình nghiên cứu trong và ngoài nước"},
                    {"number": "1.3", "title": "Mục tiêu nghiên cứu", "description": "Mục tiêu tổng quát và các mục tiêu cụ thể của luận án"},
                    {"number": "1.4", "title": "Câu hỏi nghiên cứu và giả thuyết", "description": "Hệ thống câu hỏi nghiên cứu và các giả thuyết khoa học"},
                    {"number": "1.5", "title": "Đối tượng và phạm vi nghiên cứu", "description": "Đối tượng nghiên cứu, phạm vi không gian và thời gian"},
                    {"number": "1.6", "title": "Phương pháp nghiên cứu", "description": "Tổng quan về phương pháp luận và các phương pháp cụ thể"},
                    {"number": "1.7", "title": "Ý nghĩa khoa học và thực tiễn", "description": "Đóng góp mới về mặt lý thuyết và ứng dụng thực tiễn"},
                    {"number": "1.8", "title": "Cấu trúc luận án", "description": "Bố cục và nội dung chính của luận án"}
                ]
            },
            {
                "id": "literature_review",
                "title": "CHƯƠNG 2: TỔNG QUAN NGHIÊN CỨU",
                "description": "",
                "sections": [
                    {"number": "2.1", "title": "Nghiên cứu trong nước", "description": "Phân tích chi tiết các nghiên cứu trong nước theo thời gian và chủ đề"},
                    {"number": "2.2", "title": "Nghiên cứu quốc tế", "description": "Tổng quan có hệ thống các nghiên cứu quốc tế tiêu biểu"},
                    {"number": "2.3", "title": "Phân tích so sánh", "description": "So sánh, đối chiếu các hướng tiếp cận và phương pháp nghiên cứu"},
                    {"number": "2.4", "title": "Khoảng trống nghiên cứu", "description": "Xác định những vấn đề chưa được nghiên cứu hoặc cần nghiên cứu sâu hơn"},
                    {"number": "2.5", "title": "Định vị luận án", "description": "Khẳng định vị trí và đóng góp độc đáo của luận án"}
                ]
            },
            {
                "id": "theoretical_framework",
                "title": "CHƯƠNG 3: CƠ SỞ LÝ LUẬN VÀ THỰC TIỄN",
                "description": "",
                "sections": [
                    {"number": "3.1", "title": "Hệ thống khái niệm và thuật ngữ", "description": "Làm rõ và thống nhất các khái niệm cơ bản"},
                    {"number": "3.2", "title": "Cơ sở lý thuyết", "description": "Hệ thống hóa các lý thuyết nền tảng và phát triển"},
                    {"number": "3.3", "title": "Cơ sở thực tiễn", "description": "Phân tích thực trạng và bối cảnh thực tiễn của vấn đề"},
                    {"number": "3.4", "title": "Khung lý thuyết nghiên cứu", "description": "Xây dựng khung lý thuyết tổng hợp cho luận án"},
                    {"number": "3.5", "title": "Mô hình và giả thuyết nghiên cứu", "description": "Phát triển mô hình nghiên cứu và hệ thống giả thuyết"}
                ]
            },
            {
                "id": "methodology",
                "title": "CHƯƠNG 4: PHƯƠNG PHÁP LUẬN VÀ PHƯƠNG PHÁP NGHIÊN CỨU",
                "description": "",
                "sections": []  # Will be customized based on research approach
            },
            {
                "id": "empirical_study",
                "title": "CHƯƠNG 5: NGHIÊN CỨU THỰC NGHIỆM",
                "description": "Trình bày chi tiết quá trình thực hiện nghiên cứu thực nghiệm, bao gồm thiết kế, triển khai và thu thập dữ liệu.",
                "sections": [
                    {"number": "5.1", "title": "Thiết kế nghiên cứu thực nghiệm", "description": "Mô tả chi tiết về thiết kế và quy trình nghiên cứu"},
                    {"number": "5.2", "title": "Thực hiện nghiên cứu", "description": "Quá trình triển khai nghiên cứu trên thực tế"},
                    {"number": "5.3", "title": "Thu thập và xử lý dữ liệu", "description": "Quy trình thu thập, làm sạch và chuẩn bị dữ liệu phân tích"}
                ]
            },
            {
                "id": "results",
                "title": "CHƯƠNG 6: KẾT QUẢ NGHIÊN CỨU",
                "description": "",
                "sections": [
                    {"number": "6.1", "title": "Kết quả mô tả", "description": "Thống kê mô tả về mẫu nghiên cứu và các biến số"},
                    {"number": "6.2", "title": "Kết quả phân tích chính", "description": "Trình bày kết quả phân tích theo từng mục tiêu nghiên cứu"},
                    {"number": "6.3", "title": "Kiểm định mô hình và giả thuyết", "description": "Kết quả kiểm định các mô hình và giả thuyết nghiên cứu"},
                    {"number": "6.4", "title": "Phân tích bổ sung", "description": "Các phân tích sâu thêm và kiểm tra độ robust của kết quả"}
                ]
            },
            {
                "id": "discussion",
                "title": "CHƯƠNG 7: THẢO LUẬN KẾT QUẢ NGHIÊN CỨU",
                "description": "",
                "sections": [
                    {"number": "7.1", "title": "Thảo luận các phát hiện chính", "description": "Diễn giải và bình luận sâu sắc về các kết quả quan trọng"},
                    {"number": "7.2", "title": "So sánh với nghiên cứu trước đây", "description": "Đối chiếu và so sánh với các nghiên cứu trong và ngoài nước"},
                    {"number": "7.3", "title": "Đóng góp lý thuyết", "description": "Làm rõ những đóng góp mới về mặt lý thuyết"},
                    {"number": "7.4", "title": "Ý nghĩa thực tiễn", "description": "Phân tích ý nghĩa và ứng dụng thực tiễn của nghiên cứu"},
                    {"number": "7.5", "title": "Hạn chế nghiên cứu", "description": "Thảo luận thành thật về những hạn chế và điều kiện của nghiên cứu"}
                ]
            },
            {
                "id": "conclusion",
                "title": "CHƯƠNG 8: KẾT LUẬN VÀ KIẾN NGHỊ",
                "description": "",
                "sections": [
                    {"number": "8.1", "title": "Những đóng góp chính của luận án", "description": "Tóm tắt những đóng góp mới về lý thuyết và thực tiễn"},
                    {"number": "8.2", "title": "Kiến nghị chính sách", "description": "Đề xuất các giải pháp chính sách dựa trên kết quả nghiên cứu"},
                    {"number": "8.3", "title": "Kiến nghị cho thực tiễn", "description": "Hướng dẫn ứng dụng kết quả nghiên cứu vào thực tiễn"},
                    {"number": "8.4", "title": "Hướng nghiên cứu tiếp theo", "description": "Đề xuất các hướng nghiên cứu mở rộng và phát triển"}
                ]
            }
        ]
