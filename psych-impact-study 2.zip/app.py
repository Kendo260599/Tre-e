import streamlit as st
import io
import pandas as pd
from thesis_generator import ThesisOutlineGenerator
from utils.document_generator import DocumentGenerator
from utils.enhanced_document_generator import EnhancedDocumentGenerator
from utils.enhanced_peer_review_panel import EnhancedPeerReviewPanel
from utils.global_academic_database import GlobalAcademicDatabase
from utils.visual_research_model_generator import VisualResearchModelGenerator
from utils.data_analyzer import DataAnalyzer
from utils.advanced_ai_generator import AdvancedAIGenerator
from utils.academic_reviewer import DoctoralAcademicReviewer
from utils.theoretical_framework_generator import TheoreticalFrameworkGenerator
from utils.advanced_data_analyzer import AdvancedDataAnalyzer
from utils.simulated_peer_review import SimulatedPeerReviewPanel

def main():
    st.set_page_config(
        page_title="AutoThesis Writer",
        page_icon="🎓",
        layout="wide"
    )

    st.title("🎓 AutoThesis Writer")
    st.markdown("*Hệ thống tạo luận văn hoàn chỉnh với AI và phân tích dữ liệu*")

    # Navigation tabs
    tab1, tab2, tab3, tab4, tab5, tab6 = st.tabs(["📝 Thông tin cơ bản", "🧠 Khung lý thuyết", "📊 Phân tích dữ liệu", "🤖 Tạo nội dung", "🔍 Phản biện hội đồng", "📄 Kết quả"])

    # Initialize session state
    if 'thesis_data' not in st.session_state:
        st.session_state.thesis_data = {}
    if 'outline_generated' not in st.session_state:
        st.session_state.outline_generated = False
    if 'data_analyzed' not in st.session_state:
        st.session_state.data_analyzed = False
    if 'data_analyzer' not in st.session_state:
        st.session_state.data_analyzer = DataAnalyzer()
    if 'ai_generator' not in st.session_state:
        st.session_state.ai_generator = AdvancedAIGenerator()
    if 'academic_reviewer' not in st.session_state:
        st.session_state.academic_reviewer = DoctoralAcademicReviewer()
    if 'framework_generator' not in st.session_state:
        st.session_state.framework_generator = TheoreticalFrameworkGenerator()
    if 'advanced_analyzer' not in st.session_state:
        st.session_state.advanced_analyzer = AdvancedDataAnalyzer()
    if 'peer_review_panel' not in st.session_state:
        st.session_state.peer_review_panel = SimulatedPeerReviewPanel()
    if 'enhanced_peer_review' not in st.session_state:
        st.session_state.enhanced_peer_review = EnhancedPeerReviewPanel()
    if 'academic_database' not in st.session_state:
        st.session_state.academic_database = GlobalAcademicDatabase()
    if 'visual_model_generator' not in st.session_state:
        st.session_state.visual_model_generator = VisualResearchModelGenerator()

    with tab1:
        st.header("📝 Thông tin cơ bản luận văn")

        col1, col2 = st.columns([1, 1])

        with col1:
            # Input form
            thesis_topic = st.text_area(
                "Chủ đề luận văn",
                value=st.session_state.thesis_data.get('topic', ''),
                placeholder="Ví dụ: Ảnh hưởng của khó khăn tâm lý đến kết quả học tập của sinh viên dân tộc thiểu số tại trường cao đẳng nghề",
                height=100
            )

            field_of_study = st.selectbox(
                "Ngành học",
                [
                    "Tâm lý học giáo dục",
                    "Khoa học giáo dục",
                    "Quản trị kinh doanh",
                    "Kinh tế học",
                    "Công nghệ thông tin",
                    "Kỹ thuật",
                    "Y học",
                    "Luật học",
                    "Ngôn ngữ học",
                    "Văn học",
                    "Lịch sử",
                    "Triết học",
                    "Xã hội học",
                    "Chính trị học",
                    "Môi trường",
                    "Nông nghiệp",
                    "Khác"
                ],
                index=0 if 'field' not in st.session_state.thesis_data else 
                      ["Tâm lý học giáo dục", "Khoa học giáo dục", "Quản trị kinh doanh", "Kinh tế học", 
                       "Công nghệ thông tin", "Kỹ thuật", "Y học", "Luật học", "Ngôn ngữ học", "Văn học", 
                       "Lịch sử", "Triết học", "Xã hội học", "Chính trị học", "Môi trường", "Nông nghiệp", "Khác"
                      ].index(st.session_state.thesis_data['field']) if st.session_state.thesis_data['field'] in 
                      ["Tâm lý học giáo dục", "Khoa học giáo dục", "Quản trị kinh doanh", "Kinh tế học", 
                       "Công nghệ thông tin", "Kỹ thuật", "Y học", "Luật học", "Ngôn ngữ học", "Văn học", 
                       "Lịch sử", "Triết học", "Xã hội học", "Chính trị học", "Môi trường", "Nông nghiệp", "Khác"] else 0
            )

            if field_of_study == "Khác":
                custom_field = st.text_input("Nhập ngành học khác")
                if custom_field:
                    field_of_study = custom_field

            degree_level = st.selectbox(
                "Trình độ",
                ["Thạc sĩ", "Tiến sĩ"],
                index=0 if 'level' not in st.session_state.thesis_data else 
                      ["Thạc sĩ", "Tiến sĩ"].index(st.session_state.thesis_data['level'])
            )

            research_objectives = st.text_area(
                "Mục tiêu nghiên cứu",
                value=st.session_state.thesis_data.get('objectives', ''),
                placeholder="Ví dụ: Phân tích các yếu tố gây khó khăn tâm lý và đề xuất biện pháp hỗ trợ",
                height=80
            )

            research_approach = st.selectbox(
                "Phương pháp nghiên cứu chính",
                [
                    "Nghiên cứu định lượng",
                    "Nghiên cứu định tính",
                    "Nghiên cứu hỗn hợp (định lượng + định tính)",
                    "Nghiên cứu thực nghiệm",
                    "Nghiên cứu khảo sát",
                    "Nghiên cứu tài liệu"
                ],
                index=0 if 'approach' not in st.session_state.thesis_data else 
                      ["Nghiên cứu định lượng", "Nghiên cứu định tính", "Nghiên cứu hỗn hợp (định lượng + định tính)",
                       "Nghiên cứu thực nghiệm", "Nghiên cứu khảo sát", "Nghiên cứu tài liệu"
                      ].index(st.session_state.thesis_data['approach'])
            )

            # Save basic info button
            if st.button("💾 Lưu thông tin cơ bản", type="primary", use_container_width=True):
                if thesis_topic and research_objectives:
                    st.session_state.thesis_data.update({
                        'topic': thesis_topic,
                        'field': field_of_study,
                        'level': degree_level,
                        'objectives': research_objectives,
                        'approach': research_approach
                    })
                    st.success("✅ Đã lưu thông tin cơ bản!")
                else:
                    st.error("Vui lòng điền đầy đủ chủ đề và mục tiêu nghiên cứu.")

        with col2:
            st.subheader("📋 Thông tin đã lưu")
            if st.session_state.thesis_data:
                st.write("**Chủ đề:**", st.session_state.thesis_data.get('topic', 'Chưa nhập'))
                st.write("**Ngành học:**", st.session_state.thesis_data.get('field', 'Chưa chọn'))
                st.write("**Trình độ:**", st.session_state.thesis_data.get('level', 'Chưa chọn'))
                st.write("**Phương pháp:**", st.session_state.thesis_data.get('approach', 'Chưa chọn'))
            else:
                st.info("👆 Điền thông tin bên trái và nhấn 'Lưu thông tin cơ bản'")

            # Generate outline section
            st.subheader("🎯 Tạo đề cương")
            if st.button("📋 Tạo đề cương luận văn", use_container_width=True):
                if st.session_state.thesis_data:
                    with st.spinner("Đang tạo đề cương..."):
                        generator = ThesisOutlineGenerator()
                        outline = generator.generate_outline(
                            topic=st.session_state.thesis_data['topic'],
                            field=st.session_state.thesis_data['field'],
                            level=st.session_state.thesis_data['level'],
                            objectives=st.session_state.thesis_data['objectives'],
                            approach=st.session_state.thesis_data['approach']
                        )
                        st.session_state.thesis_data['outline'] = outline
                        st.session_state.outline_generated = True
                    st.success("✅ Đã tạo đề cương thành công!")
                else:
                    st.error("Vui lòng lưu thông tin cơ bản trước khi tạo đề cương.")

    with tab2:
        st.header("🧠 Tự động xây dựng khung lý thuyết")

        if not st.session_state.thesis_data.get('topic') or not st.session_state.thesis_data.get('field'):
            st.warning("⚠️ Vui lòng hoàn thành thông tin cơ bản ở tab trước để tạo khung lý thuyết.")
        else:
            col1, col2 = st.columns([1, 1])

            with col1:
                st.subheader("⚙️ Cấu hình khung lý thuyết")

                # Research paradigm selection
                research_paradigm = st.selectbox(
                    "Chọn paradigm nghiên cứu",
                    ["Positivist (Thực chứng)", "Interpretivist (Giải thích)", "Pragmatist (Thực dụng)", "Critical (Phê bình)"],
                    help="Paradigm nghiên cứu sẽ ảnh hưởng đến cách chọn lý thuyết và phương pháp"
                )

                # Variable relationships complexity
                complexity_level = st.select_slider(
                    "Mức độ phức tạp mô hình",
                    options=["Đơn giản", "Trung bình", "Phức tạp", "Rất phức tạp"],
                    value="Trung bình",
                    help="Mức độ phức tạp của mô hình nghiên cứu (số lượng biến và mối quan hệ)"
                )

                # Focus areas
                st.subheader("🎯 Trọng tâm nghiên cứu")
                focus_areas = st.multiselect(
                    "Chọn các khía cạnh trọng tâm",
                    ["Động lực", "Hành vi", "Hiệu suất", "Thái độ", "Sự hài lòng", "Chất lượng", "Đổi mới", "Lãnh đạo"],
                    default=["Hiệu suất", "Thái độ"],
                    help="Các khía cạnh này sẽ được ưu tiên trong khung lý thuyết"
                )

                # Generate framework button
                if st.button("🧠 Tạo khung lý thuyết tự động", type="primary", use_container_width=True):
                    with st.spinner("Đang phân tích và xây dựng khung lý thuyết..."):
                        try:
                            framework_result = st.session_state.framework_generator.generate_theoretical_framework(
                                topic=st.session_state.thesis_data['topic'],
                                field=st.session_state.thesis_data['field'],
                                research_approach=st.session_state.thesis_data['approach']
                            )

                            # Store framework results
                            st.session_state.thesis_data['theoretical_framework'] = framework_result
                            st.success("✅ Khung lý thuyết đã được tạo thành công!")
                        except Exception as e:
                            st.error(f"Lỗi khi tạo khung lý thuyết: {str(e)}")

                # Visual Research Model Generator
                st.markdown("---")
                st.subheader("🎯 Tạo mô hình nghiên cứu trực quan")

                model_complexity = st.selectbox(
                    "Mức độ phức tạp mô hình",
                    ["simple", "medium", "complex"],
                    format_func=lambda x: {"simple": "Đơn giản (2-3 biến chính)", 
                                         "medium": "Trung bình (4-6 biến)", 
                                         "complex": "Phức tạp (7+ biến)"}[x],
                    index=1
                )

                if st.button("🎨 Tạo mô hình nghiên cứu trực quan", use_container_width=True):
                    with st.spinner("Đang tạo mô hình nghiên cứu..."):
                        try:
                            # Generate research model
                            research_model = st.session_state.visual_model_generator.generate_research_model(
                                topic=st.session_state.thesis_data['topic'],
                                field=st.session_state.thesis_data['field'],
                                complexity=model_complexity
                            )

                            # Create visual diagram
                            diagram_base64 = st.session_state.visual_model_generator.create_visual_diagram(
                                research_model, "structural"
                            )

                            # Export model description
                            model_description = st.session_state.visual_model_generator.export_model_description(research_model)

                            # Store in session state
                            st.session_state.thesis_data['research_model'] = {
                                'model': research_model,
                                'diagram': diagram_base64,
                                'description': model_description
                            }

                            st.success("✅ Mô hình nghiên cứu trực quan đã được tạo!")
                        except Exception as e:
                            st.error(f"Lỗi khi tạo mô hình: {str(e)}")

            with col2:
                st.subheader("📊 Kết quả khung lý thuyết")

                if 'theoretical_framework' in st.session_state.thesis_data:
                    framework = st.session_state.thesis_data['theoretical_framework']

                    # Display key theories
                    st.markdown("### 🏛️ Các lý thuyết chính")
                    for theory in framework['recommended_theories']:
                        with st.expander(f"📚 {theory['name']} (Mức liên quan: {theory['relevance']:.0%})"):
                            st.markdown(f"**Khái niệm:** {theory['concept']}")
                            theory_desc = theory['description']
                            st.markdown(f"**Mô tả:** {theory_desc['description']}")
                            st.markdown(f"**Ứng dụng:** {theory_desc['application']}")

                    # Display conceptual model
                    st.markdown("### 🔗 Mô hình nghiên cứu")
                    model = framework['conceptual_model']

                    col_vars1, col_vars2 = st.columns(2)
                    with col_vars1:
                        st.markdown("**Biến độc lập:**")
                        for var in model['independent_variables']:
                            st.markdown(f"• {var.replace('_', ' ').title()}")

                        st.markdown("**Biến trung gian:**")
                        for var in model['mediating_variables']:
                            st.markdown(f"• {var.replace('_', ' ').title()}")

                    with col_vars2:
                        st.markdown("**Biến phụ thuộc:**")
                        for var in model['dependent_variables']:
                            st.markdown(f"• {var.replace('_', ' ').title()}")

                        st.markdown("**Biến điều tiết:**")
                        for var in model['moderating_variables']:
                            st.markdown(f"• {var.replace('_', ' ').title()}")

                    # Display hypotheses
                    st.markdown("### 🎯 Các giả thuyết nghiên cứu")
                    for i, hypothesis in enumerate(framework['hypotheses'], 1):
                        st.markdown(f"{i}. {hypothesis}")

                    # Framework diagram description
                    st.markdown("### 🎨 Mô tả sơ đồ khung lý thuyết")
                    st.markdown(framework['framework_diagram'])

                # Display visual research model if available
                if 'research_model' in st.session_state.thesis_data:
                    st.markdown("---")
                    st.markdown("### 🔬 Mô hình nghiên cứu trực quan")

                    model_data = st.session_state.thesis_data['research_model']

                    # Display the diagram
                    if model_data['diagram']:
                        import base64
                        from io import BytesIO

                        # Decode and display image
                        image_data = base64.b64decode(model_data['diagram'])
                        st.image(image_data, caption="Mô hình nghiên cứu trực quan", use_column_width=True)

                    # Model description in expander
                    with st.expander("📋 Mô tả chi tiết mô hình nghiên cứu"):
                        st.markdown(model_data['description'])

                    # Statistical analysis plan
                    if st.button("📊 Tạo kế hoạch phân tích thống kê", use_container_width=True):
                        analysis_plan = st.session_state.visual_model_generator.create_statistical_analysis_plan(
                            model_data['model']
                        )

                        with st.expander("📈 Kế hoạch phân tích thống kê chi tiết"):
                            st.markdown(analysis_plan)

                        # Store analysis plan
                        st.session_state.thesis_data['statistical_analysis_plan'] = analysis_plan

                    # Download framework content
                    if st.button("📥 Tải nội dung khung lý thuyết", use_container_width=True):
                        framework_content = st.session_state.framework_generator.export_framework_content(
                            framework, st.session_state.thesis_data['topic']
                        )
                        st.download_button(
                            label="📥 Tải file khung lý thuyết",
                            data=framework_content.encode('utf-8'),
                            file_name="khung_ly_thuyet.txt",
                            mime="text/plain",
                            use_container_width=True
                        )
                else:
                    st.info("👆 Nhấn 'Tạo khung lý thuyết tự động' để xem kết quả")

    with tab3:
        st.header("📊 Phân tích dữ liệu nâng cao bằng AI")

        col1, col2 = st.columns([1, 1])

        with col1:
            st.subheader("📁 Tải lên dữ liệu")
            uploaded_file = st.file_uploader(
                "Chọn file dữ liệu (Excel hoặc CSV)",
                type=['xlsx', 'xls', 'csv'],
                help="Tải lên dữ liệu khảo sát để phân tích AI tự động"
            )

            # Research question for advanced analysis
            st.subheader("🎯 Câu hỏi nghiên cứu")
            research_question = st.text_area(
                "Nhập câu hỏi nghiên cứu để AI tự động chọn phương pháp phân tích phù hợp",
                placeholder="VD: Tác động của leadership style đến employee performance thông qua job satisfaction",
                help="AI sẽ dựa vào câu hỏi này để tự động chọn phương pháp thống kê phù hợp"
            )

            if uploaded_file is not None:
                try:
                    # Use advanced analyzer
                    import pandas as pd
                    if uploaded_file.name.endswith('.csv'):
                        df = pd.read_csv(uploaded_file)
                    else:
                        df = pd.read_excel(uploaded_file)

                    st.success(f"✅ Đã tải {len(df)} dòng dữ liệu với {len(df.columns)} cột")

                    # Show data preview
                    st.subheader("👀 Xem trước dữ liệu")
                    st.dataframe(df.head())

                    # Advanced AI analysis button
                    if st.button("🤖 Phân tích AI tự động", type="primary", use_container_width=True):
                        if research_question:
                            with st.spinner("AI đang phân tích dữ liệu và chọn phương pháp thống kê..."):
                                try:
                                    analysis_results = st.session_state.advanced_analyzer.analyze_dataset(
                                        df=df,
                                        research_question=research_question,
                                        variables_info=None
                                    )
                                    st.session_state.thesis_data['advanced_analysis'] = analysis_results
                                    st.success("✅ Phân tích AI hoàn thành!")
                                except Exception as e:
                                    st.error(f"Lỗi phân tích: {str(e)}")
                        else:
                            st.warning("⚠️ Vui lòng nhập câu hỏi nghiên cứu")

                except Exception as e:
                    st.error(f"Lỗi đọc file: {str(e)}")

        with col2:
            st.subheader("📊 Kết quả phân tích AI")

            if 'advanced_analysis' in st.session_state.thesis_data:
                results = st.session_state.thesis_data['advanced_analysis']

                # Data quality assessment
                st.markdown("### 📋 Đánh giá chất lượng dữ liệu")
                quality = results['data_quality']
                col_q1, col_q2 = st.columns(2)
                with col_q1:
                    st.metric("Số dòng", quality['total_rows'])
                    st.metric("Số cột", quality['total_columns'])
                with col_q2:
                    missing_pct = sum(v['percentage'] for v in quality['missing_data'].values()) / len(quality['missing_data'])
                    st.metric("Dữ liệu thiếu", f"{missing_pct:.1f}%")

                # Recommended methods
                st.markdown("### 🎯 Phương pháp phân tích được AI khuyến nghị")
                for rec in results['recommended_methods']:
                    with st.expander(f"📈 {rec['method']} - Ưu tiên: {rec['priority']}"):
                        st.markdown(f"**Mục đích:** {rec['purpose']}")

                # Statistical results
                if 'analysis_results' in results:
                    st.markdown("### 📊 Kết quả thống kê")

                    analysis = results['analysis_results']

                    # Correlation results
                    if 'correlation' in analysis:
                        st.markdown("#### 🔗 Phân tích tương quan")
                        corr_matrix = analysis['correlation']['correlation_matrix']
                        if corr_matrix:
                            import pandas as pd
                            df_corr = pd.DataFrame(corr_matrix)
                            st.dataframe(df_corr, use_container_width=True)

                    # Regression results
                    if 'regression' in analysis:
                        st.markdown("#### 📈 Phân tích hồi quy")
                        for reg in analysis['regression']['simple_regressions']:
                            if reg['significant']:
                                st.success(f"✅ {reg['independent_var']} → {reg['dependent_var']}: R² = {reg['r_squared']:.3f}")
                            else:
                                st.info(f"ℹ️ {reg['independent_var']} → {reg['dependent_var']}: Không có ý nghĩa thống kê")

                # Academic interpretation
                if 'interpretation' in results:
                    st.markdown("### 📝 Giải thích học thuật")
                    with st.expander("Xem giải thích chi tiết"):
                        st.markdown(results['interpretation'])

                # Download results chapter
                if st.button("📥 Tải chương kết quả nghiên cứu", use_container_width=True):
                    if 'results_chapter' in results:
                        st.download_button(
                            label="📥 Tải file chương kết quả",
                            data=results['results_chapter'].encode('utf-8'),
                            file_name="chuong_ket_qua_nghien_cuu.txt",
                            mime="text/plain",
                            use_container_width=True
                        )
            else:
                st.info("👆 Tải lên dữ liệu và chạy phân tích AI để xem kết quả")

    with tab4:
        st.header("🤖 Tạo nội dung luận văn với AI")

        if not st.session_state.outline_generated:
            st.warning("⚠️ Vui lòng tạo đề cương ở tab 'Thông tin cơ bản' trước khi tạo nội dung.")
        else:
            col1, col2 = st.columns([1, 1])

            with col1:
                st.subheader("⚙️ Cài đặt tạo nội dung")

                selected_chapters = st.multiselect(
                    "Chọn chương muốn tạo nội dung",
                    ["introduction", "literature_review", "methodology", "results", "discussion", "conclusion"],
                    default=["introduction", "methodology"],
                    format_func=lambda x: {
                        "introduction": "Chương 1: Mở đầu",
                        "literature_review": "Chương 2: Tổng quan nghiên cứu", 
                        "methodology": "Chương 3: Phương pháp nghiên cứu",
                        "results": "Chương 4: Kết quả nghiên cứu",
                        "discussion": "Chương 5: Thảo luận",
                        "conclusion": "Chương 6: Kết luận"
                    }[x]
                )

                content_length = st.selectbox(
                    "Độ dài nội dung",
                    ["short", "medium", "long"],
                    index=1,
                    format_func=lambda x: {"short": "Ngắn (~200 từ)", "medium": "Trung bình (~400 từ)", "long": "Dài (~600 từ)"}[x]
                )

                use_cerebras_ai = st.checkbox(
                    "🧠 Sử dụng Cerebras AI (Chất lượng cao)", 
                    value=True,
                    help="Sử dụng Cerebras AI để tạo nội dung chất lượng cao hơn với khả năng phân tích sâu"
                )

                include_citations = st.checkbox("Tạo danh mục tài liệu tham khảo", value=True)
                include_abstract = st.checkbox("Tạo tóm tắt luận văn", value=True)

                # Advanced features
                st.markdown("---")
                st.subheader("🌐 Tính năng nâng cao")

                use_global_db = st.checkbox(
                    "Kích hoạt Cơ sở dữ liệu học thuật toàn cầu", 
                    value=False,
                    help="Tích hợp với cơ sở dữ liệu nghiên cứu quốc tế để tăng độ chính xác và tính cập nhật"
                )

                # Generate content button
                if st.button("🎨 Tạo nội dung AI", type="primary", use_container_width=True):
                    if selected_chapters:
                        with st.spinner("AI đang tạo nội dung..."):
                            generated_content = {}

                            # Get global research context if enabled
                            global_context = None
                            if use_global_db:
                                with st.spinner("Đang tìm kiếm cơ sở dữ liệu học thuật toàn cầu..."):
                                    search_results = st.session_state.academic_database.search_research_papers(
                                        query=st.session_state.thesis_data['topic'],
                                        field=st.session_state.thesis_data['field'],
                                        max_results=15
                                    )

                                    global_context = st.session_state.academic_database.synthesize_research_context(
                                        search_results,
                                        "literature_review",
                                        st.session_state.thesis_data['topic']
                                    )

                                    # Store global research data
                                    st.session_state.thesis_data['global_research_context'] = global_context

                            # Generate doctoral-level content for selected chapters
                            for chapter in selected_chapters:
                                if use_cerebras_ai:
                                    # Sử dụng Cerebras AI
                                    content = st.session_state.ai_generator.generate_enhanced_content_with_cerebras(
                                        chapter_type=chapter,
                                        topic=st.session_state.thesis_data['topic'],
                                        field=st.session_state.thesis_data['field'],
                                        objectives=st.session_state.thesis_data['objectives'],
                                        global_context=global_context
                                    )
                                else:
                                    # Sử dụng phương pháp gốc
                                    if chapter == "introduction":
                                        content = st.session_state.ai_generator.generate_doctoral_introduction(
                                            topic=st.session_state.thesis_data['topic'],
                                            field=st.session_state.thesis_data['field'],
                                            objectives=st.session_state.thesis_data['objectives'],
                                            global_context=global_context
                                        )
                                    elif chapter == "literature_review":
                                        content = st.session_state.ai_generator.generate_doctoral_literature_review(
                                            topic=st.session_state.thesis_data['topic'],
                                            field=st.session_state.thesis_data['field'],
                                            global_context=global_context
                                        )
                                    elif chapter == "methodology":
                                        content = st.session_state.ai_generator.generate_advanced_methodology(
                                            approach=st.session_state.thesis_data['approach'],
                                            field=st.session_state.thesis_data['field'],
                                            topic=st.session_state.thesis_data['topic'],
                                            global_context=global_context
                                        )
                                elif chapter in ["results", "discussion", "conclusion"]:
                                    # Generate standard content for other chapters
                                    chapter_titles = {
                                        'results': 'KẾT QUẢ NGHIÊN CỨU',
                                        'discussion': 'THẢO LUẬN KẾT QUẢ', 
                                        'conclusion': 'KẾT LUẬN VÀ KIẾN NGHỊ'
                                    }
                                    chapter_nums = {'results': 4, 'discussion': 5, 'conclusion': 6}
                                    content = f"""# CHƯƠNG {chapter_nums.get(chapter, 4)}: {chapter_titles.get(chapter, chapter.upper())}

## Nội dung chương đang được phát triển

Chương này sẽ trình bày chi tiết về {chapter} trong nghiên cứu về {st.session_state.thesis_data['topic']}.

### Các phần chính:
1. Phân tích dữ liệu thu thập
2. Kết quả nghiên cứu định lượng  
3. Kết quả nghiên cứu định tính
4. Tích hợp và thảo luận kết quả
5. Ý nghĩa và đóng góp khoa học

*Nội dung chi tiết sẽ được bổ sung dựa trên dữ liệu nghiên cứu thực tế.*
"""
                                    generated_content[chapter] = content
                                else:
                                    # Fallback content for any other chapters
                                    content = f"""# CHƯƠNG: {chapter.upper()}

## Nội dung đang được phát triển

Chương này sẽ trình bày về {chapter} trong bối cảnh nghiên cứu {st.session_state.thesis_data['topic']}.

*Nội dung sẽ được bổ sung dựa trên yêu cầu cụ thể.*
"""
                                    generated_content[chapter] = content

                            # Generate abstract if requested  
                            if include_abstract:
                                abstract = f"""**TÓM TẮT**

Nghiên cứu này tập trung vào {st.session_state.thesis_data['topic'].lower()} trong lĩnh vực {st.session_state.thesis_data['field'].lower()}. Mục tiêu chính là {st.session_state.thesis_data['objectives'].lower()}.

**Phương pháp:** Nghiên cứu sử dụng {st.session_state.thesis_data['approach'].lower()} với thiết kế mixed-methods bao gồm cả nghiên cứu định lượng và định tính.

**Kết quả:** Nghiên cứu đã xác định được những yếu tố quan trọng ảnh hưởng đến {st.session_state.thesis_data['topic'].lower()} và đề xuất các giải pháp cải thiện hiệu quả.

**Kết luận:** Kết quả nghiên cứu có đóng góp quan trọng cho lý thuyết và thực tiễn trong lĩnh vực {st.session_state.thesis_data['field'].lower()}, đặc biệt trong bối cảnh Việt Nam.

**Từ khóa:** {st.session_state.thesis_data['topic'].lower()}, {st.session_state.thesis_data['field'].lower()}, nghiên cứu thực nghiệm, Việt Nam
"""
                                generated_content['abstract'] = abstract

                            # Generate citations if requested
                            if include_citations:
                                if use_cerebras_ai:
                                    citations = st.session_state.ai_generator.generate_cerebras_citations(
                                        topic=st.session_state.thesis_data['topic'],
                                        field=st.session_state.thesis_data['field'],
                                        num_citations=25
                                    )
                                else:
                                    citations = st.session_state.ai_generator.generate_doctoral_level_citations(
                                        topic=st.session_state.thesis_data['topic'],
                                        field=st.session_state.thesis_data['field'],
                                        num_citations=25
                                    )
                                generated_content['citations'] = citations

                            st.session_state.thesis_data['ai_content'] = generated_content

                        st.success("✅ Đã tạo nội dung AI thành công!")
                    else:
                        st.error("Vui lòng chọn ít nhất một chương để tạo nội dung.")

            with col2:
                st.subheader("📝 Nội dung đã tạo")

                if 'ai_content' in st.session_state.thesis_data:
                    # Display global research context if available
                    if 'global_research_context' in st.session_state.thesis_data:
                        with st.expander("🌐 Bối cảnh nghiên cứu toàn cầu"):
                            context = st.session_state.thesis_data['global_research_context']
                            st.markdown("### 📊 Thống kê nghiên cứu")
                            col1, col2, col3 = st.columns(3)
                            with col1:
                                st.metric("Nghiên cứu liên quan", context.get('total_papers', 'N/A'))
                            with col2:
                                st.metric("Nghiên cứu gần đây", context.get('recent_papers', 'N/A'))
                            with col3:
                                st.metric("Trích dẫn cao", context.get('high_impact_papers', 'N/A'))

                            st.markdown("### 🔍 Tóm tắt xu hướng nghiên cứu")
                            st.markdown(context.get('research_trends', 'Đang cập nhật...'))

                    content_tabs = st.tabs(list(st.session_state.thesis_data['ai_content'].keys()))

                    for i, (key, content) in enumerate(st.session_state.thesis_data['ai_content'].items()):
                        with content_tabs[i]:
                            if key == 'citations':
                                st.subheader("📚 Tài liệu tham khảo")
                                for j, citation in enumerate(content, 1):
                                    st.write(f"{j}. {citation}")
                            else:
                                st.markdown(content)
                else:
                    st.info("👆 Chọn chương và nhấn 'Tạo nội dung AI' để xem kết quả")

    with tab5:
        st.header("🔍 Phản biện hội đồng học thuật")

        if 'ai_content' not in st.session_state.thesis_data:
            st.warning("⚠️ Vui lòng tạo nội dung AI ở tab trước để thực hiện phản biện học thuật.")
        else:
            col1, col2 = st.columns([1, 1])

            with col1:
                st.subheader("⚙️ Cấu hình hội đồng phản biện")

                # Chapter selection for review
                if 'ai_content' in st.session_state.thesis_data:
                    available_chapters = list(st.session_state.thesis_data['ai_content'].keys())
                    chapter_options = [ch for ch in available_chapters if ch not in ['abstract', 'citations']]
                else:
                    chapter_options = []

                chapter_to_review = st.selectbox(
                    "Chọn chương để phản biện",
                    chapter_options,
                    format_func=lambda x: {
                        "introduction": "Chương 1: Mở đầu",
                        "literature_review": "Chương 2: Tổng quan nghiên cứu", 
                        "methodology": "Chương 3: Phương pháp nghiên cứu",
                        "results": "Chương 4: Kết quả nghiên cứu",
                        "discussion": "Chương 5: Thảo luận",
                        "conclusion": "Chương 6: Kết luận"
                    }.get(x, x.title())
                )

                # Number of reviewers
                num_reviewers = st.slider(
                    "Số lượng phản biện viên",
                    min_value=3,
                    max_value=5,
                    value=3,
                    help="Hội đồng phản biện gồm 3-5 chuyên gia với chuyên môn khác nhau"
                )

                # Review focus areas
                st.subheader("🎯 Trọng tâm phản biện")
                review_focus = st.multiselect(
                    "Chọn các khía cạnh cần tập trung phản biện",
                    ["Phương pháp nghiên cứu", "Lý thuyết và tài liệu", "Ứng dụng thực tiễn", "Tính mới và đóng góp", "Viết học thuật"],
                    default=["Phương pháp nghiên cứu", "Lý thuyết và tài liệu"],
                    help="Các khía cạnh này sẽ được ưu tiên trong quá trình phản biện"
                )

                # Review strictness
                review_strictness = st.select_slider(
                    "Mức độ nghiêm khắc",
                    options=["Khuyến khích", "Bình thường", "Nghiêm khắc", "Rất nghiêm khắc"],
                    value="Bình thường",
                    help="Mức độ nghiêm khắc trong đánh giá của hội đồng"
                )

                # Advanced Defense Simulation
                st.subheader("🎭 Mô phỏng buổi bảo vệ luận văn")

                defense_type = st.radio(
                    "Loại phản biện",
                    ["Panel Review", "Full Defense Simulation"],
                    format_func=lambda x: {"Panel Review": "🔍 Phản biện thông thường", "Full Defense Simulation": "🎭 Mô phỏng bảo vệ đầy đủ"}[x],
                    horizontal=True
                )

                # Conduct review button
                if st.button("🔍 Tiến hành phản biện hội đồng", type="primary", use_container_width=True):
                    if chapter_options and chapter_to_review in st.session_state.thesis_data['ai_content']:
                        with st.spinner("Hội đồng đang phản biện chương..."):
                            try:
                                chapter_content = st.session_state.thesis_data['ai_content'][chapter_to_review]

                                if defense_type == "Full Defense Simulation":
                                    # Use enhanced peer review with defense simulation
                                    defense_session = st.session_state.enhanced_peer_review.conduct_defense_simulation(
                                        thesis_content=chapter_content,
                                        topic=st.session_state.thesis_data['topic'],
                                        field=st.session_state.thesis_data['field'],
                                        num_reviewers=num_reviewers
                                    )
                                    st.session_state.thesis_data['defense_simulation'] = defense_session
                                else:
                                    # Use standard panel review
                                    panel_review = st.session_state.peer_review_panel.conduct_panel_review(
                                        chapter_content=chapter_content,
                                        chapter_type=chapter_to_review,
                                        topic=st.session_state.thesis_data['topic'],
                                        field=st.session_state.thesis_data['field'],
                                        num_reviewers=num_reviewers
                                    )
                                    st.session_state.thesis_data['peer_review'] = panel_review

                                st.success("✅ Phản biện hội đồng hoàn thành!")
                            except Exception as e:
                                st.error(f"Lỗi phản biện: {str(e)}")
                    else:
                        st.error("Không tìm thấy nội dung chương được chọn")

            with col2:
                st.subheader("📋 Kết quả phản biện")

                # Display defense simulation results if available
                if 'defense_simulation' in st.session_state.thesis_data:
                    defense_session = st.session_state.thesis_data['defense_simulation']

                    st.markdown("### 🎭 Kết quả mô phỏng bảo vệ luận văn")

                    # Session info
                    session_info = defense_session['session_info']
                    col_info1, col_info2 = st.columns(2)
                    with col_info1:
                        st.metric("Ngày bảo vệ", session_info['date'])
                        st.metric("Số thành viên hội đồng", session_info['panel_size'])
                    with col_info2:
                        st.metric("Thời gian", session_info['time'])
                        st.metric("Chủ đề", session_info['topic'][:30] + "..." if len(session_info['topic']) > 30 else session_info['topic'])

                    # Panel decision
                    decision = defense_session['panel_decision']
                    if decision['result'] == "ĐẠT":
                        st.success(f"🎉 Kết quả: {decision['result']} - {decision['classification']}")
                    else:
                        st.error(f"❌ Kết quả: {decision['result']}")

                    st.metric("Điểm trung bình", f"{decision['average_score']}/10")

                    # Defense transcript
                    with st.expander("💬 Xem biên bản hội thoại bảo vệ"):
                        for dialogue in defense_session['defense_transcript']:
                            speaker_icon = "👨‍🏫" if "Chủ tịch" in dialogue['role'] or "Phản biện" in dialogue['role'] else "🎓"
                            st.markdown(f"**[{dialogue['timestamp']}] {speaker_icon} {dialogue['speaker']} ({dialogue['role']}):**")
                            st.markdown(f"{dialogue['content']}")
                            st.markdown("---")

                    # Individual evaluations
                    with st.expander("📊 Đánh giá chi tiết từng thành viên"):
                        for eval in defense_session['individual_evaluations']:
                            reviewer = eval['reviewer']
                            st.markdown(f"### {reviewer['name']} - {reviewer['title']}")
                            st.markdown(f"**Cơ quan:** {reviewer['institution']}")
                            st.markdown(f"**Điểm tổng thể:** {eval['overall_score']}/10")

                            # Detailed scores
                            st.markdown("**Chi tiết điểm số:**")
                            for criterion, score in eval['detailed_scores'].items():
                                st.markdown(f"- {criterion}: {score}/10")

                            st.markdown(f"**Nhận xét:** {eval['comments']}")
                            st.markdown(f"**Khuyến nghị:** {eval['recommendation']}")
                            st.markdown("---")

                    # Formal minutes download
                    if st.button("📄 Tải biên bản chính thức", use_container_width=True):
                        minutes = defense_session['formal_minutes']
                        st.download_button(
                            label="📥 Tải biên bản bảo vệ",
                            data=minutes.encode('utf-8'),
                            file_name=f"bien_ban_bao_ve_{session_info['date'].replace('/', '_')}.txt",
                            mime="text/plain",
                            use_container_width=True
                        )

                elif 'peer_review' in st.session_state.thesis_data:
                    review_results = st.session_state.thesis_data['peer_review']

                    # Panel consensus
                    consensus = review_results['panel_consensus']
                    st.markdown("### 🎯 Đánh giá chung của hội đồng")

                    col_metrics = st.columns(3)
                    with col_metrics[0]:
                        st.metric("Điểm trung bình", f"{consensus['average_score']:.1f}/10")
                    with col_metrics[1]:
                        st.metric("Độ nhất quán", consensus['score_consistency'])
                    with col_metrics[2]:
                        st.metric("Thời gian sửa", consensus['revision_timeline'])

                    # Decision
                    decision_color = {
                        "Accept with Minor Revisions": "success",
                        "Major Revisions Required": "warning", 
                        "Reject and Resubmit": "error",
                        "Reject": "error"
                    }
                    decision = consensus['consensus_decision']
                    if decision in decision_color:
                        if decision_color[decision] == "success":
                            st.success(f"✅ Quyết định: {decision}")
                        elif decision_color[decision] == "warning":
                            st.warning(f"⚠️ Quyết định: {decision}")
                        else:
                            st.error(f"❌ Quyết định: {decision}")

                    # Individual reviewer feedback
                    st.markdown("### 👥 Phản biện từng thành viên")

                    for review in review_results['individual_reviews']:
                        reviewer = review['reviewer_info']
                        with st.expander(f"📝 {reviewer['name']} - {reviewer['expertise']} (Điểm: {review['overall_score']:.1f})"):

                            st.markdown("**Điểm mạnh:**")
                            for strength in review['strengths']:
                                st.markdown(f"✅ {strength}")

                            st.markdown("**Điểm cần cải thiện:**")
                            for weakness in review['weaknesses']:
                                st.markdown(f"❗ {weakness}")

                            st.markdown("**Câu hỏi phản biện:**")
                            for i, question in enumerate(review['critical_questions'], 1):
                                st.markdown(f"{i}. {question}")

                    # Response strategies
                    st.markdown("### 📝 Hướng dẫn phản hồi")
                    strategies = review_results['response_strategies']

                    if strategies['immediate_actions']:
                        st.markdown("**Hành động ngay lập tức:**")
                        for action in strategies['immediate_actions']:
                            st.markdown(f"• {action}")

                    # Download review report
                    if st.button("📥 Tải báo cáo phản biện", use_container_width=True):
                        review_report = st.session_state.peer_review_panel.export_review_report(
                            review_results,
                            st.session_state.thesis_data['topic'],
                            chapter_to_review
                        )
                        st.download_button(
                            label="📥 Tải file báo cáo phản biện",
                            data=review_report.encode('utf-8'),
                            file_name=f"bao_cao_phan_bien_{chapter_to_review}.txt",
                            mime="text/plain",
                            use_container_width=True
                        )
                else:
                    st.info("👆 Chọn chương và tiến hành phản biện để xem kết quả")

    with tab6:
        st.header("📄 Kết quả và xuất file")

        # Progress overview
        st.subheader("📊 Tổng quan tiến độ")
        progress_items = [
            ("Thông tin cơ bản", 'topic' in st.session_state.thesis_data),
            ("Đề cương", 'outline' in st.session_state.thesis_data),
            ("Khung lý thuyết", 'theoretical_framework' in st.session_state.thesis_data),
            ("Phân tích dữ liệu", 'advanced_analysis' in st.session_state.thesis_data),
            ("Nội dung AI", 'ai_content' in st.session_state.thesis_data),
            ("Phản biện", 'peer_review' in st.session_state.thesis_data)
        ]

        cols_progress = st.columns(len(progress_items))
        for i, (name, completed) in enumerate(progress_items):
            with cols_progress[i]:
                if completed:
                    st.success(f"✅ {name}")
                else:
                    st.error(f"❌ {name}")

        # Calculate completion percentage
        completed_count = sum(1 for _, completed in progress_items if completed)
        completion_pct = (completed_count / len(progress_items)) * 100
        st.progress(completion_pct / 100)
        st.markdown(f"**Hoàn thành:** {completion_pct:.0f}%")

        # Final document generation
        st.subheader("📝 Tạo luận văn hoàn chỉnh")

        if completion_pct >= 50:  # At least 50% completed
            col1, col2 = st.columns([1, 1])

            with col1:
                document_format = st.selectbox(
                    "Chọn định dạng xuất",
                    ["docx", "pdf", "txt"],
                    format_func=lambda x: {"docx": "Microsoft Word (.docx)", "pdf": "PDF (.pdf)", "txt": "Text (.txt)"}[x]
                )

                include_components = st.multiselect(
                    "Chọn thành phần đưa vào luận văn",
                    ["outline", "theoretical_framework", "ai_content", "advanced_analysis", "peer_review"],
                    default=["outline", "theoretical_framework", "ai_content"],
                    format_func=lambda x: {
                        "outline": "Đề cương",
                        "theoretical_framework": "Khung lý thuyết", 
                        "ai_content": "Nội dung AI",
                        "advanced_analysis": "Phân tích dữ liệu",
                        "peer_review": "Báo cáo phản biện"
                    }[x]
                )

                if st.button("🎓 Tạo luận văn hoàn chỉnh", type="primary", use_container_width=True):
                    with st.spinner("Đang tổng hợp và tạo file luận văn..."):
                        try:
                            doc_generator = EnhancedDocumentGenerator()

                            # Include selected components
                            content_data = {}
                            for component in include_components:
                                if component in st.session_state.thesis_data:
                                    content_data[component] = st.session_state.thesis_data[component]

                            # Generate enhanced document
                            if document_format == "docx":
                                doc_content = doc_generator.create_enhanced_document(
                                    st.session_state.thesis_data,
                                    include_visualizations=True,
                                    include_references=True
                                )
                                st.session_state.final_document = doc_content
                                st.success("✅ Luận văn hoàn chỉnh đã được tạo!")
                            else:
                                # For other formats, create text version
                                text_content = doc_generator.export_text_version(st.session_state.thesis_data)
                                st.session_state.final_document = text_content
                                st.success("✅ Luận văn hoàn chỉnh đã được tạo!")
                        except Exception as e:
                            st.error(f"Lỗi tạo luận văn: {str(e)}")

            with col2:
                st.subheader("📋 Thông tin luận văn")

                if st.session_state.thesis_data:
                    st.markdown("### 📖 Thông tin chung")
                    st.write("**Đề tài:**", st.session_state.thesis_data.get('topic', 'N/A'))
                    st.write("**Ngành:**", st.session_state.thesis_data.get('field', 'N/A'))
                    st.write("**Trình độ:**", st.session_state.thesis_data.get('level', 'N/A'))
                    st.write("**Phương pháp:**", st.session_state.thesis_data.get('approach', 'N/A'))

                    # Download section
                    if 'final_document' in st.session_state:
                        st.markdown("### 📥 Tải xuống")

                        filename = f"luan_van_{st.session_state.thesis_data.get('field', 'unknown').lower().replace(' ', '_')}"

                        if isinstance(st.session_state.final_document, bytes):
                            # DOCX file
                            st.download_button(
                                label="📥 Tải luận văn (.docx)",
                                data=st.session_state.final_document,
                                file_name=f"{filename}.docx",
                                mime="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                                use_container_width=True
                            )
                        else:
                            # Text file
                            st.download_button(
                                label=f"📥 Tải luận văn (.{document_format})",
                                data=st.session_state.final_document.encode('utf-8'),
                                file_name=f"{filename}.{document_format}",
                                mime="text/plain",
                                use_container_width=True
                            )

                # Statistics
                if 'ai_content' in st.session_state.thesis_data:
                    st.markdown("### 📊 Thống kê nội dung")
                    total_words = 0
                    for content in st.session_state.thesis_data['ai_content'].values():
                        if isinstance(content, str):
                            total_words += len(content.split())
                        elif isinstance(content, list):
                            total_words += sum(len(str(item).split()) for item in content)

                    st.metric("Tổng số từ", f"{total_words:,}")
                    st.metric("Số chương", len([k for k in st.session_state.thesis_data['ai_content'].keys() if k not in ['abstract', 'citations']]))
        else:
            st.warning(f"⚠️ Cần hoàn thành ít nhất 50% để tạo luận văn (hiện tại: {completion_pct:.0f}%)")
            st.info("💡 Hoàn thành các tab trước để có thể tạo luận văn hoàn chỉnh")


if __name__ == "__main__":
    main()
