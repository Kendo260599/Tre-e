# Overview

AutoThesis Writer is a comprehensive doctoral-level academic thesis generation and review system that automatically creates high-quality, unrefutable Vietnamese academic theses. The system meets international academic standards, includes rigorous peer review functionality, AI-powered content generation with proper citations, statistical analysis capabilities, theoretical framework building, and exports complete theses in multiple formats.

## Recent Major Enhancements (August 21, 2025)
- **Six-Tab Advanced Interface**: Basic Info → Theoretical Framework → Advanced Data Analysis → AI Content → Peer Review Panel → Final Results
- **Enhanced Peer Review Panel with Defense Simulation**: Added AI Panel Defense Simulator with formal defense session simulation, detailed reviewer profiles, and comprehensive evaluation transcripts
- **Global Academic Database Integration**: Connected to international research databases for enhanced content validation and up-to-date citations across all chapters
- **Visual Research Model Generator**: Automatic creation of conceptual diagrams and research frameworks with statistical analysis plan generation
- **Advanced Theoretical Framework System**: Enhanced with visual diagram generation, statistical planning, and multi-theory integration
- **Dual Review System**: Standard panel review and full defense simulation modes with formal minutes and evaluation transcripts
- **Enhanced AI Content Generation**: Integrated with global database for international research context and improved academic rigor
- **Complete Academic Workflow**: From initial framework through visual models to formal defense simulation with comprehensive documentation

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
- **Advanced Six-Tab Interface**: Streamlit-based progressive workflow with Basic Info → Theoretical Framework → Advanced Data Analysis → AI Content → Peer Review Panel → Final Results
- **Interactive Components**: Multi-level forms with paradigm selection, complexity settings, review configuration, and progress tracking
- **Real-time Analysis**: Displays generated frameworks, statistical results, and peer review feedback immediately

## Core Engine Architecture
- **Theoretical Framework Generator**: Automatically builds comprehensive academic frameworks with theory selection, conceptual modeling, and hypothesis generation based on topic analysis
- **Advanced Data Analyzer**: AI-powered statistical analysis engine that automatically selects appropriate methods, performs analysis, and generates academic interpretations
- **Simulated Peer Review Panel**: Multi-reviewer system simulating 3-5 academic experts with different specializations and review styles
- **Doctoral AI Content Generator**: Enhanced content creation with proper scholarly citations, methodological rigor, and theoretical contributions

## Analysis and Review System
- **Automatic Method Selection**: AI analyzes research questions and data to recommend appropriate statistical methods
- **Multi-Perspective Review**: Simulates methodology experts, theory specialists, practical application reviewers, innovation assessors, and writing quality evaluators
- **Academic Quality Assurance**: Ensures content meets international doctoral standards with proper citations, theoretical depth, and methodological rigor

## Document Generation System
- **Enhanced Document Creation**: Generates complete thesis documents integrating all components (theoretical frameworks, statistical analysis, peer review reports)
- **Multiple Format Support**: Exports to DOCX, PDF, and text formats with proper academic formatting
- **Component Integration**: Seamlessly combines outline, theoretical framework, AI content, data analysis, and review feedback into cohesive documents

## Intelligent Content Engine
- **Context-Aware Generation**: Adapts content based on field, research approach, and complexity level
- **Quality Control Integration**: Built-in academic review and feedback mechanisms
- **Progressive Development**: Supports iterative thesis development with continuous quality improvement

# External Dependencies

## Python Libraries
- **Streamlit**: Web application framework for the user interface
- **python-docx**: Document generation library for creating Word documents
- **io**: Built-in Python library for in-memory file operations

## Template Resources
- **Vietnamese Academic Standards**: Built-in templates following Vietnamese university thesis requirements
- **Field-Specific Guidelines**: Integrated knowledge base for different academic disciplines

## Document Export
- **Microsoft Word Format**: Generates .docx files compatible with Microsoft Word and similar office suites
- **Download Functionality**: Streamlit's built-in download capabilities for file delivery
