import { type NextRequest, NextResponse } from "next/server"

const CEREBRAS_API_KEY = "csk-ekpp2wm8npdv8wdk43tn6ef53ww86errnw3ec8hwr99xk496"
const CEREBRAS_API_URL = "https://api.cerebras.ai/v1/chat/completions"

export async function POST(request: NextRequest) {
  try {
    const { prompt, type } = await request.json()

    const response = await fetch(CEREBRAS_API_URL, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${CEREBRAS_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "llama3.1-8b",
        messages: [
          {
            role: "system",
            content:
              "Bạn là một chuyên gia tâm lý học và nghiên cứu khoa học. Hãy trả lời bằng tiếng Việt một cách chuyên nghiệp và chi tiết.",
          },
          {
            role: "user",
            content: prompt,
          },
        ],
        temperature: 0.7,
        max_tokens: 2000,
      }),
    })

    if (!response.ok) {
      throw new Error(`Cerebras API error: ${response.status}`)
    }

    const data = await response.json()
    const aiResponse = data.choices[0]?.message?.content || "Không thể tạo nội dung"

    return NextResponse.json({
      success: true,
      content: aiResponse,
      type,
    })
  } catch (error) {
    console.error("Cerebras AI Error:", error)
    return NextResponse.json({ success: false, error: "Lỗi kết nối AI" }, { status: 500 })
  }
}
