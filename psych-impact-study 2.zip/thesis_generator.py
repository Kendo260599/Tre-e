from templates.thesis_templates import ThesisTemplates

class ThesisOutlineGenerator:
    def __init__(self):
        self.templates = ThesisTemplates()
    
    def generate_outline(self, topic, field, level, objectives, approach):
        """
        Generate a comprehensive thesis outline based on input parameters
        """
        # Determine the template based on degree level
        if level == "Tiến sĩ":
            base_structure = self.templates.get_doctoral_structure()
        else:
            base_structure = self.templates.get_masters_structure()
        
        # Customize the outline based on field and research approach
        customized_outline = self._customize_outline(
            base_structure, topic, field, objectives, approach
        )
        
        return customized_outline
    
    def _customize_outline(self, base_structure, topic, field, objectives, approach):
        """
        Customize the base outline structure with specific content
        """
        customized = []
        
        for chapter in base_structure:
            customized_chapter = chapter.copy()
            
            # Customize chapter descriptions based on field and topic
            if chapter['id'] == 'introduction':
                customized_chapter['description'] = self._generate_introduction_description(topic, field, objectives)
            
            elif chapter['id'] == 'literature_review':
                customized_chapter['description'] = self._generate_literature_description(topic, field)
            
            elif chapter['id'] == 'theoretical_framework':
                customized_chapter['description'] = self._generate_theoretical_description(topic, field)
            
            elif chapter['id'] == 'methodology':
                customized_chapter['description'] = self._generate_methodology_description(approach, field)
                customized_chapter['sections'] = self._customize_methodology_sections(approach)
            
            elif chapter['id'] == 'results':
                customized_chapter['description'] = self._generate_results_description(approach, objectives)
            
            elif chapter['id'] == 'discussion':
                customized_chapter['description'] = self._generate_discussion_description(objectives, field)
            
            elif chapter['id'] == 'conclusion':
                customized_chapter['description'] = self._generate_conclusion_description(objectives, field)
            
            customized.append(customized_chapter)
        
        return customized
    
    def _generate_introduction_description(self, topic, field, objectives):
        return f"""
        Chương này giới thiệu bối cảnh nghiên cứu về {topic.lower()} trong lĩnh vực {field.lower()}. 
        Trình bày tính cấp thiết của vấn đề nghiên cứu, các khoảng trống trong kiến thức hiện tại, 
        và ý nghĩa thực tiễn của nghiên cứu. Đặt ra câu hỏi nghiên cứu chính và mục tiêu cụ thể 
        nhằm {objectives.lower()}.
        """
    
    def _generate_literature_description(self, topic, field):
        return f"""
        Tổng quan toàn diện các nghiên cứu trước đây liên quan đến {topic.lower()} trong bối cảnh 
        {field.lower()}. Phân tích các lý thuyết, mô hình và phát hiện nghiên cứu có liên quan, 
        xác định khoảng trống nghiên cứu và định vị nghiên cứu hiện tại trong bối cảnh học thuật rộng lớn.
        """
    
    def _generate_theoretical_description(self, topic, field):
        return f"""
        Xây dựng khung lý thuyết cho nghiên cứu dựa trên các lý thuyết cơ bản trong {field.lower()}. 
        Phát triển mô hình nghiên cứu và các giả thuyết (nếu có) để giải thích mối quan hệ giữa các 
        biến số liên quan đến {topic.lower()}.
        """
    
    def _generate_methodology_description(self, approach, field):
        methodology_descriptions = {
            "Nghiên cứu định lượng": f"""
            Trình bày thiết kế nghiên cứu định lượng với phương pháp thu thập và phân tích dữ liệu số. 
            Mô tả dân số mục tiêu, phương pháp chọn mẫu, công cụ đo lường, và các phương pháp thống kê 
            phù hợp với nghiên cứu trong lĩnh vực {field.lower()}.
            """,
            "Nghiên cứu định tính": f"""
            Mô tả thiết kế nghiên cứu định tính với các phương pháp thu thập dữ liệu chất lượng như 
            phỏng vấn sâu, quan sát tham gia. Trình bày phương pháp chọn mẫu có mục đích, quy trình 
            phân tích nội dung thematic phù hợp với nghiên cứu {field.lower()}.
            """,
            "Nghiên cứu hỗn hợp (định lượng + định tính)": f"""
            Thiết kế nghiên cứu hỗn hợp kết hợp cả phương pháp định lượng và định tính. Mô tả cách 
            tích hợp hai loại dữ liệu để có cái nhìn toàn diện về vấn đề nghiên cứu trong {field.lower()}.
            """
        }
        
        return methodology_descriptions.get(approach, f"""
        Trình bày phương pháp nghiên cứu {approach.lower()} được sử dụng, bao gồm thiết kế nghiên cứu, 
        phương pháp thu thập và phân tích dữ liệu phù hợp với nghiên cứu trong lĩnh vực {field.lower()}.
        """)
    
    def _customize_methodology_sections(self, approach):
        base_sections = [
            {"number": "3.1", "title": "Thiết kế nghiên cứu", "description": "Mô tả tổng thể về thiết kế và phương pháp tiếp cận nghiên cứu"},
            {"number": "3.2", "title": "Đối tượng và phạm vi nghiên cứu", "description": "Xác định dân số mục tiêu, đơn vị phân tích và phạm vi nghiên cứu"},
            {"number": "3.3", "title": "Phương pháp chọn mẫu", "description": "Mô tả kỹ thuật chọn mẫu và xác định kích thước mẫu phù hợp"}
        ]
        
        if "định lượng" in approach.lower():
            base_sections.extend([
                {"number": "3.4", "title": "Công cụ thu thập dữ liệu", "description": "Thiết kế bảng hỏi/thang đo và kiểm định độ tin cậy, độ giá trị"},
                {"number": "3.5", "title": "Phương pháp phân tích dữ liệu", "description": "Các kỹ thuật thống kê mô tả và suy luận được sử dụng"}
            ])
        
        if "định tính" in approach.lower():
            base_sections.extend([
                {"number": "3.4", "title": "Phương pháp thu thập dữ liệu định tính", "description": "Kỹ thuật phỏng vấn, quan sát và thu thập tài liệu"},
                {"number": "3.5", "title": "Phương pháp phân tích nội dung", "description": "Quy trình mã hóa và phân tích chủ đề (thematic analysis)"}
            ])
        
        base_sections.append({
            "number": "3.6", "title": "Đạo đức nghiên cứu", 
            "description": "Các vấn đề đạo đức và biện pháp đảm bảo quyền lợi của đối tượng nghiên cứu"
        })
        
        return base_sections
    
    def _generate_results_description(self, approach, objectives):
        return f"""
        Trình bày chi tiết các kết quả nghiên cứu thu được thông qua phương pháp {approach.lower()}. 
        Phân tích và diễn giải dữ liệu một cách khách quan, hệ thống để trả lời các câu hỏi nghiên cứu 
        và đạt được {objectives.lower()}.
        """
    
    def _generate_discussion_description(self, objectives, field):
        return f"""
        Thảo luận ý nghĩa của các kết quả nghiên cứu trong bối cảnh {field.lower()}. So sánh với 
        các nghiên cứu trước đây, giải thích các phát hiện mới, và đánh giá mức độ đạt được 
        {objectives.lower()}. Thảo luận về những hạn chế của nghiên cứu.
        """
    
    def _generate_conclusion_description(self, objectives, field):
        return f"""
        Tổng kết các phát hiện chính của nghiên cứu và ý nghĩa của chúng đối với lĩnh vực {field.lower()}. 
        Đưa ra các kiến nghị thực tiễn và hướng nghiên cứu tương lai. Đánh giá đóng góp của nghiên cứu 
        trong việc {objectives.lower()}.
        """
